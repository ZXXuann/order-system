<script>
	export default {
		onLaunch: function() {
			// uni.setStorageSync("token","eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIzY2ViNDRiNDNiODE0NTkyODI3YmEzZjQ3Y2ZiNmJjZSIsInN1YiI6IjEiLCJpc3MiOiJ6eHgiLCJpYXQiOjE2NzQxNDMxMTIsImV4cCI6MTY3NDIyOTUxMn0.J2nXAnmR7CZ4w7eAmYUYv9pLR8p3G_er-mt4Vczn2n8")
		},
		onShow: function() {
		},
		onHide: function() {
		},
		// components: {
		// 	uniCard
		// },
	}
</script>

<style lang="scss">
	@import '~@/static/styles/app.scss';
</style>
