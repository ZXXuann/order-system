## 1.0.2（2022-09-30）
修复 columnType 不生效的问题
修复 compressSize和imageSize 小程序不生效的问题
新增 compressQuality 照片压缩质量,详见属性介绍
新增 compressWidth 照片压缩宽度,详见属性介绍
## 1.0.1（2022-07-18）
- 更新使用说明
- 一定要仔细看
## 1.0.0（2022-07-15）
- jade-image-upload 图片上传组件
- 使用uni_modules目录规范
- 目前兼容微信小程序、H5，其它平台未实际测试过