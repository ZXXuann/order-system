<template>
	<view class="container">
		<uni-list>
			<uni-list-item v-for="item in msgList" :title="item.from+''" :note="item.msg"></uni-list-item>
		</uni-list>
		<view class="textarea-box">
			<textarea class="textarea" v-model="message.msg" placeholder-class="placeholder" :maxlength="50"
				auto-height="true"></textarea>

		</view>
		<button type="info" style="margin-top: 10rpx" @tap="send">发送</button>
	</view>
</template>


<script>
	let socket;
	export default {
		data() {
			return {
				// 桌号
				deskId: JSON.parse(localStorage.getItem("deskId")).data || '游客',
				// 消息记录列表
				msgList: [],
				// 发送的消息
				message: {
					time: null, //时间
					to: '客服', //发给谁
					from: '',
					msg: ''
				}
			}
		},
		onLoad() {
			let temp = sessionStorage.getItem("contact");
			console.log(temp);
			if (temp != null) {
				this.msgList = JSON.parse(temp);
			}
		 this.init();
		},
		onclose() {
			console.log(JSON.stringify(this.msgList))
			sessionStorage.setItem("contact", JSON.stringify(this.msgList));
			socket.onclose();
		},
		onHide() {
			sessionStorage.setItem("contact", JSON.stringify(this.msgList));
		},
		methods: {
			send() {
				if (!this.message.msg) {
					uni.showToast({
						title: '请输入信息',
						//将值设置为 success 或者直接不用写icon这个参数
						icon: 'error',
						//显示持续时间为 2秒
			  	duration: 2000
					})
				} else {
					var that = this;
					this.message.from = this.deskId;
					this.message.time = new Date().toLocaleTimeString();
					socket.send(JSON.stringify(this.message));
					let obj = {
						time: that.message.time,
						to: '客服', //发给谁
						from: that.deskId,
						msg: that.message.msg
					}
					this.msgList = [...this.msgList, obj]
			 	this.message.msg = '';
				}
			},
			init() {
				let that = this;
				let socketUrl = "ws://localhost:8080/websocket/" + this.deskId;
				// 开启一个websocket服务
				socket = new WebSocket(socketUrl);
				//打开事件
				socket.onopen = function() {
					console.log("websocket已打开");
				};
				//  浏览器端收消息，获得从服务端发送过来的文本消息
				socket.onmessage = function(msg) {
					let data = JSON.parse(msg.data)
					if (data.to == "all") {
						console.log(data);
					} else
						that.msgList = [...that.msgList, data]
				};
				//关闭事件
				socket.onclose = function() {
					console.log("websocket已关闭");
				};
				//发生了错误事件
				socket.onerror = function() {
					console.log("websocket发生了错误");
				}
			}
		}
	}
</script>

<style lang="scss">
	.container {
		background-color: #FFFFFF;
		padding: 40rpx;
	}

	.chat-custom-right {
		flex: 1;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		justify-content: space-between;
		align-items: flex-end;
	}

	.chat-custom-text {
		font-size: 12px;
		color: #999;
	}

	.remarks {
		margin-bottom: 40rpx;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		font-size: $font-size-base;

		.remark {
			color: $text-color-assist;
			padding: 10rpx 26rpx;
			border: 1rpx solid rgba($color: $border-color, $alpha: 0.6);
			margin-right: 20rpx;

			&.active {
				color: #343434;
				border-color: #343434;
			}
		}
	}

	.textarea-box {
		.textarea {
			width: 100%;
			border: 1rpx solid rgba($color: $border-color, $alpha: 0.6);
			padding: 20rpx;
			font-size: $font-size-medium;
		}
	}
</style>
