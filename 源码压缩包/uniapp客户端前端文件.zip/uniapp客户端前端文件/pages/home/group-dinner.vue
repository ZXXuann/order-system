<template>
	<view class="container">
		<image src="http://go.cdn.heytea.com/storage/products/2020/06/01/74271488c8d046fab5f2e64d6c94d8a7.jpeg" class="w-100" mode="widthFix"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
