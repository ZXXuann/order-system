<template>
	<view>
		<view class="packet-form" v-if="discount!=null">
			<uni-card title="不使用红包卡券" @click="handleNo"></uni-card>
			<uni-card v-for="(item,index) in discount" :title="item.discountTitle" :extra="item.discountAccount+'元'" :sub-title="'截止时间:'+item.validate" 
				:thumbnail="item.discountType==0?'/static/images/card/redpacket.png':'/static/images/card/discount.png'"
				@click="handleGo(item)">
				<text style="font-size:20rpx;display: block;">{{item.discountDetail}}</text>
				<text v-if="item.discountCondition!=0" style="font-size:20rpx;display: block;">满{{item.discountCondition}}元-{{item.discountAccount}}元</text>
			</uni-card>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				giftCards: [],
				currentTab2Index: 0,
				myGiftCards: [],
				product: {},
				per: 1,
				discount: [],
				novalidate: [],
				discountCondition:0,
			}
		},
		onReachBottom() {
			if (this.isStart) {
				this.per++;
				this.getRateList();
			}
		},
		onLoad(e){
			this.discountCondition=e.amount;
			this.getDiscount();
		},
		methods: {
			handleNo(){
				uni.navigateTo({
					url:'/pages/pay/pay'
				})
			},
			handleGo(e){
				uni.navigateTo({
					url:'/pages/pay/pay?id='+e.cdId+"&amount="+e.discountAccount,
				})
			},
			getDiscount() {
				this.$request({
					url: "/discount/validCondition?discountCondition="+this.discountCondition+"&pageNum=" + this.per
				}).then(res => {
					if (res.code == 200) {
						let arr = res.data;
						if (arr == null || arr.length == 0) {
							this.isStart = false;
							return;
						}
						console.log(res);
						this.discount.push(...arr);
					}
				})
			},
			
		}
	}
</script>

<style>

</style>
