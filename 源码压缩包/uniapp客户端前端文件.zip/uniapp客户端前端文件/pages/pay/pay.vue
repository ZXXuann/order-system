<template>
	<view class="container">
		<!-- <view class="bg-white p-30 d-flex align-items-center justify-content-between mb-20">
			<view>
				<text class="mr-20">联系电话</text>
				<text>18666610000</text>
			</view>
			<button type="primary" plain class="font-size-sm line-height-1">自动填写</button>
		</view> -->
		<!-- <view class="bg-white p-30 mb-20">
			<view class="font-size-medium font-weight-bold mb-30">取餐时间</view>
			<view class="text-color-primary">冰淇淋/鲜食等产品无需等待，可立即向店员领取</view>
		</view> -->
		<view class="bg-white pt-30 mb-20">
			<view class="font-size-medium font-weight-bold mb-30 pl-30">商品列表</view>
			<list-cell arrow line-right>
				<view class="w-100 d-flex align-items-center overflow-hidden">
					<scroll-view class="flex-fill overflow-hidden" scroll-x>
						<view class="w-100 d-flex align-items-center">
							<image v-for="(item, index) in cart" :src="url+item.foodImg" class="pro-img" :key="index">
							</image>
						</view>
					</scroll-view>
					<view class="flex-shrink-0 ml-20">共{{ cartNum }}件</view>
				</view>
			</list-cell>
			<list-cell arrow last>
				<view class="w-100 d-flex align-items-center justify-content-between" @tap="handleDiscount">
					<view class="d-flex align-items-center">
						<view>优惠券</view>
						<view class="coupon-label">劵</view>
					</view>
					<view class="text-color-assist">{{discount}}</view>
				</view>
			</list-cell>
			<list-cell arrow last>
				<view class="w-100 d-flex align-items-center justify-content-between overflow-hidden">
					<view class="flex-shrink-0">备注</view>
					<navigator hover-class="none" class="flex-fill ml-40 text-truncate text-right" open-type="navigate"
						url="/pages/pay/remark">{{ remark }}</navigator>
				</view>
			</list-cell>
			<list-cell last>
				<view class="w-100 d-flex justify-content-end align-items-center">
					<text class="font-size-sm">共{{ cartNum }}件商品，小计</text>
					<text class="font-size-lg font-weight-bold">￥{{ cartAmount }}</text>
				</view>
			</list-cell>
		</view>
		<list-cell last>
			<view class="w-100 d-flex align-items-center justify-content-between">
				<view>支付方式</view>
				<view class="d-flex align-items-center">
					<image src="/static/images/order/weixin-pay.png" class="wx-pay-icon"></image>
					<view>微信</view>
				</view>
			</view>
		</list-cell>
		<view class="footer">
			<view class="mr-30">
				合计：<text class="font-size-lg font-weight-bold">￥{{ cartAmount }}</text>
			</view>
			<button type="primary" @click="handlePay">支付</button>
		</view>
	</view>
</template>

<script>
	import listCell from '@/components/list-cell/list-cell.vue'

	export default {
		components: {
			listCell
		},
		data() {
			return {
				cart: uni.getStorageSync('cart'),
				url: "",
				discount: "无优惠券",
				discountnum: 0,
				cdId: 0,
				customerName: "",
				customerAddr: "",
				customerPhone: 0,
				orderType: 0,
				chairNo: uni.getStorageSync("deskId") || 0,
				address: uni.getStorageSync('address') || null

			}
		},
		onLoad(e) {
			this.url = this.$url;
			this.discountnum = (e.amount != undefined ? e.amount : 0);
			this.discount = (e.amount != undefined ? '-' + e.amount + '元' : '无优惠券');
			this.cdId = e.id != undefined ? e.id : 0;
			this.orderType = uni.getStorageSync('orderType') || 0;
		},

		computed: {
			cartNum() {
				return this.cart.reduce((acc, cur) => acc + cur.number, 0)
			},
			cartAmount() {
				return this.cart.reduce((acc, cur) => acc + cur.number * cur.foodPrice , 0)- this.discountnum;
			},
			remark() {
				return this.$store.state.remark
			}
		},
		methods: {
			handleDiscount() {
				uni.navigateTo({
					url: '/pages/pay/discount?amount='+this.cartAmount
				})
			},
			handlePay() {
				// let formData=new FormData();
				// formData.append("cdId",this.cdId);
				// formData.append("customerName",this.customerName);
				// formData.append("customerAddr",this.customerAddr);
				// formData.append("customerId",this.customerId);
				// formData.append("orderType",this.orderType);
				// formData.append("chairNo",this.chairNo);
				// this.cart.forEach((item,index)=>{
				// 	formData.append("foods[" + index + "].foodId", this.cart[index].id);
				// 	formData.append("foods[" + index + "].foodNumber", this.cart[index].foodNumber);
				// })
				let obj = {
					cdId: this.cdId,
					// customerName:this.customerName,
					// customerAddr:this.customerAddr,
					orderType: this.orderType,
					chairNo: this.chairNo,
					foods: []
				}
				if (this.orderType == 1 && this.address != null) {
					this.$set(obj, "customerPhone", this.address.phone);
					this.$set(obj, "customerName", this.address.name);
					this.$set(obj, "customerAddr", this.address.address + this.address.description);
				}
				this.cart.forEach((item, index) => {
					let temp = {
						foodId: this.cart[index].foodId,
						foodNumber: this.cart[index].number,
						speciIds: this.cart[index].spciIds,
					}
					obj.foods.push(temp);
				})
				console.log(obj)
				this.$request({
					url: "/cart/postcart",
					data: obj,
					method: "post",
					contentType: "application/json",
				}).then(res => {
					console.log(res);
					if (res.code == 200) {
						uni.removeStorageSync('orderType');
						uni.removeStorageSync('cart');
						uni.showToast({
							icon: 'success',
							title: '操作成功'
						})
						uni.switchTab({
							url: "/pages/order/order"
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.info {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.container {
		height: auto;
		padding-bottom: 120rpx;
	}

	.pro-img {
		width: 170rpx;
		height: 120rpx;
		flex-shrink: 0;
		padding-right: 15rpx;
	}

	.coupon-label {
		background-color: $color-primary;
		color: #FFFFFF;
		font-size: 18rpx;
		line-height: 0.9rem;
		width: 0.9rem;
		height: 0.9rem;
		margin-left: 10rpx;
		text-align: center;
	}

	.wx-pay-icon {
		width: 40rpx;
		height: 40rpx;
		margin-right: 10rpx;
	}

	.footer {
		background-color: #FFFFFF;
		z-index: 10;
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100rpx;
		display: flex;
		justify-content: flex-end;
		align-items: center;

		button {
			width: 250rpx;
			text-align: center;
			padding: 0;
			height: 100%;
			line-height: 100rpx;
			border-radius: 0 !important;
			font-size: $font-size-lg;
		}
	}
</style>
