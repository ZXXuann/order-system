<template>
	<view class="container">
		<desk  @change="getDesk" :visible="deskvisible&&orderType == 'takein'" @closeDesk="closeDesk"></desk>
		<view class="header">
			<!-- 搜索栏 begin -->
			<view class="search-box">
				<view class="search-input" @tap="handleSearch">
					<image src="/static/images/common/search-icon.png" class="search-icon"></image>
					<view>搜索</view>
				</view>
			</view>
			<!-- 搜索栏 end -->
			<view class="center">
				<view class="store">
					<view class="title">
						<image :src="orderType == 'takein' ? 
								'/static/images/common/star_normal.png' : 
								'/static/images/order/order_icon_address.png'" class="left-icon" />
						<!-- 为了测试方便，这里使用静态店铺数据 -->
						<view class="address">{{ orderType == 'takeout' ? address.address+address.description : '广东药科大学店' }}</view>
						<!-- //<image src="/static/images/common/black_arrow_right.png" class="right-icon"></image> -->
					</view>
					<!-- 外卖&自取switch begin -->
					<view class="buttons">
						<button type="default" class="button" :class="{active: orderType == 'takein'}" plain
							hover-class="none" @tap="switchOrderType">
							堂食
						</button>
						<button type="default" class="button" :class="{active: orderType == 'takeout'}" plain
							hover-class="none" @tap="switchOrderType">
							外卖
						</button>
					</view>
					<!-- 外卖&自取switch end -->
				</view>
				<view v-if="orderType != 'takeout'" class="location" @tap="handleChooseDesk">下单桌号：{{deskId}}
					<uni-icons type="forward" size="15" style="padding-left:10rpx;color:#b4b4b4"></uni-icons>
				</view>
			</view>
			<!-- 滚动公告栏 begin -->
			<!-- <view class="notices">
				<swiper class="swiper" autoplay vertical :interval="3000" :duration="1000" circular>
					<swiper-item v-for="(notice, index) in notices" :key="index">
						<view class="swiper-item">
							<image :src="notice.image" class="image"></image>
							<view class="content">{{ notice.content }}</view>
						</view>
					</swiper-item>
				</swiper>
				<view class="more">
					<text>更多</text>
					<image src="/static/images/common/gray_arrow_down.png" class="down-icon"></image>
				</view>
			</view> -->
		</view>
		<!-- 滚动公告栏 end -->
		<view class="main">
			<!-- 左侧菜单 begin -->
			<scroll-view class="menu-bar" scroll-y scroll-with-animation>
				<view class="wrapper">
					<view class="menu-item" @tap="handleMenuSelected(category.foodtypeId)"
						:class="{active: currentCategoryId == category.foodtypeId}"
						v-for="(category, index) in categories" :key="index">
						<image :src="url+category.foddtypeImg" class="image" mode="widthFix"></image>
						<view class="title">{{ category.foodtypeName }}</view>
					</view>
				</view>
			</scroll-view>
			<!-- 左侧菜单 end -->
			<!-- 右侧商品列表 begin -->
			<scroll-view class="product-section" scroll-y scroll-with-animation :scroll-top="productsScrollTop"
				@scroll="productsScroll">
				<view class="wrapper">
					<view id="ads">
						<!-- 广告栏1 begin -->
						<swiper class="ads1" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000"
							circular>
							<swiper-item v-for="(ad, index) in ads1" :key="index">
								<image :src="ad" class="w-100" mode="widthFix"></image>
							</swiper-item>
						</swiper>
						<!-- 广告栏1 end -->
						<!-- 广告栏2 begin -->
						<swiper class="ads2" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000"
							circular>
							<swiper-item v-for="(ad, index) in ads2" :key="index">
								<image :src="ad" class="w-100" mode="widthFix"></image>
							</swiper-item>
						</swiper>
						<!-- 广告栏2 end -->
					</view>
					<!-- 商品 begin -->
					<view class="products-list" v-for="(category, index) in categories" :key="index"
						:id="`products-${category.foodtypeId}`">
						<view class="category-name">{{ category.foodtypeName }}</view>
						<view class="products">
							<view class="product" v-for="(product, key) in category.items" :key="key"
								@tap="showProductDetailModal(product)">
								<image :src="url+product.foodImgs[0]" mode="scaleToFill" class="image"></image>
								<view class="content">
									<view class="name">{{ product.foodName }}<text class="rec" v-if="product.recommend">推荐</text></view>
									<view class="labels">
										<view class="label"
											:style="{color: label.label_color, background: $util.hexToRgba(label.label_color, 0.2)}"
											v-for="label in product.labels" :key="label.id">{{ label.name }}</view>
									</view>
									<view class="description">{{ product.foodDetail }}</view>
									<view class="price">
										<view>￥{{ product.foodPrice }}</view>
										<actions :materials-btn="product.isSingle!=0"
											@materials="showProductDetailModal(product)"
											:number="productCartNum(product.foodId)" @add="handleAddToCart(product)"
											@minus="handleMinusFromCart(product)" />
									</view>
								</view>
							</view>
						</view>
					</view>
					<!-- 商品 end -->
				</view>
			</scroll-view>
			<!-- 右侧商品列表 end -->
		</view>
		<!-- 商品详情 modal begin -->
		<product-modal ref="ProductModal" :product="product" :url="url" :visible="productModalVisible" @cancel="closeProductDetailModal"
			@add-to-cart="handleAddToCartInModal" />
		<!-- 商品详情 modal end -->
		<!-- 购物车栏 begin -->
		<cart-bar :cart="cart" @add="handleAddToCart" @minus="handleMinusFromCart" @clear="clearCart" @pay="pay" />
		<!-- 购物车栏 end -->
		<search :show="showSearch" :categories="categories" @hide="showSearch=false" @choose="showProductDetailModal"
			:hotSearch="hotSearch" :historySearch="historySearch"></search>
	</view>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex'
	import Actions from './components/actions/actions.vue'
	import CartBar from './components/cartbar/cartbar.vue'
	import ProductModal from './components/product-modal/product-modal.vue'
	import cartPopup from './components/cart-popup/cart-popup.vue'
	import Search from './components/search/search.vue'
	import desk from './components/desk/desk.vue'

	export default {
		components: {
			Actions,
			CartBar,
			ProductModal,
			cartPopup,
			Search,
			desk
		},
		data() {
			return {
				categories: [],
				cart: [],
				product: {},
				currentCategoryId: 1,
				notices: [],
				ads1: [
					"/static/images/ads/aa.png",
					"/static/images/ads/bb.png",
				],
				ads2: [
					"/static/images/ads/cc.png",
					"/static/images/ads/ee.png",
				],
				productModalVisible: false,
				cartPopupShow: false,
				productsScrollTop: 0,
				showSearch: false,
				url: "",
				historySearch: [],
				hotSearch: ["鱼香肉丝"],
				deskId: 0,
				deskvisible:true,
				isTakein:true,
				recommendation:[]
			}
		},
		computed: {
			...mapState(['orderType', 'address']),
			productCartNum() {	//计算单个菜品添加到购物车的数量
				return id => this.cart.reduce((acc, cur) => {
						if(cur.foodId == id) {
							return acc += cur.number
						}
						return acc
					}, 0)
			}
		},
		onLoad(e) {
			this.deskvisible=uni.getStorageSync("deskId")==""?true:false;
			this.deskId = uni.getStorageSync("deskId")||0;
			this.url = this.$url;
			this.notices = this.$api('notices');
			this.getFoods();
		},
		methods: {
			closeDesk(){
				this.deskvisible=false;
			},
			getDesk(e){
				console.log(e)
				this.deskId=e;
				uni.setStorageSync("deskId",e);
				this.deskvisible=false;
			},
			getFoods() {
				this.$request({
					url: "/food/allfood"
				}).then(res => {
					if (res.code == 200) {
						let arr = res.data;
						console.log(arr);
						this.categories = arr;
						// for(let i=0;i<this.categories.length;i++){
						// 	for(let j=0;j<this.categories[i].items.length;j++){
						// 		if(this.categories[i].items[j].isSingle!=0){
						// 			for(let k=0;k<this.categories[i].items[j].spcf.length;k++){
						// 				// this.$set(this.categories[i].items[j].spcf[k].chose[0],
						// 				// 'is_selected',1);
						// 			}
						// 		}
						// 	}
						// }
						this.$nextTick(() => this.calcSize());
						this.simCommend();
						this.newCommend();
					}
				})
			},
			handleChooseDesk(){
				console.log(this.deskvisible)
				this.deskvisible=true;
				console.log(this.deskvisible)
			},
			handleSearch() {
				this.historySearch = uni.getStorageSync("his") || [];
				this.showSearch = true;
			},
			...mapMutations(['SET_ORDER_TYPE']),
			switchOrderType() {
				if (this.orderType === 'takein') {
					uni.navigateTo({
						url: '/pages/addresses/addresses'
					})
				} else {
					this.SET_ORDER_TYPE('takein');
				}
			},
			handleAddToCart(product) { //添加到购物车
			// console.log(this.cart);
				const index = this.cart.findIndex(item => {
					if (!product.isSingle) {
						return item.foodId == product.foodId
					} else {
						return item.foodId == product.foodId&& (item.materials_text == product.materials_text)
					}
				})
				if (index > -1) {
					this.cart[index].number += (product.number || 1)
					console.log(this.cart);
					return
				}
				
				this.cart.push({
					foodId: product.foodId,
					foodtypeId: product.foodtypeId,
					foodName: product.foodName,
					foodPrice: product.foodPrice,
					number: product.number || 1,
					foodImg: product.foodImgs[0],
					spciIds:product.spciIds,
					materials_text: product.materials_text,
					isSingle: product.isSingle
				})
				console.log("qqq3");
			},
			handleMinusFromCart(product) { //从购物车减商品
				let index
				if (!product.isSingle) {
					index = this.cart.findIndex(item => item.foodId == product.foodId)
				} else {
					index = this.cart.findIndex(item => (item.foodId == product.foodId)&& (item.materials_text == product.materials_text))
				}
				this.cart[index].number -= 1
				if (this.cart[index].number <= 0) {
					this.cart.splice(index, 1)
				}
			},
			showProductDetailModal(product) {
				this.product = product
				this.productModalVisible = true
				
				//设置默认值
				for(let i=0;i<product.spcf.length;i++){
					this.$refs['ProductModal'].changeMaterialSelected(i,0);
				}
				
			},
			handleAddToCartInModal(product) {
				this.handleAddToCart(product)
				this.closeProductDetailModal()
			},
			closeProductDetailModal() {
				this.productModalVisible = false
				this.product = {}
			},
			openCartDetailsPopup() {
				this.$refs['cartPopup'].open()
			},
			clearCart() {
				this.cart = []
			},
			handleMenuSelected(id) {
				this.productsScrollTop = this.categories.find(item => item.foodtypeId == id).top
				this.$nextTick(() => this.currentCategoryId = id)
			},
			productsScroll({
				detail
			}) {
				const {
					scrollTop
				} = detail
				let tabs = this.categories.filter(item => item.top <= scrollTop).reverse()
				if (tabs.length > 0) {
					this.currentCategoryId = tabs[0].foodtypeId
				}
			},
			calcSize() {
				let h = 0
				let view = uni.createSelectorQuery().select('#ads')
				view.fields({
					size: true
				}, data => {
					h += Math.floor(data.height)
				}).exec()
				this.categories.forEach(item => {
					let view = uni.createSelectorQuery().select(`#products-${item.foodtypeId}`)
					view.fields({
						size: true
					}, data => {
						item.top = h
						h += Math.floor(data.height)
						item.bottom = h
					}).exec()
				})
			},
			pay() {
				uni.setStorageSync('cart', this.cart)
				uni.setStorageSync('orderType',this.orderType=='takein'?0:1);
				uni.navigateTo({
					url: '/pages/pay/pay'
				})
			},
			simCommend(){
				//相似推荐 协同过滤
				this.$request({
					url: "/food/recFood"
				}).then(res => {
					let arr=res.data;
					if(arr!=null&&arr.length>0){
						arr.forEach(item=>{
							if(this.categories!=null&&this.categories.length>0)
							this.categories.forEach(cate=>{
								if(cate!=null&&cate.items!=null&&cate.items.length>0)
								cate.items.forEach(food=>{
									if(item.foodId==food.foodId){
										this.$set(food,"recommend",true);
									}
								})
							})
						})
					}
				});
			},
			newCommend(){
				//新品推荐
				let set=false;
				this.categories.forEach(item=>{
					// console.log(item);;
					item.items.forEach(temp=>{
						let time =	new Date(temp.createTime.replace(/-/g, '/')).getTime(); 
						let now = new Date().getTime();
						// console.log(now)
						if(now-time<=864000000){//n天内的推荐
							if(!set){
								this.currentCategoryId=0;
								let obj={
									foodtypeId:0,
									foodtypeName:"新菜推荐",
									items:[],
									foddtypeImg:"/profile/upload/icon/me_icon_notification.png"
								};
								this.categories=[obj,...this.categories];
							}
							this.categories[0].items.push(temp);
						}
					})
				})
							
			}
		}
	}
</script>

<style lang="scss">
	@import './index.scss';
</style>
