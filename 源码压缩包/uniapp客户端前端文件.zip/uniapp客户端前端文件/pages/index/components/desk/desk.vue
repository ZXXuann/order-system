<template>
	<modal :show="visible" class="modal-form" custom padding="9rpx" radius="10rpx">
		<scroll-view scroll-y="true" style="height:290rpx">
			<button type="warn" @tap="$emit('closeDesk')">关闭</button>
			<button type="primary" v-for="item in desk" @click="handleDesk(item)">{{item}}号</button>
		</scroll-view>
	</modal>
</template>

<script>
	import Modal from '@/components/modal/modal.vue'
	import Actions from '../actions/actions.vue'
	
	export default {
		name: 'desk',
		components: {
			Modal,
			Actions
		},
		props: {
			visible: {
				type: Boolean,
				default: true
			},
			desk: {
				type: Array,
				default: () => [1,2,3,4,5,6,7,8,9]
			},
			url:{
				type:String,
				default:""
			}
		},
		data() {
			return {
				productData: {},
			}
		},
		watch: {
			product(val) {
				this.productData = JSON.parse(JSON.stringify(val))
				this.$set(this.productData, 'number', 1)
			}
		},
		computed: {
		
		},
		methods: {
			handleDesk(e){
				this.$emit("change",e);
			}
		}
	}
</script>

<style lang="scss" scoped>
	.modal-form{
		display: flex;
		button {
			font-size:30rpx;
			border-radius: 10rpx;
			margin-left:10rpx;
			margin-top:10rpx;
			width:180rpx;
			height:80rpx;
			display: inline-block;
		}
	}
</style>
