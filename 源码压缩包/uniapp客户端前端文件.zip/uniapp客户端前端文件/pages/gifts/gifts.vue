<template>
	<view class="container">
		<swiper-item class="my-gift-cards-swiper">
			<view class="header">
				<view class="tab-bar-2">
					<view class="item" :class="{'active': currentTab2Index == 0}" @tap="handleTab2Change(0)">可使用</view>
					<view class="item" :class="{'active': currentTab2Index == 1}" @tap="handleTab2Change(1)">已过期</view>
				</view>
			</view>
			<view class="content">
				<swiper :duration="400" class="h-100" :current="currentTab2Index"
					@change="e => handleTab2Change(e.detail.current)">
					<swiper-item>
						<view class="packet-form" v-if="discount!=null">
							<uni-card v-for="(item,index) in discount" :title="item.discountTitle"
								:extra="item.discountAccount+'元'" :sub-title="'截止时间:'+item.validate"
								:thumbnail="item.discountType==0?'/static/images/card/redpacket.png':'/static/images/card/discount.png'">
								<text style="font-size:20rpx;display: block;">{{item.discountDetail}}</text>
								<text v-if="item.discountCondition!=0"
									style="font-size:20rpx;display: block;">满{{item.discountCondition}}元-{{item.discountAccount}}元</text>
							</uni-card>
						</view>
						<view class="h-100 d-flex flex-column align-items-center" v-else>
							<template>
								<image src="/static/images/my/img_giftcard_empty.png" class="giftcard-empty-img">
								</image>
								<view class="tips" style="margin: 50rpx 0;">暂无红包卡券</view>
								<button type="primary" class="font-size-lg" style="padding: 0 80rpx;" @tap="handleGo()">
									立即吃饭获取卡券
								</button>
							</template>
						</view>
					</swiper-item>
					<swiper-item>
						<view class="h-100 d-flex flex-column align-items-center">
							<view class="packet-form" v-if="novalidate!=null">
								<uni-card v-for="(item,index) in novalidate" :title="item.discountTitle"
									:extra="item.discountAccount+'元'" :sub-title="'截止时间:'+item.validate"
									:thumbnail="item.discountType==0?'/static/images/card/redpacket.png':'/static/images/card/discount.png'">
									<text style="font-size:20rpx;display: block;">{{item.discountDetail}}</text>
									<text v-if="item.discountCondition!=0"
										style="font-size:20rpx;display: block;">满{{item.discountCondition}}元-{{item.discountAccount}}元</text>
								</uni-card>
							</view>
							<template v-else>
								<image src="/static/images/my/img_giftcard_empty.png" class="giftcard-empty-img">
								</image>
								<view class="tips" style="margin: 50rpx 0;">暂无红包卡券</view>
							</template>
						</view>
					</swiper-item>
				</swiper>
			</view>
		</swiper-item>
	</view>
</template>

<script>
	import CardPopup from './components/CardPopup.vue'

	export default {
		data() {
			return {
				giftCards: [],
				currentTab2Index: 0,
				myGiftCards: [],
				product: {},
				per: 1,
				discount: [],
				novalidate: []
			}
		},
		onLoad() {
			this.getDiscount();
			this.getNoValidate();
		},
		onReachBottom() {
			if (this.isStart) {
				this.per++;
				this.getRateList();
			}
		},
		computed: {
			MyCanUseGiftCards() {
				return this.myGiftCards.filter(item => item.status == 1)
			},
			myInactiveGiftCards() {
				return this.myGiftCards.filter(item => item.status == 0)
			}
		},
		methods: {
			getNoValidate() {
				this.$request({
					url: "/discount/novalidatediscountinfo?pageNum=" + this.per
				}).then(res => {
					if (res.code == 200) {
						let arr = res.data;
						if (arr == null || arr.length == 0) {
							this.isStart = false;
							return;
						}
						console.log(res);
						this.novalidate.push(...arr);
					}
				})
			},
			getDiscount() {
				this.$request({
					url: "/discount/discountinfo?pageNum=" + this.per
				}).then(res => {
					if (res.code == 200) {
						let arr = res.data;
						if (arr == null || arr.length == 0) {
							this.isStart = false;
							return;
						}
						console.log(res);
						this.discount.push(...arr);
					}
				})
			},
			handleTab2Change(index) {
				this.currentTab2Index = index
			},
			handleGo() {
				uni.switchTab({
					url: "/pages/index/index"
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.tab-bar {
		z-index: 10;
		background-color: #FFFFFF;
		position: fixed;
		top: 0;
		/* #ifdef H5 */
		top: var(--window-top);
		/* #endif */
		width: 100%;
		height: 100rpx;
		color: $text-color-grey;
		font-size: $font-size-lg;
		display: flex;
		align-items: stretch;
		justify-content: space-evenly;

		.item {
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: center;
			position: relative;

			&.active {
				color: $text-color-base;

				&:after {
					content: ' ';
					position: absolute;
					bottom: 0;
					width: 30%;
					left: 35%;
					height: 6rpx;
					background-color: $color-primary;
				}
			}
		}
	}

	.tab-panes {
		padding-top: 100rpx;
		height: 100%;
		overflow-y: scroll;
	}

	.gift-cards {
		margin-bottom: 80rpx;
	}

	.category-list {
		.header {
			padding: 30rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.title {
				font-size: $font-size-lg;
				color: $text-color-base;
				font-weight: 700 !important;
			}

			.more {
				display: flex;
				align-items: center;
				font-size: $font-size-sm;
				color: $text-color-assist;

				image {
					width: 20rpx;
					height: 32rpx;
				}
			}
		}

		.product-list {
			padding-left: 30rpx;
			height: 270rpx;

			.product {

				.product-image {
					border-radius: $border-radius-lg;
					width: 447rpx;
					height: 260rpx;
					box-shadow: 0 0 20rpx 0 rgba($color: $border-color, $alpha: 0.6);
				}
			}
		}
	}

	.bottom {
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: $font-size-sm;
		color: $text-color-assist;
		padding: 30rpx 0;

		.divider {
			width: 2rpx;
			background-color: $text-color-assist;
			height: 0.6rem;
			margin: 0 40rpx;
		}
	}

	.my-gift-cards-swiper {
		display: flex;
		flex-direction: column;

		.header {
			display: flex;
			justify-content: space-between;
			padding: 20rpx 30rpx;
			align-items: center;

			.tab-bar-2 {
				display: flex;
				align-items: center;

				.item {
					padding: 10rpx 30rpx;
					font-size: $font-size-base;
					color: $text-color-assist;
					font-weight: 700 !important;

					&.active {
						background-color: #FFFFFF;
						color: $color-primary;
					}
				}
			}

			.right {
				display: flex;
				align-items: center;
				color: $color-primary;
				font-size: $font-size-base;

				image {
					width: 34rpx;
					height: 28rpx;
					margin-right: 10rpx;
				}
			}
		}

		.content {
			flex: 1;

		}
	}

	.giftcard-empty-img {
		margin-top: 100rpx;
		width: 438rpx;
		height: 291rpx;
	}
</style>
