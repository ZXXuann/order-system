<template>
	<view>
		<image src="https://static.heytea.com/taro_trial/v1/img/my/img_gift_card_banner.png?timestamp=1590337385420"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
