<template>
	<view class="container">
		<view class="brand">
			<image
				src="https://wx.qlogo.cn/mmopen/vi_32/vM0qx5z4BQUQU4icZNct8Oib0Q0ypMW6hdhejkBxrTzibvYHtdyaQI85hsWvL6PoA3ic3Jjwn99YdfxEj1ib7gvaJeQ/132"
				class="avatar"></image>
			<view class="username">{{form.nickname}}</view>
		</view>
		<view class="user-form">
			<list-cell line-right padding="30rpx">
				<view class="form-item">
					<view class="label">新密码</view>
					<input type="safe-password" :password="showPwd" v-model="form.password" />
				</view>
			</list-cell>
			<list-cell line-right padding="30rpx">
				<view class="form-item">
					<view class="label">二次确认</view>
					<input type="safe-password" :password="showPwd" v-model="form.secPassword" />
					<!-- <button type="default" plain class="font-size-sm" @tap="showTelphoneModal">更换手机</button> -->
				</view>
			</list-cell>
			
				<view class="showpsd" @click="showPasswd">{{showPwd?'查看密码':"隐藏密码"}}</view>
			
		</view>
		<view class="save-btn">
			<button type="info" @click="updCustomer">保存</button>
		</view>
		</view>
</template>

<script>
	import listCell from '@/components/list-cell/list-cell.vue'
	import modal from '@/components/modal/modal.vue'

	export default {
		components: {
			listCell,
			modal
		},
		data() {
			return {
				showPwd:true,
				form: {},
				uploadForm: {},
				sex:0,
				rules: {
					password: {
						rule: /^[0-9a-zA-Z]{1,16}$/,
						msg: "密码应该为1-16位"
					},
					secPassword: {
						rule: /^[0-9a-zA-Z]{1,16}$/,
						msg: "密码应该为1-16位"
					}
				},
			}
		},
		methods: {
			showPasswd(){
				this.showPwd=!this.showPwd;
			},
			validPass(){
				if(this.form.password!=this.form.secPassword){
					uni.showToast({
						title:'两次密码不同',
						icon:'none'
					})
					return false;
				}
				return true;
			},
			validate(key){
				let bool=true;
				if(!this.rules[key].rule.test(this.form[key])){
					//提示信息
					uni.showToast({
						title:this.rules[key].msg,
						icon:'none'
					})
					//取反
					bool=false;
					return false;
				}
				return bool;
			},
			updCustomer() {
				if(!this.validate('password')) return;
				if(!this.validPass()) return;
				this.uploadForm.customerPasswd = this.form.password;
				uni.showLoading({
					title: "保存中..."
				})
				uni.request({
					url: this.$url + "/customer/updPwd",
					header: {
						token: uni.getStorageSync("token"),
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: this.uploadForm,
					method: "POST",
					success: res => {
						console.log(this.form)
						console.log(res)
						uni.hideLoading();
						if (res.data.code == 200) {
							uni.showToast({
								title: "修改成功...",
							});
							uni.removeStorageSync('token');
							uni.navigateTo({
								url: '/pages/login/login'
							});
						} else
							uni.showToast({
								title: "修改失败..."
							});
						// console.log(this.swipers);
					},
					fail: res => {
						uni.hideLoading();
						uni.showToast({
							title: "操作失败..."
						});
					}
				})
			},
			handleBirthdayChange({
				target: {
					value
				}
			}) {
				this.form.birthday = value
			},
			showTelphoneModal() {
				this.telphoneModalVisible = true
			},
			closeTelphoneModal() {
				this.telphoneModalVisible = false
				this.telphoneForm = this.$options.data().telphoneForm
			},
			getVerifyCode() {
				if (this.countdown) return

				if (!this.telphoneForm.telphone) {
					uni.showToast({
						title: '请填写手机号码',
						icon: 'none'
					})
					return
				}

				this.countdown = 60
				let interval = setInterval(() => {
					if (!this.countdown) {
						clearInterval(interval)
						return
					}
					this.countdown -= 1
				}, 1000)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.brand {
		background-color: $bg-color-white;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding: 40rpx 0;
		margin-bottom: 20rpx;

		.avatar {
			width: 200rpx;
			height: 200rpx;
			border-radius: 100%;
			margin-bottom: 30rpx;
		}

		.username {
			color: $font-size-medium;
			font-weight: bold;
		}
	}
	.showpsd{
		display:block;
		text-align:center;
		line-height:100rpx;
		height:100rpx;
		width:750rpx;
	}
	.user-form {
		.form-item {
			width: 100%;
			display: flex;
			align-items: center;

			.label {
				width: 160rpx;
			}

			input {
				flex: 1;
			}

			.radio {
				display: flex;
				margin-right: 50rpx;

				image {
					width: 40rpx;
					height: 40rpx;
					margin-right: 20rpx;
				}
			}
		}
	}

	.save-btn {
		padding: 0 30rpx;
		margin-top: 60rpx;

		button {
			width: 100%;
			font-size: $font-size-extra-lg;
		}
	}

	.telphone-modal {
		.header {
			display: flex;
			align-items: center;
			justify-content: center;
			position: relative;
			font-size: $font-size-extra-lg;
			font-weight: bold;
			margin-bottom: 30rpx;

			.close-icon {
				width: 60rpx;
				height: 60rpx;
				position: absolute;
				right: 0;
			}
		}

		.tips {
			color: $text-color-grey;
			line-height: 1.2rem;
			margin-bottom: 50rpx;
		}

		.telphone-form {
			font-size: $font-size-base;

			.telphone-input {
				width: 100%;
				display: flex;
				align-items: center;

				.prefix {
					color: $color-primary;
					display: flex;
					align-items: center;
					padding-right: 20rpx;
					position: relative;
					margin-right: 10rpx;

					&::after {
						content: " ";
						position: absolute;
						width: 4rpx;
						background-color: $border-color;
					}
				}

				input {
					flex: 1;
				}
			}

			.verfiycode-input {
				width: 100%;
				display: flex;
				align-items: center;
				justify-content: space-between;

				.countdown {
					font-size: $font-size-base;
				}
			}
		}

		.footer {
			margin-top: 30rpx;

			button {
				font-size: $font-size-lg;
			}
		}
	}
</style>
