<template>
	<view class="media-container">
		<view class="rate-form" v-for="(item,index) in foods">
			<text>{{item.foodName}}: </text><uni-rate v-model="item.score" @change="handleChange" />
		</view>
		<view class="content">
			<textarea class="text-form" placeholder="请对此评价" v-model="scoreDetail"></textarea>
		</view>
		<jade-image-upload
		class="img"
		 :list="media"
		 :control="control"
		 :columnType="columnType"
		 :maxCount="maxCount"
		 :compressSize="compressSize"
		 :compressQuality="compressQuality"
		 :compressWidth='compressWidth'
		 :imageSize="imageSize"
		 @chooseFile="chooseFile"
		 @imgDelete="mediaDelete">
		</jade-image-upload>
		<view class="btn-form">
			<button type="primary" @click="handlePost">发布</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				control: true,
				columnType: 'other',
				maxCount: 6,
				compressSize: 0.2,
				imageSize: 2,
				compressQuality: 0.8,
				compressWidth: 375,
				main:"",
				uploadTask: null,
				media: [], //数据源
				srclist:[],
				orderId:0,
				customerId:1,
				score:5,
				scoreDetail:"",
				foods:[]
			};
		},
		onLoad(e){
			this.orderId=e.orderId;
			this.getOrderDetail();
		},
		methods: {
			//获取订单内容
			getOrderDetail(){
				this.$request({url:"/order/detail/list?orderId="+this.orderId}).then(res=>{
					if(res.code==200){
						let arr=res.data;
						console.log(arr.items);
						arr.items.forEach(item=>{
							// this.$set(item,"score",5);
							let obj={
								foodId:item.foodId,
								foodName:item.foodName,
								orderId:item.orderId,
								score:5
							}
							this.foods.push(obj);
						})
					}
				})
			},
			//上传
			chooseFile(e) {
				this.uploadFileToServe(e)
			},
			//中断上传并删除
			mediaDelete(e) {
				this.uploadTask ? this.uploadTask.abort() : ''
				this.media.splice(e,1)
			},
			handleChange(e){
				console.log(e)
			},
			handlePost(){
				let obj={
					orderId:this.orderId,
					customerId:this.customerId,
					singleScore:[],
					scoreDetail:this.scoreDetail,
					scoreImg:this.srclist.join(",")
				}
				this.foods.forEach(item=>{
					let temp={
					customerId:item.customerId,
					foodId:item.foodId,
					score:item.score,
					orderId:item.orderId,
					};
					obj.singleScore.push(temp);
				})
				console.log(this.foods)
				this.$request({
					url:"/anms/updateRate",
					data:obj,
					method:"post",
					contentType: "application/json",
					}).then(res=>{
						console.log(res);
						if(res.code==200){
							uni.switchTab({
								url:"/pages/order/order"
							});
							uni.showToast({
								icon:'success',
								title:'操作成功'
							});
						}
				})
			},
			//上传逻辑处理
			uploadFileToServe(urlList) {
				if (!urlList || urlList.length <= 0) {
					return
				};
				urlList.forEach((item) => {
						this.uploadTask = uni.uploadFile({
							url: this.$url+'/anms/upload', 
							filePath: item.src,
							name: 'file',
							success: (res) => {
								let data = JSON.parse(res.data) 
								console.log(data)
									item.status = 'error'
									item.progress = '上传失败'
									
									item.status = 'success'
									item.progress = '上传成功'
									item.src=this.$url+data.data[0].filepath;
									this.srclist=[...this.srclist,data.data[0].filepath];
							}
						});
						this.uploadTask.onProgressUpdate((res) => {
							item.percent = res.progress
							this.media.splice(item.index,1,item)
						})
					})
				}
		}
	}
</script>

<style lang="scss" scoped>
	.media-container {
		padding: 30rpx 26rpx;
		box-sizing: border-box;
		.btn-form{
			padding-top:20rpx;
		}
		.rate-form{
			padding-bottom:30rpx ;
			display: flex;
			text{
				display:block;
				padding-top:10rpx;
				font-size: 35rpx;
				padding-right: 20rpx;
			}
			
		}
		.img{
			/deep/ image{
				border:1px solid #c6c6c6;
			}
			
		}
		.content{
			.text-form{
				border-top:1px solid #e7e7e7;
				padding-top: 20rpx;
				font-size: 20rpx;
				margin-bottom: 20rpx;
			}
		}
	}
	
</style>
