<template>
	<view class="content">
		<uni-card class="card-form" v-for="(item,index) in ratelist"  :extra="item.createTime" :title="item.customerName" :isFull="true" 
			:sub-title="'评分:'+item.score+'星'" thumbnail="/static/images/mall/img_pointmall_star.png">
			<text class="uni-body">{{item.scoreDetail}}</text>
			<view class="img-form" v-if="item.scoreImgs!=undefined&&item.scoreImgs.length!=0&&item.scoreImgs[0]!=''">
				<image mode="aspectFill" class="lit-img" v-for="(img,index) in item.scoreImgs" :src="url+img"
					@click="previewImage(item.scoreImgs,index)"
					></image>
			</view>
		</uni-card>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				extraIcon: {
					color: '#4cd964',
					size: '22',
					type: 'gear-filled'
				},
				url: this.$url,
				ratelist: [],
				per:1,
				isStart:true
			}
		},
		onLoad() {
			this.getRateList();
		},
		onReachBottom(){
			if(this.isStart){
				this.per++;
				this.getRateList();
			}
		},
		methods: {
			getRateList() {
				this.$request({
					url: "/anms/rateinfo?pageNum="+this.per
				}).then(res => {
					if (res.code == 200) {
						let arr = res.data;
						if(arr==null||arr.length==0){
							this.isStart=false;
							return;
						}
						console.log(res);
						this.ratelist.push(...arr);
					}
				})
			},
			previewImage(val, index) { // index 索引 如果 需要复用方法 可以使用 类型来进行区分(val)
				// var photoList = val.map(item => { // item 获取到的图片地址
				// 	return item;
				// });
				// console.log(val);
				let arr = val;
				let temp = [];
				arr.forEach(item => {
					temp.push(this.$url + item);
				})
				console.log(temp)
				uni.previewImage({
					current: index, // 当前显示图片的索引值
					urls: temp, // 需要预览的图片列表，要求必须是数组
					loop: true, // 是否可循环预览
				})
			}
		}
	}
</script>

<style lang="scss">
	.content {
		.card-form {
			padding-bottom: 30rpx !important;
			text {
				display: block;
				font-size: 30rpx;
			}

			.img-form {
				display: block;
				padding-top: 30rpx;

				.lit-img {
					// border:1px solid #c6c6c6;
					border-radius: 15rpx;
					float: left;
					display: block;
					width: 210rpx;
					margin-right: 10rpx;
					height: 210rpx;
					margin-bottom: 10rpx;
				}
			}
		}
	}
</style>
