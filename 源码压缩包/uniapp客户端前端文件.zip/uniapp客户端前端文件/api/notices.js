export default [{
		"id": 10,
		"content": "多肉车厘回归，精选当季山东樱桃，颗颗手工去核，入茶清甜消暑，快来下单尝鲜吧~",
		"image_id": 114210,
		"image": "https://go.cdn.heytea.com/2020/02/26/tmp/f5d557b627b640838d0c324bd96eabfb.jpg"
	},
	{
		"id": 7,
		"content": "太妃焦糖爆米花全新上市，焦香十足，美味易爆，快来「喜茶食验室」下单尝鲜吧~",
		"image_id": 104726,
		"image": "https://go.cdn.heytea.com/2020/01/09/tmp/3f393edea5094c1d8f8b524610caa531.jpg"
	}
]
