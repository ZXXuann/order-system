export default [
    {
        "id": 53,
        "postId": 48,
        "no": "BB20200525152258",
        "sort": 1,
        "type": 1,
        "contentType": 1,
        "title": "兔年兔礼，现正预售中",
        "subtitle": "2023兔年礼盒",
        "coverPic": "https://go.cdn.heytea.com/storage/products/2020/05/25/d7f9a7e9ea3747778d301b443147cd82.png",
        "imageTextContent": null,
        "redirectContent": {
            "redirectType": 1,
            "name": null,
            "path": "https://mp.weixin.qq.com/s/eWEMnvHNtOEup-hzE38r8Q",
            "appId": null
        }
    },
    {
        "id": 54,
        "postId": 49,
        "no": "BB20200525152844",
        "sort": 2,
        "type": 1,
        "contentType": 1,
        "title": "兔年two倍红包",
        "subtitle": "恭喜发财,红包two倍来",
        "coverPic": "https://go.cdn.heytea.com/storage/products/2020/05/25/0346c403e88243eaa76aa334097ad8ec.png",
        "imageTextContent": null,
        "redirectContent": {
            "redirectType": 1,
            "name": null,
            "path": "https://mp.weixin.qq.com/s/AaMBCLliMla5ktAVF5TGSA",
            "appId": null
        }
    },
    {
        "id": 50,
        "postId": 45,
        "no": "BB20200508143203",
        "sort": 3,
        "type": 1,
        "contentType": 1,
        "title": "点餐平台升级啦",
        "subtitle": "点击了解升级详情",
        "coverPic": "https://go.cdn.heytea.com/storage/products/2020/05/08/0a11147144ff42629e6eca9eeec53215.png",
        "imageTextContent": null,
        "redirectContent": {
            "redirectType": 0,
            "name": null,
            "path": "pages/member/upgrade_publicity/index",
            "appId": null
        }
    }
]
