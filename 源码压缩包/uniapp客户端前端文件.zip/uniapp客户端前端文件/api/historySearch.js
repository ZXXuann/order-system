export default [{
	"productName": "芝芝莓莓 ®",
	"productId": 932,
	"type": 1,
	"images": [{
		"id": 156414,
		"url": "https://go.cdn.heytea.com/storage/product/2020/06/01/0080e20b3cca4d85ac19db53163aa138.jpg"
	}, {
		"id": 154137,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/27/01ab97ed6518438ebdca8683c059b94c.jpg"
	}],
	"nameImage": "",
	"showTrademark": false
}]
