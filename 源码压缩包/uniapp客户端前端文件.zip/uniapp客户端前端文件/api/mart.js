export default [
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/f3a26c6ce9594b1e97324c82798f6c71.png",
        "id": 308158,
        "itemNo": "5875254410113816001",
        "itemStock": 629,
        "name": "芝芝果茶系列 喜茶xCONTIGO联名芝芝/波波吸管杯",
        "itemSalesVolume": 5734,
        "salePrice": 14800,
        "labelPrice": 14800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/1f2a67c624a7451d968e9e4b03954219.png",
        "id": 308157,
        "itemNo": "5875248837678562001",
        "itemStock": 52,
        "name": "芝芝果茶系列 芝芝/波波玻璃杯",
        "itemSalesVolume": 2784,
        "salePrice": 3800,
        "labelPrice": 3800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/144c0c63c6974c31aed91115880e0f2f.png",
        "id": 308145,
        "itemNo": "5873948140577130001",
        "itemStock": 36,
        "name": "夫子来喜 茶礼盒",
        "itemSalesVolume": 102,
        "salePrice": 6800,
        "labelPrice": 6800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/33877cdc294b4f53b6d354a811b70e98.png",
        "id": 308160,
        "itemNo": "5889961614260412001",
        "itemStock": 1098,
        "name": "太妃焦糖味 爆米花 60gX3袋",
        "itemSalesVolume": 1517,
        "salePrice": 3600,
        "labelPrice": 3600
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/4bf0414775c44eca829aa5242d459a05.png",
        "id": 308159,
        "itemNo": "5878654210726418001",
        "itemStock": 637,
        "name": "灵感一周茶礼盒 7款喜茶经典茗茶袋泡茶",
        "itemSalesVolume": 1848,
        "salePrice": 4800,
        "labelPrice": 4800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/d3630bd4bc854938a8169c420f3a6849.jpg",
        "id": 308156,
        "itemNo": "5875245257658433001",
        "itemStock": 763,
        "name": "混坚果3口味 2盒装 芥末味/海苔味/麻辣火锅味",
        "itemSalesVolume": 2082,
        "salePrice": 6000,
        "labelPrice": 6000
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/edc8203bfaab4cb19caf01e168acecf1.png",
        "id": 308152,
        "itemNo": "5874582768671687001",
        "itemStock": 77,
        "name": "广州限定搪瓷杯",
        "itemSalesVolume": 370,
        "salePrice": 8400,
        "labelPrice": 8400
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/73ef887855c74af09702b635d1464973.png",
        "id": 308153,
        "itemNo": "5874584305257205001",
        "itemStock": 35,
        "name": "广州限定帆布袋",
        "itemSalesVolume": 311,
        "salePrice": 5800,
        "labelPrice": 5800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/d58efe491b54453bb86757ad71e1a725.png",
        "id": 308154,
        "itemNo": "5874586879833837001",
        "itemStock": 187,
        "name": "广州限定皮质手机壳",
        "itemSalesVolume": 142,
        "salePrice": 7200,
        "labelPrice": 7200
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/b99765b790b842fba62f087e156f6c6b.png",
        "id": 308155,
        "itemNo": "5874589128570809001",
        "itemStock": 71,
        "name": "广州限定钥匙扣",
        "itemSalesVolume": 141,
        "salePrice": 3800,
        "labelPrice": 3800
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/81cf385b26fe48d7971b81bedf4a28e3.png",
        "id": 308135,
        "itemNo": "5871100589448027001",
        "itemStock": 567,
        "name": "喜茶WonderLab联名礼盒 饱腹食品代餐奶昔6瓶",
        "itemSalesVolume": 1245,
        "salePrice": 13900,
        "labelPrice": 15900
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/7e8f188bef8f48eea2a208970be59153.png",
        "id": 308142,
        "itemNo": "5871327666758468001",
        "itemStock": 6814,
        "name": "喜茶饼家夹心小方",
        "itemSalesVolume": 1797,
        "salePrice": 4500,
        "labelPrice": 4500
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/28a63bbd2bf6467790d39f4ed9274ec1.png",
        "id": 308129,
        "itemNo": "5858321915470775001",
        "itemStock": 212,
        "name": "灵感魔都手机壳",
        "itemSalesVolume": 227,
        "salePrice": 2900,
        "labelPrice": 2900
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/ce87ab4bf1bd4dd8b2249fc4bc228baf.png",
        "id": 308130,
        "itemNo": "5858325640508027001",
        "itemStock": 66,
        "name": "灵感魔都帆布袋",
        "itemSalesVolume": 200,
        "salePrice": 3900,
        "labelPrice": 3900
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/0f178944c5db4cf3a76489010c0f24d0.png",
        "id": 308132,
        "itemNo": "5858332808611918001",
        "itemStock": 0,
        "name": "灵感魔都小男巫钥匙扣",
        "itemSalesVolume": 168,
        "salePrice": 2900,
        "labelPrice": 2900
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/17198929f7e7409aadf8930e492770bb.png",
        "id": 308131,
        "itemNo": "5858330358639234001",
        "itemStock": 0,
        "name": "灵感魔都冰箱贴",
        "itemSalesVolume": 334,
        "salePrice": 2500,
        "labelPrice": 2500
    },
    {
        "thumbnail": "https://prod-mall-cos-1252929494.cos.ap-guangzhou.myqcloud.com/db26492cad3b40afbfe819c39df5ee58.png",
        "id": 308133,
        "itemNo": "5858334811291675001",
        "itemStock": 0,
        "name": "灵感魔都AirPods Case",
        "itemSalesVolume": 273,
        "salePrice": 2900,
        "labelPrice": 2900
    }
]
