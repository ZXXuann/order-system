export default [{
	"id": 73600008,
	"scoreChange": 1,
	"method": 7,
	"description": "会员任务领取_每日签到（奖励随机翻倍）",
	"createAt": "2020-05-30 00:41:48",
	"sourceType": null,
	"orderNo": null,
	"payment": null,
	"shopName": null,
	"client": 1
}, {
	"id": 73600007,
	"scoreChange": 10,
	"method": 7,
	"description": "会员任务领取_完善个人资料",
	"createAt": "2020-05-30 00:41:45",
	"sourceType": null,
	"orderNo": null,
	"payment": null,
	"shopName": null,
	"client": 1
}, {
	"id": 70873226,
	"scoreChange": 1,
	"method": 7,
	"description": "会员任务领取_每日签到（奖励随机翻倍）",
	"createAt": "2020-05-16 08:27:21",
	"sourceType": null,
	"orderNo": null,
	"payment": null,
	"shopName": null,
	"client": 1
}, {
	"id": 54302375,
	"scoreChange": 25,
	"method": 1,
	"description": "消费获得_微信小程序下单",
	"createAt": "2020-01-18 18:05:53",
	"sourceType": "App\\Models\\Order",
	"orderNo": "755067202001181805428749",
	"payment": "50.00",
	"shopName": "益田假日天地GO店",
	"client": 1
}, {
	"id": 42968209,
	"scoreChange": 5,
	"method": 1,
	"description": "购买 流沙牛角 等1件商品",
	"createAt": "2019-11-06 19:36:12",
	"sourceType": "App\\Models\\Order",
	"orderNo": "755067201911061936067634",
	"payment": "10.00",
	"shopName": "益田假日天地GO店",
	"client": 1
}, {
	"id": 42967480,
	"scoreChange": 14,
	"method": 1,
	"description": "购买 捣蛋南瓜波波冰 等1件商品",
	"createAt": "2019-11-06 19:32:12",
	"sourceType": "App\\Models\\Order",
	"orderNo": "755067201911061932051220",
	"payment": "28.00",
	"shopName": "益田假日天地GO店",
	"client": 1
}, {
	"id": 40618359,
	"scoreChange": 2,
	"method": 7,
	"description": "每日签到（奖励随机翻倍）",
	"createAt": "2019-10-21 15:16:17",
	"sourceType": null,
	"orderNo": null,
	"payment": null,
	"shopName": null,
	"client": 1
}, {
	"id": 40415803,
	"scoreChange": 16,
	"method": 1,
	"description": "购买 流沙牛角 等2件商品",
	"createAt": "2019-10-20 12:29:30",
	"sourceType": "App\\Models\\Order",
	"orderNo": "755015201910201229255435",
	"payment": "33.00",
	"shopName": "万象天地PINK店",
	"client": 1
}]
