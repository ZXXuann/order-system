export default [{
	"productName": "豆豆雪糕杯",
	"productId": 716,
	"type": 1,
	"images": [{
		"id": 156414,
		"url": "https://go.cdn.heytea.com/storage/product/2020/06/01/0080e20b3cca4d85ac19db53163aa138.jpg"
	}, {
		"id": 154137,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/27/01ab97ed6518438ebdca8683c059b94c.jpg"
	}],
	"nameImage": "",
	"showTrademark": false
}, {
	"productName": "芝芝莓莓 ®",
	"productId": 932,
	"type": 1,
	"images": [{
		"id": 156415,
		"url": "https://go.cdn.heytea.com/storage/product/2020/06/01/9cd1cc3f5c074d28b32af9e3e3a2cd14.jpg"
	}, {
		"id": 154138,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/27/0c83954c0d5547b4b1fe1650b9b317b0.jpg"
	}],
	"nameImage": "",
	"showTrademark": false
}, {
	"productName": "多肉芒芒甘露",
	"productId": 941,
	"type": 1,
	"images": [{
		"id": 155005,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/933b36506a8d450eb0f54f6b3c39d84f.jpg"
	}, {
		"id": 155006,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/cfafc3e1a8ad45f8a1aebf70e355ce28.jpg"
	}],
	"nameImage": "https://go.cdn.heytea.com/storage/product/2020/05/29/d3d7c45908a24863acc51893320cb177.jpg",
	"showTrademark": false
}, {
	"productName": "满杯红柚",
	"productId": 944,
	"type": 1,
	"images": [{
		"id": 155009,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/5648897812654a459ec7c70d4207acfb.jpg"
	}, {
		"id": 155010,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/35abcb9cee8c4f9c907e5190f2322531.jpg"
	}],
	"nameImage": "https://go.cdn.heytea.com/storage/product/2020/05/29/d865085468ed414e8d63b13593d2aabc.jpg",
	"showTrademark": false
}, {
	"productName": "多肉葡萄",
	"productId": 931,
	"type": 2,
	"images": [{
		"id": 154995,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/92a953a3ffaf4ce6bb29beb54efc0b5d.jpg"
	}, {
		"id": 117059,
		"url": "https://go.cdn.heytea.com/storage/product/2020/03/04/132420629a0d4fe78e2a164e3f1c44b7.jpg"
	}],
	"nameImage": "https://go.cdn.heytea.com/storage/product/2020/03/02/3aa66935a73f4b02ad78e591e1decabb.jpg",
	"showTrademark": false
}, {
	"productName": "多肉芒芒甘露",
	"productId": 941,
	"type": 2,
	"images": [{
		"id": 135047,
		"url": "https://go.cdn.heytea.com/storage/product/2020/04/15/44ed201701ef406087100b0c1690daad.jpg"
	}, {
		"id": 117036,
		"url": "https://go.cdn.heytea.com/storage/product/2020/03/04/de106edd904148f185f6273835be0baf.jpg"
	}],
	"nameImage": "",
	"showTrademark": false
}, {
	"productName": "多肉芒芒甘露",
	"productId": 901,
	"type": 2,
	"images": [{
		"id": 154996,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/29/fdd842483f664d73bcc04105a7b412a5.jpg"
	}, {
		"id": 143249,
		"url": "https://go.cdn.heytea.com/storage/product/2020/05/03/d6715484323c404086058c662ce3c8c8.jpg"
	}],
	"nameImage": "https://go.cdn.heytea.com/storage/product/2020/05/03/7c8d55f76d1240a196983d216d86e7ca.jpg",
	"showTrademark": false
}]
