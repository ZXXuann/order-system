export const BASE_URL="http://localhost:8088"
export const request=(options)=>{
	return new Promise((resolve,reject)=>{
	uni.request({
		url:BASE_URL+options.url,
		method:options.method||'GET',
		header:{
			token:uni.getStorageSync('token')?uni.getStorageSync('token'):'',
			'content-type': options.contentType||'application/x-www-form-urlencoded;charset=utf-8'
			},
		data:options.data||{},
		success:(res)=>{
			const data=res.data;
			if(data.code==401){
				console.log(res)
				uni.removeStorageSync('token');
				uni.redirectTo({
					url:'/pages/login/login'
				})
				return;
			}else if(data.code!=200){
				uni.showToast({
					icon:'error',
					title:'操作失败'
				})
			}
			resolve(data)
		},
		fail: (error) => {
			uni.showToast({
				icon:'error',
				title:'操作失败'
			})
			reject(error)
		}
	})
	}
	)
}