**特别声明：本项目中的展示图片归喜茶所有。**

### 源码地址

github地址: [https://github.com/tinypuppet/heytea](https://github.com/tinypuppet/heytea)

gitee地址：[https://gitee.com/tinypuppet/heytea](https://gitee.com/tinypuppet/heytea)

uni-app插件市场地址：[https://ext.dcloud.net.cn/plugin?id=1957](https://ext.dcloud.net.cn/plugin?id=1957)

### 简介

uniapp开发的一套仿喜茶GO小程序的前端模板（weapp + H5）（持续更新）。

**练手项目，仅供参考。**

如果你喜欢这套模板，请给个star。

### 个人说明

如有问题，请联系QQ或微信``327722714``。

### 说明

本项目包含：

- 首页
- 点单
- 喜茶百货
- 百货详情
- 历史订单
- 我的
- 积分商城
- 积分商城详情页
- 我的-微信一键登录
- 我的-成为星球会员
- 我的-个人资料
- 我的-钱包
- 我的-阿喜有礼
- 会员码
- 任务中心

### 展示效果

|点单|首页|百货|订单|我的|
|---|---|---|---|---|
|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/c7ab7d00-a62a-11ea-8698-3fa69385df82_0.jpg?v=1591251998)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/c7ab7d00-a62a-11ea-8698-3fa69385df82_1.jpg?v=1591251998)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/c7ab7d00-a62a-11ea-8698-3fa69385df82_2.jpg?v=1591251998)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/c7ab7d00-a62a-11ea-8698-3fa69385df82_3.jpg?v=1591251998)|![](https://img.cdn.aliyun.dcloud.net.cn/stream/plugin_screens/c7ab7d00-a62a-11ea-8698-3fa69385df82_4.jpg?v=1591251998)|
