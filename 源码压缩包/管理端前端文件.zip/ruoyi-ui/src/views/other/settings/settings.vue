<template>
  <div>
    <el-form ref="settings" :model="formData" :rules="rules" size="medium" label-width="100px">
      <el-form-item label="桌数" prop="field102">
        <el-input v-model="formData.deskNum" placeholder="请输入桌数" clearable :style="{width: '100%'}">
        </el-input>
      </el-form-item>
      <el-form-item size="large">
        <el-button type="primary" @click="submitForm">提交</el-button>
        <el-button @click="resetForm">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import {settings} from "@/api/other/settings";
export default {
  components: {},
  props: [],
  data() {
    return {
      formData: {
        deskNum: 10,
      },
      rules: {
        deskNum: [{
          required: true,
          message: '请输入桌数',
          trigger: 'blur'
        }],
      },
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    submitForm() {
      this.$refs['settings'].validate(valid => {
        if (!valid) return
          settings(this.formData).then(data=>{
            this.$modal.msgSuccess("新增成功");
          }).catch(error=>{
            this.$modal.msgError(error);
          })
      })
    },
    resetForm() {
      this.$refs['settings'].resetFields()
    },
  }
}

</script>
<style>
</style>
