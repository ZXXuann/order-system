<template>
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>聊天-{{userName}}</span>
      </div>
      <div v-for="(item,index) in msgList" :key="index" class="text item">
        <div class="">{{item.from}}:{{item.msg}}</div>
      </div>
      <el-collapse @change="handleChange" style="margin-top:20px">
        <el-collapse-item title="选择客户" name="1">
          <div v-for="item in nameList" @click="handleName(item)">{{item}}</div>
        </el-collapse-item>
      </el-collapse>
      <el-input
        type="textarea"
        :rows="5"
        placeholder="请输入内容"
        v-model="message.msg"
      style="margin-top:20px">
      </el-input>
      <el-button style="float:right;margin-top:20px;margin-bottom: 20px" @click="send">发送信息</el-button>
    </el-card>
  </div>
</template>

<script>
import { listInfo, getInfo, delInfo, addInfo, updateInfo } from "@/api/order/info";

let socket;
export default {
  name: "chat",
  dicts: ['order_pay_status', 'order_way_status', 'order_now_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      userName:"请选择客户",
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // info表格数据
      infoList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        customerName: null,
        customerAddr: null,
        customerId: null,
        orderAmount: null,
        orderType: null,
        orderStatus: null,
        payStatus: null,
        chairNo: null,
      },
      // 表单参数
      form: {},
      // 消息记录列表
      msgList: [],
      nameList:[],
      // 发送的消息
      message: {
        time:null,//时间
        to: null,//发给谁
        from:'客服',
        msg: ''
      }
    }
  },
  created() {
    this.getList();
    this.init();
  },
  methods: {
    handleName(item){
      this.userName=item;
      let item1 = sessionStorage.getItem(item);
      this.msgList=JSON.parse(item1);
    },
    handleChange(){},
    send() {
      if (!this.message.msg) {
        this.$modal.msgSuccess("请输入信息");
      } else {
        let that=this;
        this.message.from='客服';
        this.message.to=that.userName;
        this.message.time=new Date().toLocaleTimeString();
        socket.send(JSON.stringify(this.message));
        console.log(this.message)
        let obj={
          time:that.message.time,
          to: that.userName,//发给谁
          from:'客服',
          msg:that.message.msg
        }
        if(this.msgList!=null&&this.msgList.length!=0){
          this.msgList=[...this.msgList,obj]
        }else{
          this.msgList=[obj]
        }
        this.message.msg = '';
        sessionStorage.setItem(that.userName,JSON.stringify(that.msgList));
      }
    },
    init() {
      // 如果sessionStorage中没有用户信息，则跳转登录页面
      // this.user = sessionStorage.getItem('user')
      // if (!this.user) {
      //   this.$router.push('/')
      // }
      let that = this;

      console.log("您的浏览器支持WebSocket");
      let socketUrl = "ws://localhost:8080/websocket/客服";
      // 开启一个websocket服务
      socket = new WebSocket(socketUrl);
      //打开事件
      socket.onopen = function () {
        console.log("websocket已打开");
      };
      //  浏览器端收消息，获得从服务端发送过来的文本消息
      socket.onmessage = function (msg) {
        let data = JSON.parse(msg.data)
        if(data.to=="all"){
           that.nameList=data.msg.split(",");
           that.nameList.some((data,index)=>{
             if(data=="客服"){
               that.nameList.splice(index,1);
             }
           })
        }else{
          if(data.from=="客服"){return}
          if(that.userName==data.from){
            that.msgList=[...that.msgList,data];
            sessionStorage.setItem(data.from,JSON.stringify(that.msgList));
          }else{
            let item = sessionStorage.getItem(data.from);
            let parse;
            if(item!=null){
              parse = JSON.parse(item);
              parse=[...parse,data];
            }else{
              parse=[data];
            }
            sessionStorage.setItem(data.from,JSON.stringify(parse));
            that.$modal.msgSuccess(data.from+"给你发了一条信息");
          }
        }

      };
      //关闭事件
      socket.onclose = function () {
        console.log("websocket已关闭");
      };
      //发生了错误事件
      socket.onerror = function () {
        console.log("websocket发生了错误");
      }
    },
    /** 查询info列表 */
    getList() {
      this.loading = true;
      listInfo(this.queryParams).then(response => {
        this.infoList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        orderId: null,
        customerName: null,
        customerAddr: null,
        customerId: null,
        orderAmount: null,
        orderType: null,
        orderStatus: null,
        payStatus: null,
        chairNo: null,
        createTime: null,
        createBy: null,
        updateBy: null,
        updateTime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.orderId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加info";
    },
    /** 查看按钮操作 */
    handleCheck(row) {
      const orderId = row.orderId;
      console.log(orderId)
      this.$router.push({ path: "/order/detail", query: {id: orderId} });
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const orderId = row.orderId || this.ids
      getInfo(orderId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改info";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.orderId != null) {
            updateInfo(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addInfo(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const orderIds = row.orderId || this.ids;
      this.$modal.confirm('是否确认删除info编号为"' + orderIds + '"的数据项？').then(function() {
        return delInfo(orderIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('order/info/export', {
        ...this.queryParams
      }, `info_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
