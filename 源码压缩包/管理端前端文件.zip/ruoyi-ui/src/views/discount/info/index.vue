<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
      <el-form-item label="红包卡券数额" prop="discountAccount">
        <el-input
          v-model="queryParams.discountAccount"
          placeholder="请输入红包卡券数额"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="红包卡券详细" prop="discountDetail">
        <el-input
          v-model="queryParams.discountDetail"
          placeholder="请输入红包卡券详细"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="红包卡券是否生效" prop="isvalidate">
        <el-select v-model="queryParams.isvalidate" placeholder="请选择红包卡券是否生效" clearable>
          <el-option
            v-for="dict in dict.type.discount_validate_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="满减条件" prop="discountCondition">
        <el-input
          v-model="queryParams.discountCondition"
          placeholder="请输入满减条件"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="红包类型" prop="discountType">
        <el-select v-model="queryParams.discountType" placeholder="请选择红包类型" clearable>
          <el-option
            v-for="dict in dict.type.discount_type_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="红包卡券标题" prop="discountTitle">
        <el-input
          v-model="queryParams.discountTitle"
          placeholder="请输入红包卡券标题"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="default"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAddKey"
          v-hasPermi="['discount:info:addKey']"
        >新增红包兑换码</el-button>
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['discount:info:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['discount:info:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['discount:info:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['discount:info:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="infoList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="红包卡券id" align="center" prop="discountId" />
      <el-table-column label="红包卡券数额" align="center" prop="discountAccount" />
      <el-table-column label="红包卡券详细" align="center" prop="discountDetail" />
      <el-table-column label="红包卡券是否生效" align="center" prop="isvalidate">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.discount_validate_status" :value="scope.row.isvalidate"/>
        </template>
      </el-table-column>
      <el-table-column label="满减条件" align="center" prop="discountCondition" />
      <el-table-column label="红包类型" align="center" prop="discountType">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.discount_type_status" :value="scope.row.discountType"/>
        </template>
      </el-table-column>
      <el-table-column label="红包卡券标题" align="center" prop="discountTitle" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['discount:info:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['discount:info:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改红包卡券对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="红包卡券数额" prop="discountAccount">
          <el-input v-model="form.discountAccount" placeholder="请输入红包卡券数额" />
        </el-form-item>
        <el-form-item label="红包卡券详细" prop="discountDetail">
          <el-input v-model="form.discountDetail" placeholder="请输入红包卡券详细" />
        </el-form-item>
        <el-form-item label="红包卡券是否生效" prop="isvalidate">
          <el-select v-model="form.isvalidate" placeholder="请选择红包卡券是否生效">
            <el-option
              v-for="dict in dict.type.discount_validate_status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="满减条件" prop="discountCondition">
          <el-input v-model="form.discountCondition" placeholder="请输入满减条件" />
        </el-form-item>
        <el-form-item label="红包类型" prop="discountType">
          <el-select v-model="form.discountType" placeholder="请选择红包类型">
            <el-option
              v-for="dict in dict.type.discount_type_status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="红包卡券标题" prop="discountTitle">
          <el-input v-model="form.discountTitle" placeholder="请输入红包卡券标题" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 添加红包兑换码对话框 -->
    <el-dialog :title="titleExchange" :visible.sync="openExchange" width="400px" append-to-body>
      <el-form ref="formExchange" :model="formExchange" :rules="rules" label-width="80px">
        <el-form-item label="红包卡券码" prop="discountAccount" label-width="100px">
          <el-input v-model="formExchange.discountId" placeholder="请输入红包卡券码" />
        </el-form-item>
        <el-form-item label="数量" prop="discountDetail" label-width="100px">
          <el-input v-model="formExchange.number" placeholder="请输入红包卡券数量" type="number"/>
        </el-form-item>
        <el-form-item label="兑换码生效" prop="isvalidate" label-width="100px">
          <el-select v-model="form.isvalidate" placeholder="请选择红包卡券是否生效">
            <el-option
              v-for="dict in dict.type.discount_validate_status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFormExchange">确 定</el-button>
        <el-button @click="cancelExchange">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listInfo, getInfo, delInfo, addInfo, updateInfo,addKey } from "@/api/discount/info";

export default {
  name: "Info",
  dicts: ['discount_type_status', 'discount_validate_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 红包卡券表格数据
      infoList: [],
      // 弹出层标题
      title: "",
      titleExchange:"",
      // 是否显示弹出层
      open: false,
      openExchange: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        discountAccount: null,
        discountDetail: null,
        isvalidate: null,
        discountCondition: null,
        discountType: null,
        discountTitle: null
      },
      // 表单参数
      form: {},
      formExchange: {},
      // 表单校验
      rules: {
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询红包卡券列表 */
    getList() {
      this.loading = true;
      listInfo(this.queryParams).then(response => {
        this.infoList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    cancelExchange() {
      this.openExchange = false;
      this.resetExchange();
    },
    // 表单重置
    reset() {
      this.form = {
        discountId: null,
        discountAccount: null,
        discountDetail: null,
        isvalidate: null,
        discountCondition: null,
        updateTime: null,
        createBy: null,
        createTime: null,
        discountType: null,
        updateBy: null,
        discountTitle: null
      };
      this.resetForm("form");
    },
    // 表单重置
    resetExchange() {
      this.formExchange = {
        discountId: null,
        number:0,
      };
      this.resetForm("formExchange");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.discountId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAddKey() {
      this.resetExchange();
      this.openExchange = true;
      this.titleExchange = "添加红包兑换码";
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加红包卡券";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const discountId = row.discountId || this.ids
      getInfo(discountId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改红包卡券";
      });
    },
    /** 提交按钮 */
    submitFormExchange() {
      this.$refs["formExchange"].validate(valid => {
        if (valid) {
          if (this.formExchange.discountId != null) {
            addKey(this.formExchange).then(response => {
              this.$modal.msgSuccess("增加成功");
              this.openExchange = false;
              this.getList();
            });
          } else {
            addInfo(this.formExchange).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.openExchange = false;
              this.getList();
            });
          }
        }
      });
    },
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.discountId != null) {
            updateInfo(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addInfo(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const discountIds = row.discountId || this.ids;
      this.$modal.confirm('是否确认删除红包卡券编号为"' + discountIds + '"的数据项？').then(function() {
        return delInfo(discountIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('discount/info/export', {
        ...this.queryParams
      }, `info_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
