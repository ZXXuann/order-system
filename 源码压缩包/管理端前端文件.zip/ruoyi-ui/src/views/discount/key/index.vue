<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
      <el-form-item label="兑换码" prop="key">
        <el-input
          v-model="queryParams.key"
          placeholder="请输入红包卡券兑换码"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="创建时间" prop="createTime">
        <el-date-picker clearable
          v-model="queryParams.createTime"
          type="date"
          value-format="yyyy-MM-dd"
          placeholder="请选择创建时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="是否生效" prop="isvalidate">
        <el-select v-model="queryParams.isvalidate" placeholder="请选择是否生效" clearable>
          <el-option
            v-for="dict in dict.type.discount_validate_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['discount:key:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['discount:key:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['discount:key:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="keyList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="兑换码标识" align="center" prop="keyId" />
      <el-table-column label="卡券标识" align="center" prop="discountId" />
      <el-table-column label="兑换码" align="center" prop="discountKey" />
      <el-table-column label="创建时间" align="center" prop="createTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="生效" align="center" prop="isvalidate">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.discount_validate_status" :value="scope.row.isvalidate"/>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['discount:key:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['discount:key:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加红包卡券兑换码对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="红包卡券码" prop="discountId" label-width="100px">
          <el-input v-model="form.discountId" placeholder="请输入红包卡券码" />
        </el-form-item>
        <el-form-item label="结束时间(天)" prop="number" label-width="100px">
          <el-input v-model="form.endTime" placeholder="请输入结束时间" type="number"/>
        </el-form-item>
        <el-form-item label="数量" prop="number" label-width="100px">
          <el-input v-model="form.number" placeholder="请输入红包卡券数量" type="number"/>
        </el-form-item>
        <el-form-item label="生效" prop="isvalidate" label-width="100px">
          <el-select v-model="form.isvalidate" placeholder="请选择生效">
            <el-option
              v-for="dict in dict.type.discount_validate_status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 修改红包卡券兑换码对话框 -->
    <el-dialog :title="title" :visible.sync="openSec" width="500px" append-to-body>
      <el-form ref="formSec" :model="formSec" :rules="rules" label-width="80px">
        <el-form-item label="生效" prop="isvalidate" label-width="100px">
          <el-select v-model="formSec.isvalidate" placeholder="请选择生效">
            <el-option
              v-for="dict in dict.type.discount_validate_status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFormSec">确 定</el-button>
        <el-button @click="cancelSec">取 消</el-button>
      </div>
    </el-dialog>

    <el-dialog title="兑换码" :visible.sync="openKey" width="500px" class="showAll_dialog" append-to-body>
      <el-scrollbar style="height: 100%" :native="false">
          <div style="padding:20px;border-bottom: 1px solid #e6e6e6" v-for="(item,index) in ret" :key="index">
            {{item}}
          </div>
      </el-scrollbar>
    </el-dialog>
  </div>
</template>
<style lang="scss" scoped>
.showAll_dialog {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
::v-deep .el-dialog {
  margin: 0 auto !important;
  height: 80%;
  overflow: hidden;
.el-dialog__body {
  position: absolute;
  left: 0;
  top: 54px;
  bottom: 0;
  right: 0;
  padding: 0;
  z-index: 1;
  overflow: hidden;
  overflow-y: auto;
}
}
}
</style>
<script>
import { listKey, getKey, delKey, addKey, updateKey } from "@/api/discount/key";

export default {
  name: "Key",
  dicts: ['discount_validate_status'],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 红包卡券兑换码表格数据
      keyList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      openSec: false,
      openKey: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        discountId: null,
        discountKey: null,
        createTime: null,
        isvalidate: null
      },
      // 表单参数
      form: {},
      formSec: {},
      // 表单校验
      rules: {
      },
      //返回结果
      ret:[]
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询红包卡券兑换码列表 */
    getList() {
      this.loading = true;
      listKey(this.queryParams).then(response => {
        this.keyList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    cancelSec() {
      this.openSec = false;
      this.resetSec();
    },
    // 表单重置
    reset() {
      this.form = {
        keyId: null,
        discountId: null,
        createTime: null,
        createBy: null,
        updateBy: null,
        updateTime: null,
        isvalidate: null,
        endTime:null
      };
      this.resetForm("form");
    },
    resetSec() {
      this.formSec = {
        keyId: null,
        isvalidate: null
      };
      this.resetForm("formSec");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.keyId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加红包卡券兑换码";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.resetSec();
      const keyId = row.keyId || this.ids
      getKey(keyId).then(response => {
        this.formSec = response.data;
        this.openSec = true;
        this.title = "修改红包卡券兑换码";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.keyId != null) {
            updateKey(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addKey(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.openKey = true;
              this.ret = response.data;
              this.getList();
            });
          }
        }
      });
    },
    submitFormSec() {
      this.$refs["formSec"].validate(valid => {
        if (valid) {
            updateKey(this.formSec).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.openSec = false;
              this.getList();
            });
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const keyIds = row.keyId || this.ids;
      this.$modal.confirm('是否确认删除红包卡券兑换码编号为"' + keyIds + '"的数据项？').then(function() {
        return delKey(keyIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('discount/key/export', {
        ...this.queryParams
      }, `key_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
