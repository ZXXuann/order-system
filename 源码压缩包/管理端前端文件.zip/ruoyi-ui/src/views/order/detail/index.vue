<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
<!--      <el-form-item label="订单主表标识" prop="orderId">-->
<!--        <el-input-->
<!--          v-model="queryParams.orderId"-->
<!--          placeholder="请输入订单主表标识"-->
<!--          clearable-->
<!--          @keyup.enter.native="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
      <el-form-item label="菜品标识" prop="foodId">
        <el-input
          v-model="queryParams.foodId"
          placeholder="请输入菜品标识"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="菜品名" prop="foodName">
        <el-input
          v-model="queryParams.foodName"
          placeholder="请输入菜品名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="菜品金额" prop="foodPrice">
        <el-input
          v-model="queryParams.foodPrice"
          placeholder="请输入菜品金额"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="菜品数目" prop="foodCount">
        <el-input
          v-model="queryParams.foodCount"
          placeholder="请输入菜品数目"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['order:detail:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['order:detail:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['order:detail:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['order:detail:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="detailList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="订单详情表标识" align="center" prop="detailId" />
      <el-table-column label="订单主表标识" align="center" prop="orderId" />
      <el-table-column label="菜品标识" align="center" prop="foodId" />
      <el-table-column label="菜品名" align="center" prop="foodName" />
      <el-table-column label="菜品金额" align="center" prop="foodPrice" />
      <el-table-column label="菜品数目" align="center" prop="foodCount" />
      <el-table-column label="菜品图片" align="center" prop="foodImg" width="100">
        <template slot-scope="scope">
          <image-preview :src="scope.row.foodImg" :width="50" :height="50"/>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['order:detail:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['order:detail:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改detail对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
<!--        <el-form-item label="订单主表标识" prop="orderId">-->
<!--          <el-input v-model="form.orderId" placeholder="请输入订单主表标识" />-->
<!--        </el-form-item>-->
        <el-form-item label="菜品标识" prop="foodId">
          <el-input v-model="form.foodId" placeholder="请输入菜品标识" />
        </el-form-item>
        <el-form-item label="菜品名" prop="foodName">
          <el-input v-model="form.foodName" placeholder="请输入菜品名" />
        </el-form-item>
        <el-form-item label="菜品金额" prop="foodPrice">
          <el-input v-model="form.foodPrice" placeholder="请输入菜品金额" />
        </el-form-item>
        <el-form-item label="菜品数目" prop="foodCount">
          <el-input v-model="form.foodCount" placeholder="请输入菜品数目" />
        </el-form-item>
        <el-form-item label="菜品图片" prop="foodImg">
          <image-upload v-model="form.foodImg"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listDetail, getDetail, delDetail, addDetail, updateDetail } from "@/api/order/detail";

export default {
  name: "Detail",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // detail表格数据
      detailList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        orderId: null,
        foodId: null,
        foodName: null,
        foodPrice: null,
        foodCount: null,
        foodImg: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
      //订单id
      orderId:1,
    };
  },
  created() {
    this.getParamsId()
    this.getList();
  },
  methods: {
    /** 查询detail列表 */
    getList() {
      this.loading = true;
      listDetail(this.queryParams).then(response => {
        this.detailList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        detailId: null,
        // orderId: null,
        foodId: null,
        foodName: null,
        foodPrice: null,
        foodCount: null,
        foodImg: null,
        createTime: null,
        createBy: null,
        updateBy: null,
        updateTime: null
      };
      this.$set(this.form,'orderId',this.orderId);
      this.resetForm("form");
    },
    /** 获取url中菜品类型参数 */
    getParamsId() {
      this.orderId=this.$route.query.id?Number(this.$route.query.id):null;
      this.$set(this.queryParams,'orderId',this.orderId);
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.detailId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加订单详细";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const detailId = row.detailId || this.ids
      getDetail(detailId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改订单详细";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.detailId != null) {
            updateDetail(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addDetail(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const detailIds = row.detailId || this.ids;
      this.$modal.confirm('是否确认删除detail编号为"' + detailIds + '"的数据项？').then(function() {
        return delDetail(detailIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('order/detail/export', {
        ...this.queryParams
      }, `detail_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
