<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
      <el-form-item label="用户名" prop="customerName">
        <el-input
          v-model="queryParams.customerName"
          placeholder="请输入用户名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="手机" prop="customerPhone">
        <el-input
          v-model="queryParams.customerPhone"
          placeholder="请输入手机"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="地址" prop="customerAddr">
        <el-input
          v-model="queryParams.customerAddr"
          placeholder="请输入地址"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="姓名" prop="nickname">
        <el-input
          v-model="queryParams.nickname"
          placeholder="请输入姓名"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
<!--      <el-form-item label="身份证号" prop="idNo">-->
<!--        <el-input-->
<!--          v-model="queryParams.idNo"-->
<!--          placeholder="请输入顾客身份号码"-->
<!--          clearable-->
<!--          @keyup.enter.native="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
      <el-form-item label="顾客角色" prop="customerType">
        <el-select v-model="queryParams.customerType" placeholder="请选择顾客角色" clearable>
          <el-option
            v-for="dict in permList"
            :key="dict.id"
            :label="dict.id+'  '+dict.remark"
            :value="dict.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['customer:info:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['customer:info:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['customer:info:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['customer:info:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="infoList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="顾客标识" align="center" prop="customerId" />
      <el-table-column label="用户名" align="center" prop="customerName" />
      <el-table-column label="手机号" align="center" prop="customerPhone" />
      <el-table-column label="地址" align="center" prop="customerAddr" />
      <el-table-column label="姓名" align="center" prop="nickname" />
<!--      <el-table-column label="顾客身份证号" align="center" prop="idNo" />-->
      <el-table-column label="顾客角色" align="center" prop="customerType">
        <template slot-scope="scope">
          <p>{{getNameById(scope.row.customerType)}}</p>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['customer:info:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['customer:info:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改info对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
<!--        <el-form-item label="第三方用户开放标识" prop="openId">-->
<!--          <el-input v-model="form.openId" placeholder="请输入第三方用户开放标识" />-->
<!--        </el-form-item>-->
        <el-form-item label="顾客姓名" prop="customerName">
          <el-input v-model="form.customerName" placeholder="请输入顾客姓名" />
        </el-form-item>
        <el-form-item label="顾客手机号" prop="customerPhone">
          <el-input v-model="form.customerPhone" placeholder="请输入顾客的手机" />
        </el-form-item>
        <el-form-item label="顾客地址" prop="customerAddr">
          <el-input v-model="form.customerAddr" placeholder="请输入顾客地址" />
        </el-form-item>
        <el-form-item label="顾客昵称" prop="nickname">
          <el-input v-model="form.nickname" placeholder="请输入顾客昵称" />
        </el-form-item>
<!--        <el-form-item label="顾客身份号码" prop="idNo">-->
<!--          <el-input v-model="form.idNo" placeholder="请输入顾客身份号码" />-->
<!--        </el-form-item>-->
        <el-form-item label="顾客角色" prop="customerType">
          <el-select v-model="form.customerType" placeholder="请选择顾客角色" clearable>
          <el-option
            v-for="dict in permList"
            :key="dict.id"
            :label="dict.id+'  '+dict.remark"
            :value="dict.id"
          />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listInfo, getInfo, delInfo, addInfo, updateInfo,permList } from "@/api/customer/info";
import {listType} from "@/api/food/type";

export default {
  name: "Info",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // info表格数据
      infoList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        customerName: null,
        customerPhone: null,
        customerAddr: null,
        nickname: null,
        // idNo: null,
        customerType: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
      },
      permList:[]
    };
  },
  created() {
    this.getList();
    this.getPermList();
  },
  methods: {
    /** 查询所对应的名称（id->name) */
    getNameById(typeId){
      let name=null;
      this.permList.some((item,i)=>{
        if(item.id==typeId){
          name=item.remark;
          console.log(name);
          return true;
        }
      });
      return name;
    },
    /** 查询角色类型列表（所有） */
    getPermList() {
      this.loading = true;
      permList().then(response => {
        this.permList = response.rows;
        this.loading = false;
        console.log(this.permList);
      });
    },
    /** 查询info列表 */
    getList() {
      this.loading = true;
      listInfo(this.queryParams).then(response => {
        this.infoList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        customerId: null,
        // openId: null,
        customerName: null,
        customerPhone: null,
        customerAddr: null,
        nickname: null,
        // idNo: null,
        customerType: null,
        createTime: null,
        createBy: null,
        updateBy: null,
        updateTime: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.customerId)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加顾客信息";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const customerId = row.customerId || this.ids
      getInfo(customerId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改顾客信息";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.customerId != null) {
            updateInfo(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addInfo(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const customerIds = row.customerId || this.ids;
      this.$modal.confirm('是否确认删除顾客编号为"' + customerIds + '"的数据项？').then(function() {
        return delInfo(customerIds);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('customer/info/export', {
        ...this.queryParams
      }, `info_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
