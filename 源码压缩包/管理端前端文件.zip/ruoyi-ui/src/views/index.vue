<template>
  <div class="app-container home">
    <el-row :gutter="30">
      <el-col :span="6">
    <el-card class="box-card" >
      <div slot="header" class="clearfix">
        <span class="title">今日营业额</span>
<!--        <el-button style="float: right; padding: 3px 0" type="text"></el-button>-->
      </div>
      <div class="text item">
        {{"￥"+todaySale}}
      </div>
      <hr/>
      <div class="percent" v-if="yesterdaySale">
        {{"同比增长："+(todaySale-yesterdaySale)/yesterdaySale*100+"%"}}
        <div class="el-icon-caret-bottom" v-if="(todaySale/yesterdaySale)<1"></div>
        <div class="el-icon-caret-top" style="color:red"  v-else></div>
      </div>
      <div class="percent" v-else>
        {{"同比增长：100%"}}
        <div class="el-icon-caret-top" style="color:red" ></div>
      </div>
    </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span class="title">昨日营业额</span>
<!--            <el-button style="float: right; padding: 3px 0" type="text">操作按钮</el-button>-->
          </div>
          <div class="text item">
            {{"￥"+yesterdaySale}}
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span class="title">今年总营业额</span>
<!--        <el-button style="float: right; padding: 3px 0" type="text">操作按钮</el-button>-->
      </div>
      <div class="text item">
        {{"￥"+thisYearSale}}
      </div>
      <hr/>
      <div class="percent" v-if="lastYearSale">
        {{"同比增长："+(thisYearSale-lastYearSale)/lastYearSale*100+"%"}}
        <div class="el-icon-caret-bottom"  v-if="(thisYearSale/lastYearSale)<1"></div>
        <div class="el-icon-caret-top" style="color:red"  v-else></div>
      </div>
      <div class="percent" v-else>
        {{"同比增长：100%"}}<div class="el-icon-caret-top" style="color:red" ></div>
      </div>
    </el-card></el-col>
      <el-col :span="6">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span class="title">去年总营业额</span>
            <!--        <el-button style="float: right; padding: 3px 0" type="text">操作按钮</el-button>-->
          </div>
          <div class="text item">
            {{"￥"+lastYearSale}}
          </div>
        </el-card></el-col>
      </el-row>

    <el-row :gutter="30" style="padding-top:20px ">
      <el-col :span="12">
        <el-card>
<!--          <div>-->
<!--            <el-button class="btn" :type="saleSel=='all'?'primary':''" @click="setSale('all')">总销量</el-button>-->
<!--            <el-button class="btn" :type="saleSel=='day'?'primary':''" @click="setSale('day')">日销量</el-button>-->
<!--          </div>-->
          <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" label-width="68px">
            <el-form-item label="销售时间">
              <el-date-picker
                v-model="dateRange"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" icon="el-icon-search" size="mini" @click="setSale('all')">搜索</el-button>
              <el-button icon="el-icon-refresh" size="mini" @click="getSaleChart">查询总销量</el-button>
            </el-form-item>
          </el-form>
      <div ref="chart" style="width:100%;height:500px"></div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <el-form :model="monqueryParams" ref="queryForm" size="small" :inline="true" label-width="68px">
            <el-form-item label="销售时间">
              <el-date-picker
                v-model="mondateRange"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" icon="el-icon-search" size="mini" @click="setMoney('all')">搜索</el-button>
              <el-button icon="el-icon-refresh" size="mini" @click="setMoney()">查询近一年营销额</el-button>
            </el-form-item>
          </el-form>
          <div ref="monchart" style="width:100%;height:500px"></div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="30" style="padding-top:20px ">
      <el-col>
        <el-card>
          <el-form :model="selpiequeryParams" ref="queryForm" size="small" :inline="true" label-width="68px">
            <el-form-item label="销售时间">
              <el-date-picker
                v-model="selpiedateRange"
                style="width: 240px"
                value-format="yyyy-MM-dd"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" icon="el-icon-search" size="mini" @click="setSelPie('all')">搜索</el-button>
              <el-button icon="el-icon-refresh" size="mini" @click="getSaleChart(2)">查询近一年比例</el-button>
            </el-form-item>
          </el-form>
          <div ref="selpiechart" style="width:100%;height:500px"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getSale,getMoneyChart,getSaleChart } from "@/api/index";
import {listInfo} from "@/api/order/info";
export default {
  name: "Index",
  data() {
    return {
      // 版本号
      version: "3.8.5",
      todaySale:0,
      yesterdaySale:0,
      thisYearSale:0,
      lastYearSale:0,
      chartName:[1,1,1,1],
      chartVal:[1,1,1,1],
      queryParams:{},
      monqueryParams:{},
      selpiequeryParams:{},
      saleSel:"all",
      dateRange: "",
      selpiedateRange: "",
      mondateRange: "",
      objPie:[{name:'获取中...',value:'100'}]
    };

  },
  mounted() {
    this.getSale();
    this.setMoney();
    // this.setSelPie();
    this.getSaleChart(1);
    this.getSaleChart(2);
  },
  created() {

  },
  methods: {
    setMoney(e){
      this.saleSel=e;//暂时无用处
      getMoneyChart( e!=null?this.addDateRange({pay_status:1}, this.mondateRange):{pay_status:1}).then(response => {
        console.log(response.data);
        this.chartMon=[...response.data.val];
        this.chartTime=[...response.data.name];
        // this.$set("chartName",response.data.name);
        // this.$set("chartVal",response.data.val);
        this.showMonChart();
        console.log(this.chartMon)
        console.log(this.chartTime)
      });
    },
    setSelPie(e){
      this.saleSel=e;//暂时无用处
      getSaleChart( e!=null?this.addDateRange({pay_status:1}, this.selpiedateRange):{pay_status:1}).then(response => {
        console.log(response)
        var tmp = [...response.data.val];
        var tmp1 = [...response.data.name];
        this.objPie = [];
        tmp.forEach((item, index) => {
          let obj = {name: tmp1[index], value: tmp[index]};
          this.objPie.push(obj);
        });
        this.objPie.sort((a, b) => {
          return b.value - a.value;
        })
        let val = 0;
        if (this.objPie.length > 8) {
          for (let i = 8; i < this.objPie.length; i++) {
            val += this.objPie[i].value;
          }
          this.objPie = [...this.objPie.slice(0, 7), {name: "其他", value: val}];
        }

        this.showSelPieChart();
      });
    },
    setSale(e){
      getSaleChart( e!=null?this.addDateRange({pay_status:1}, this.dateRange):'').then(response => {
        console.log(response.data.name);
        this.chartVal=[...response.data.val];
        this.chartName=[...response.data.name];
        // this.$set("chartName",response.data.name);
        // this.$set("chartVal",response.data.val);
        this.showSaleChart();
        console.log(this.chartName)
        console.log(this.chartVal)
      });
    },
    showMonChart(){
      let that=this;
      const chart = this.$refs.monchart
      const myChart = this.$echarts.init(chart);
      myChart.setOption({
        dataZoom: [{ // 控制图表左右滑动
          width: '15',
          type: 'slider',
          show: false, //flase直接隐藏图形
          xAxisIndex: [0],
          left: 33, //滚动条靠左侧的百分比
          bottom: 40,
          height: 20,//组件高度
          start: 0,//滚动条的起始位置
          showDataShadow: false,//是否显示数据阴影
          showDetail: false,//是否显示想洗数值信息
          end: 100 //滚动条的截止位置（按比例分割你的柱状图x轴长度）
        }, {
          type: 'inside',
          show: true,
          xAxisIndex: [0],
          start: 0,//滚动条的起始位置
          end: 0.3 //滚动条的截止位置（按比例分割你的柱状图x轴长度）
        }],
        toolbox: {
          show: true,
          feature: {
            mark: {show: true},
            dataView: {show: true, readOnly: false},
            restore: {show: true},
            saveAsImage: {show: true}
          }
        },
        title: {
          text: '营业额'
        },
        tooltip: {},
        xAxis: {
          data: that.chartTime
        },
        yAxis: {},
        series: [
          {
            name: '营业额',
            type: 'bar',
            data: that.chartMon
          }
        ]
      });
      window.addEventListener("resize", function() {
        myChart.resize()
      })
    },
    showSelPieChart(){
      let that=this;
      const chart = this.$refs.selpiechart
      const myChart = this.$echarts.init(chart);
      myChart.setOption({
        legend: {
          top: 'bottom'
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            restore: { show: true },
            saveAsImage: { show: true }
          }
        },
        title: {
          text: '菜品销售饼状图',
          left: 'center'
        },
        tooltip: {
          trigger: 'item'
        },
        series: [
          {
            label: {
              normal: {
                show: true,
                formatter: '{b}: {c}({d}%)' //自定义显示格式(b:name, c:value, d:百分比)
              }
            },
            name: 'Access From',
            type: 'pie',
            radius: '50%',
            data:this.objPie,
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }
        ]
      });
      window.addEventListener("resize", function() {
        myChart.resize()
      })
    },
    showSaleChart(){
      let that=this;
      const chart = this.$refs.chart
      const myChart = this.$echarts.init(chart);
      myChart.setOption({
        dataZoom: [{ // 控制图表左右滑动
          width: '15',
          type: 'slider',
          show: false, //flase直接隐藏图形
          xAxisIndex: [0],
          left: 33, //滚动条靠左侧的百分比
          bottom: 40,
          height: 20,//组件高度
          start: 0,//滚动条的起始位置
          showDataShadow: false,//是否显示数据阴影
          showDetail: true,//是否显示想洗数值信息
          end: 100 //滚动条的截止位置（按比例分割你的柱状图x轴长度）
        }, {
          type: 'inside',
          show: true,
          xAxisIndex: [0],
          start: 0,//滚动条的起始位置
          end: 0.3 //滚动条的截止位置（按比例分割你的柱状图x轴长度）
        }],
        toolbox: {
          show: true,
          feature: {
            mark: {show: true},
            dataView: {show: true, readOnly: false},
            restore: {show: true},
            saveAsImage: {show: true}
          }
        },
        title: {
          text: '菜品销量'
        },
        tooltip: {},
        xAxis: {
          data: that.chartName,
        axisLabel:{
          interval: 0,
          // rotate:40,
        }
        },
        yAxis: {},
        series: [
          {
            name: '销量',
            type: 'bar',
            data: that.chartVal
          }
        ]
      });
      window.addEventListener("resize", function() {
        myChart.resize()
      })
    },
    goTarget(href) {
      window.open(href, "_blank");
    },
    getSale() {
      this.loading = true;
      getSale().then(response => {
        this.todaySale = response.rows[0].todaysale;
        this.yesterdaySale = response.rows[0].yestodaysale;
        this.thisYearSale = response.rows[0].thisyearsale;
        this.lastYearSale = response.rows[0].lastyearsale;
      });
    },
    getSaleChart(e) {
      this.loading = true;
      getSaleChart({pay_status:1}).then(response => {
        if(e==1) {
          console.log(response.data.name);
          this.chartVal = [...response.data.val];
          this.chartName = [...response.data.name];
          this.showSaleChart();
        }else {
          var tmp = [...response.data.val];
          var tmp1 = [...response.data.name];
          this.objPie = [];
          tmp.forEach((item, index) => {
            let obj = {name: tmp1[index], value: tmp[index]};
            this.objPie.push(obj);
          });
          this.objPie.sort((a, b) => {
            return b.value - a.value;
          })
          let val = 0;
          if (this.objPie.length > 8) {
            for (let i = 8; i < this.objPie.length; i++) {
              val += this.objPie[i].value;
            }
            this.objPie = [...this.objPie.slice(0, 7), {name: "其他", value: val}];
          }

          this.showSelPieChart();
        }
        // this.$set("chartName",response.data.name);
        // this.$set("chartVal",response.data.val);

        console.log(this.chartName)
        console.log(this.chartVal)
      });
    },
  }
};
</script>

<style scoped lang="scss">
.home {
  .btn{
    margin-bottom: 20px;
  }
  .box-card{
    display: block;
    height:190px;
  }
  .item{
    font-size: 40px;
  }
  .percent{
    color: #aaacaf;
  }
  .title{
    font-size: 15px;
  }
  blockquote {
    padding: 10px 20px;
    margin: 0 0 20px;
    font-size: 17.5px;
    border-left: 5px solid #eee;
  }
  hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
  }
  .col-item {
    margin-bottom: 20px;
  }

  ul {
    padding: 0;
    margin: 0;
  }

  font-family: "open sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
  font-size: 13px;
  color: #676a6c;
  overflow-x: hidden;

  ul {
    list-style-type: none;
  }

  h4 {
    margin-top: 0px;
  }

  h2 {
    margin-top: 10px;
    font-size: 26px;
    font-weight: 100;
  }

  p {
    margin-top: 10px;

    b {
      font-weight: 700;
    }
  }

  .update-log {
    ol {
      display: block;
      list-style-type: decimal;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0;
      margin-inline-end: 0;
      padding-inline-start: 40px;
    }
  }
}
</style>

