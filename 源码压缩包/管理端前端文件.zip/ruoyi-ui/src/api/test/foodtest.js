import request from '@/utils/request'

// 查询菜品测试管理列表
export function listFoodtest(query) {
  return request({
    url: '/test/foodtest/list',
    method: 'get',
    params: query
  })
}

// 查询菜品测试管理详细
export function getFoodtest(foodId) {
  return request({
    url: '/test/foodtest/' + foodId,
    method: 'get'
  })
}

// 新增菜品测试管理
export function addFoodtest(data) {
  return request({
    url: '/test/foodtest',
    method: 'post',
    data: data
  })
}

// 修改菜品测试管理
export function updateFoodtest(data) {
  return request({
    url: '/test/foodtest',
    method: 'put',
    data: data
  })
}

// 删除菜品测试管理
export function delFoodtest(foodId) {
  return request({
    url: '/test/foodtest/' + foodId,
    method: 'delete'
  })
}
