import request from '@/utils/request'

// 获取营业额
export const getSale = () => {
  return request({
    url: '/order/info/sale',
    method: 'get'
  })
}


// 获取图表信息
export const getMoneyChart = (query) => {
  return request({
    url: '/order/info/moneychart',
    method: 'get',
    params: query
  })
}
export const getSaleChart = (query) => {
  return request({
    url: '/order/info/salechart',
    method: 'get',
    params: query
  })
}
