import request from '@/utils/request'

// 查询首页图片列表
export function listPic(query) {
  return request({
    url: '/other/pic/list',
    method: 'get',
    params: query
  })
}

// 查询首页图片详细
export function getPic(indexId) {
  return request({
    url: '/other/pic/' + indexId,
    method: 'get'
  })
}

// 新增首页图片
export function addPic(data) {
  return request({
    url: '/other/pic',
    method: 'post',
    data: data
  })
}

// 修改首页图片
export function updatePic(data) {
  return request({
    url: '/other/pic',
    method: 'put',
    data: data
  })
}

// 删除首页图片
export function delPic(indexId) {
  return request({
    url: '/other/pic/' + indexId,
    method: 'delete'
  })
}
