import request from '@/utils/request'
// 设置其他信息
export function settings(data) {
  return request({
    url: '/other/settings',
    method: 'post',
    data: data
  })
}
