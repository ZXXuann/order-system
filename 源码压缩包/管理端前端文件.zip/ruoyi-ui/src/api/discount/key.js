import request from '@/utils/request'

// 查询红包卡券兑换码列表
export function listKey(query) {
  return request({
    url: '/discount/key/list',
    method: 'get',
    params: query
  })
}

// 查询红包卡券兑换码详细
export function getKey(keyId) {
  return request({
    url: '/discount/key/' + keyId,
    method: 'get'
  })
}

// 新增红包卡券兑换码
export function addKey(data) {
  return request({
    url: '/discount/key',
    method: 'post',
    data: data
  })
}

// 修改红包卡券兑换码
export function updateKey(data) {
  return request({
    url: '/discount/key',
    method: 'put',
    data: data
  })
}

// 删除红包卡券兑换码
export function delKey(keyId) {
  return request({
    url: '/discount/key/' + keyId,
    method: 'delete'
  })
}
