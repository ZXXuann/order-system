import request from '@/utils/request'

// 查询红包卡券列表
export function listInfo(query) {
  return request({
    url: '/discount/info/list',
    method: 'get',
    params: query
  })
}
// 添加红包兑换码
export function addKey(query) {
  return request({
    url: '/discount/info/list/createKey',
    method: 'get',
    params: query
  })
}
// 查询红包卡券详细
export function getInfo(discountId) {
  return request({
    url: '/discount/info/' + discountId,
    method: 'get'
  })
}

// 新增红包卡券
export function addInfo(data) {
  return request({
    url: '/discount/info',
    method: 'post',
    data: data
  })
}

// 修改红包卡券
export function updateInfo(data) {
  return request({
    url: '/discount/info',
    method: 'put',
    data: data
  })
}

// 删除红包卡券
export function delInfo(discountId) {
  return request({
    url: '/discount/info/' + discountId,
    method: 'delete'
  })
}
