import request from '@/utils/request'

// 查询顾客红包卡券列表
export function listCustomerDiscount(query) {
  return request({
    url: '/discount/customerDiscount/list',
    method: 'get',
    params: query
  })
}

// 查询顾客红包卡券详细
export function getCustomerDiscount(cdId) {
  return request({
    url: '/discount/customerDiscount/' + cdId,
    method: 'get'
  })
}

// 新增顾客红包卡券
export function addCustomerDiscount(data) {
  return request({
    url: '/discount/customerDiscount',
    method: 'post',
    data: data
  })
}

// 修改顾客红包卡券
export function updateCustomerDiscount(data) {
  return request({
    url: '/discount/customerDiscount',
    method: 'put',
    data: data
  })
}

// 删除顾客红包卡券
export function delCustomerDiscount(cdId) {
  return request({
    url: '/discount/customerDiscount/' + cdId,
    method: 'delete'
  })
}
