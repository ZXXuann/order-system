import request from '@/utils/request'

// 查询菜品规格集合列表
export function listCollect(query) {
  return request({
    url: '/food/collect/list',
    method: 'get',
    params: query
  })
}
// 查询菜品类型列表
export function listType(query) {
  return request({
    url: '/food/type/list',
    method: 'get',
    params: query
  })
}

// 查询菜品测试管理列表
export function listFood(query) {
  return request({
    url: '/food/food/list',
    method: 'get',
    params: query
  })
}

// 查询菜品测试管理详细
export function getFood(foodId) {
  return request({
    url: '/food/food/' + foodId,
    method: 'get'
  })
}

// 新增菜品测试管理
export function addFood(data) {
  return request({
    url: '/food/food',
    method: 'post',
    data: data
  })
}

// 修改菜品测试管理
export function updateFood(data) {
  return request({
    url: '/food/food',
    method: 'put',
    data: data
  })
}

// 删除菜品测试管理
export function delFood(foodId) {
  return request({
    url: '/food/food/' + foodId,
    method: 'delete'
  })
}
