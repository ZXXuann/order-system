import request from '@/utils/request'

// 查询菜品规格集合列表
export function listCollect(query) {
  return request({
    url: '/food/collect/list',
    method: 'get',
    params: query
  })
}

// 查询菜品规格集合详细
export function getCollect(collectId) {
  return request({
    url: '/food/collect/' + collectId,
    method: 'get'
  })
}

// 新增菜品规格集合
export function addCollect(data) {
  return request({
    url: '/food/collect',
    method: 'post',
    data: data
  })
}

// 修改菜品规格集合
export function updateCollect(data) {
  return request({
    url: '/food/collect',
    method: 'put',
    data: data
  })
}

// 删除菜品规格集合
export function delCollect(collectId) {
  return request({
    url: '/food/collect/' + collectId,
    method: 'delete'
  })
}
