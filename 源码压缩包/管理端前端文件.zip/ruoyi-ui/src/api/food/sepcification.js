import request from '@/utils/request'

// 查询菜品规格列表
export function listSepcification(query) {
  return request({
    url: '/food/sepcification/list',
    method: 'get',
    params: query
  })
}

// 查询菜品规格详细
export function getSepcification(spcfId) {
  return request({
    url: '/food/sepcification/' + spcfId,
    method: 'get'
  })
}

// 新增菜品规格
export function addSepcification(data) {
  return request({
    url: '/food/sepcification',
    method: 'post',
    data: data
  })
}

// 修改菜品规格
export function updateSepcification(data) {
  return request({
    url: '/food/sepcification',
    method: 'put',
    data: data
  })
}

// 删除菜品规格
export function delSepcification(spcfId) {
  return request({
    url: '/food/sepcification/' + spcfId,
    method: 'delete'
  })
}
