import request from '@/utils/request'

// 查询菜品类型列表
export function listType(query) {
  return request({
    url: '/food/type/list',
    method: 'get',
    params: query
  })
}

// 查询菜品类型详细
export function getType(foodtypeId) {
  return request({
    url: '/food/type/' + foodtypeId,
    method: 'get'
  })
}

// 新增菜品类型
export function addType(data) {
  return request({
    url: '/food/type',
    method: 'post',
    data: data
  })
}

// 修改菜品类型
export function updateType(data) {
  return request({
    url: '/food/type',
    method: 'put',
    data: data
  })
}

// 删除菜品类型
export function delType(foodtypeId) {
  return request({
    url: '/food/type/' + foodtypeId,
    method: 'delete'
  })
}
