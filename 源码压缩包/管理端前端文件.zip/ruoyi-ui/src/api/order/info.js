import request from '@/utils/request'

// 查询info列表
export function listInfo(query) {
  return request({
    url: '/order/info/list',
    method: 'get',
    params: query
  })
}

// 查询info详细
export function getInfo(orderId) {
  return request({
    url: '/order/info/' + orderId,
    method: 'get'
  })
}

// 新增info
export function addInfo(data) {
  return request({
    url: '/order/info',
    method: 'post',
    data: data
  })
}

// 修改info
export function updateInfo(data) {
  return request({
    url: '/order/info',
    method: 'put',
    data: data
  })
}

// 删除info
export function delInfo(orderId) {
  return request({
    url: '/order/info/' + orderId,
    method: 'delete'
  })
}
