import request from '@/utils/request'

// 查询权限列表
export function listPerms(query) {
  return request({
    url: '/customer/perms/list',
    method: 'get',
    params: query
  })
}

// 查询权限详细
export function getPerms(id) {
  return request({
    url: '/customer/perms/' + id,
    method: 'get'
  })
}

// 新增权限
export function addPerms(data) {
  return request({
    url: '/customer/perms',
    method: 'post',
    data: data
  })
}

// 修改权限
export function updatePerms(data) {
  return request({
    url: '/customer/perms',
    method: 'put',
    data: data
  })
}

// 删除权限
export function delPerms(id) {
  return request({
    url: '/customer/perms/' + id,
    method: 'delete'
  })
}
