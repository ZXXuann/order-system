import request from '@/utils/request'

// 查询权限列表
export function permList(query) {
  return request({
    url: '/customer/perms/list',
    method: 'get',
    params: query
  })
}

// 查询info列表
export function listInfo(query) {
  return request({
    url: '/customer/info/list',
    method: 'get',
    params: query
  })
}

// 查询info详细
export function getInfo(customerId) {
  return request({
    url: '/customer/info/' + customerId,
    method: 'get'
  })
}

// 新增info
export function addInfo(data) {
  return request({
    url: '/customer/info',
    method: 'post',
    data: data
  })
}

// 修改info
export function updateInfo(data) {
  return request({
    url: '/customer/info',
    method: 'put',
    data: data
  })
}

// 删除info
export function delInfo(customerId) {
  return request({
    url: '/customer/info/' + customerId,
    method: 'delete'
  })
}
