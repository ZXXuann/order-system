package com.example.demo.filter;

import com.alibaba.fastjson.JSON;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import com.example.demo.utils.JwtUtil;
import com.example.demo.utils.RedisCache;
import com.example.demo.utils.WebUtils;
import io.jsonwebtoken.Claims;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;

@Component
public class GetFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
       try{
           filterChain.doFilter(request,response);
       } catch (Exception e){
           if(e instanceof AccessDeniedException){
               throw e;
           }else {
               e.printStackTrace();
               R r = new R(HttpStatus.BAD_REQUEST.value(), "服务器出错");
               String json = JSON.toJSONString(r);
               WebUtils.renderString(response, json);
               System.out.println("controller出错");
           }
       }
    }
}
