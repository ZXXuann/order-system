package com.example.demo.service.impl;

import java.util.List;

import com.example.demo.dao.FoodCollectMapper;
import com.example.demo.domain.FoodCollect;
import com.example.demo.service.IFoodCollectService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 规格集合Service业务层处理
 * 
 * @author zxx
 * @date 2023-01-30
 */
@Service
public class FoodCollectServiceImpl implements IFoodCollectService
{
    @Autowired
    private FoodCollectMapper foodCollectMapper;

    /**
     * 查询规格集合
     * 
     * @param collectId 规格集合主键
     * @return 规格集合
     */
    @Override
    public FoodCollect selectFoodCollectByCollectId(Long collectId)
    {
        return foodCollectMapper.selectFoodCollectByCollectId(collectId);
    }

    /**
     * 查询规格集合列表
     * 
     * @param foodCollect 规格集合
     * @return 规格集合
     */
    @Override
    public List<FoodCollect> selectFoodCollectList(FoodCollect foodCollect)
    {
        return foodCollectMapper.selectFoodCollectList(foodCollect);
    }

    /**
     * 新增规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    @Override
    public int insertFoodCollect(FoodCollect foodCollect)
    {
        foodCollect.setCreateTime(DateUtils.getNowDate());
        return foodCollectMapper.insertFoodCollect(foodCollect);
    }

    /**
     * 修改规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    @Override
    public int updateFoodCollect(FoodCollect foodCollect)
    {
        foodCollect.setUpdateTime(DateUtils.getNowDate());
        return foodCollectMapper.updateFoodCollect(foodCollect);
    }

    /**
     * 批量删除规格集合
     * 
     * @param collectIds 需要删除的规格集合主键
     * @return 结果
     */
    @Override
    public int deleteFoodCollectByCollectIds(Long[] collectIds)
    {
        return foodCollectMapper.deleteFoodCollectByCollectIds(collectIds);
    }

    /**
     * 删除规格集合信息
     * 
     * @param collectId 规格集合主键
     * @return 结果
     */
    @Override
    public int deleteFoodCollectByCollectId(Long collectId)
    {
        return foodCollectMapper.deleteFoodCollectByCollectId(collectId);
    }
}
