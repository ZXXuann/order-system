package com.example.demo.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * detail对象 order_detail
 * 
 * @author zxx
 * @date 2023-01-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetail extends BaseEntity implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 订单详情表标识 */
    private Long detailId;

    /** 订单主表标识 */

    private Long orderId;

    /** 菜品标识 */

    private Long foodId;

    /** 菜品名 */
    private String foodName;

    /** 菜品金额 */

    private BigDecimal foodPrice;

    /** 菜品数目 */

    private Long foodCount;

    /** 菜品图片 */

    private String foodImg;
    /** 附加信息 */

    private String foodAdditional;


}
