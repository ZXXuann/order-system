package com.example.demo.domain;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 红包卡券兑换码对象 discount_key
 * 
 * @author zxx
 * @date 2023-02-05
 */
public class DiscountKey extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 红包卡券兑换码标识 */
    private Long keyId;

    /** 红包卡券码 */
    private Long discountId;

    /** 红包卡券兑换码 */
    private String discountKey;

    /** 生效 */
    private String isvalidate;

    public void setKeyId(Long keyId) 
    {
        this.keyId = keyId;
    }

    public Long getKeyId() 
    {
        return keyId;
    }
    public void setDiscountId(Long discountId) 
    {
        this.discountId = discountId;
    }

    public Long getDiscountId() 
    {
        return discountId;
    }

    public String getDiscountKey() {
        return discountKey;
    }

    public void setDiscountKey(String discountKey) {
        this.discountKey = discountKey;
    }

    public void setIsvalidate(String isvalidate)
    {
        this.isvalidate = isvalidate;
    }

    public String getIsvalidate() 
    {
        return isvalidate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("keyId", getKeyId())
            .append("discountId", getDiscountId())
            .append("discountKey", getDiscountKey())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("isvalidate", getIsvalidate())
            .toString();
    }
}
