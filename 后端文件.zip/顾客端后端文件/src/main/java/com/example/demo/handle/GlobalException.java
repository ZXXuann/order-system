package com.example.demo.handle;

import com.alibaba.fastjson.JSON;
import com.example.demo.domain.R;
import com.example.demo.utils.RU;
import com.example.demo.utils.WebUtils;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@RestControllerAdvice
public class GlobalException {


//        @ExceptionHandler(value = AccessDeniedException.class)
//        @ResponseBody
//        public void exceptionHandler(HttpServletRequest req, HttpServletResponse resp,AccessDeniedException e){
//            R r = new R(HttpStatus.UNAUTHORIZED.value(), "未登录");
//            String json = JSON.toJSONString(r);
//            WebUtils.renderString(resp,json);
//        }


}