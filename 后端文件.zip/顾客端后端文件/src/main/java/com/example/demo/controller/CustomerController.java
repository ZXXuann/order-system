package com.example.demo.controller;

import com.example.demo.domain.Customer;
import com.example.demo.domain.CustomerAddress;
import com.example.demo.domain.CustomerInfo;
import com.example.demo.domain.R;
import com.example.demo.service.ICustomerAddressService;
import com.example.demo.service.ICustomerInfoService;
import com.example.demo.service.ICustomerService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping({"customer"})
public class CustomerController {
    @Autowired
    private ICustomerInfoService customerService;
    @Autowired
    private ICustomerAddressService customerAddressService;
    @GetMapping("address")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getAddress(){
        return customerAddressService.selectCustomerAddressList();
    }
    @PostMapping("updAddress")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R updAddress(CustomerAddress customerAddress){
        return RU.OK(customerAddressService.updateCustomerAddress(customerAddress));
    }
    @GetMapping("delAddress/{id}")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R updAddress(@PathVariable("id") Long id){
        return RU.OK(customerAddressService.deleteCustomerAddressById(id));
    }
    @PostMapping("insertAddress")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R insertAddress(CustomerAddress customerAddress){
        return RU.OK(customerAddressService.insertCustomerAddress(customerAddress));
    }
    @GetMapping("info")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getCustomerInfo(){
        return customerService.getCustomer();
    }
    @PostMapping("updinfo")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R updateCustomer(CustomerInfo customerInfo){
//        System.out.println(customerInfo);
        return RU.OK(customerService.updateCustomerInfo(customerInfo));
    }
    @PostMapping("updPwd")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R updateCustomerPwd(CustomerInfo customerInfo){
        return RU.OK(customerService.updateCustomerPwd(customerInfo));
    }

}
