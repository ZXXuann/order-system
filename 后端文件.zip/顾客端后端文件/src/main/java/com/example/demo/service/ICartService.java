package com.example.demo.service;

import com.example.demo.domain.Cart;
import com.example.demo.domain.R;

public interface ICartService {
    public R postOrder(Cart cart);
}
