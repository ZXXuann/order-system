package com.example.demo.service;


import com.example.demo.domain.CustomerDiscount;
import com.example.demo.domain.DiscountInfo;

import java.util.List;

/**
 * 用户卡券Service接口
 * 
 * @author ruoyi
 * @date 2023-01-20
 */
public interface ICustomerDiscountService 
{
    /**
     * 查询用户卡券
     * 
     * @param cdId 用户卡券主键
     * @return 用户卡券
     */
    public CustomerDiscount selectCustomerDiscountByCdId(Long cdId);

    List selectNoValidateDiscountList();

    /**
     * 查询用户卡券列表
     * 
     * @param customerDiscount 用户卡券
     * @return 用户卡券集合
     */
    public List selectCustomerDiscountList();


    List selectDiscountByCondition(DiscountInfo tmp);

    List selectCustomerDiscountList(DiscountInfo tmp);

    /**
     * 新增用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    public int insertCustomerDiscount(CustomerDiscount customerDiscount);

    /**
     * 修改用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    public int updateCustomerDiscount(CustomerDiscount customerDiscount);

    /**
     * 批量删除用户卡券
     * 
     * @param cdIds 需要删除的用户卡券主键集合
     * @return 结果
     */
    public int deleteCustomerDiscountByCdIds(Long[] cdIds);

    /**
     * 删除用户卡券信息
     * 
     * @param cdId 用户卡券主键
     * @return 结果
     */
    public int deleteCustomerDiscountByCdId(Long cdId);
}
