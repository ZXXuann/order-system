package com.example.demo.controller;

import com.example.demo.dao.CustomerMapper;
import com.example.demo.domain.Customer;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("demo")
public class TestController {
    @Autowired
    CustomerMapper customerMapper;

    @GetMapping("test")
    @PreAuthorize("hasAuthority('helo::word::nihao')")
    public R test(){
        List<Customer> customerList=customerMapper.selectList(null);
        return new R<>(200,customerList.get(0));
    }
}
