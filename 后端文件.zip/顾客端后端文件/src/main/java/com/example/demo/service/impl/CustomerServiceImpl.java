package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.demo.dao.CustomerMapper;
import com.example.demo.domain.Customer;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import com.example.demo.service.ICustomerService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements ICustomerService {
    @Autowired
    CustomerMapper customerMapper;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Override
    public R getCustomer() {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        QueryWrapper<Customer> wrapper = new QueryWrapper<>();
        wrapper.eq("customer_id",id);
        Customer user = customerMapper.selectOne(wrapper);
        return RU.OK(user);
    }

    @Override
    public R updateCustomer(Customer customer) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        customer.setCustomerId(id);
        int ret = customerMapper.updateById(customer);
        return RU.OK(ret);
    }

    @Override
    public R updateCustomerPwd(Customer customer) {
        return null;
    }


}
