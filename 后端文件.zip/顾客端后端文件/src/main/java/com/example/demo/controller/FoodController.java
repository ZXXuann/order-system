package com.example.demo.controller;

import com.example.demo.domain.R;
import com.example.demo.service.IFoodRecommendationService;
import com.example.demo.service.IFoodService;
import com.example.demo.service.IFoodTypeService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"anms","food"})
public class FoodController {
    @Autowired
    private IFoodService foodService;
    @Autowired
    private IFoodTypeService foodTypeService;
    @Autowired
    private IFoodRecommendationService foodRecommendationService;
    @GetMapping("allfood")
    public R getFoodAndFoodType(){
        return foodTypeService.getFoodTypeAndFood();
    }
    @GetMapping("recFood")
    public R recommendFood(){
        return foodRecommendationService.selectFoodRecommendationList();
    }
}
