package com.example.demo.domain;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("index_pic")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IndexPic implements Serializable {
    @TableId("index_id")
    private Integer indexId;
    private String indexImg;
    private String indexDetail;
    private String indexStatus;
    private Date createTime;
    private String createBy;
    private String updateBy;
    private String updateTime;
}
