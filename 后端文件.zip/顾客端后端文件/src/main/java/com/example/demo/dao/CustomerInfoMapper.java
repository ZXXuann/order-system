package com.example.demo.dao;


import com.example.demo.domain.CustomerInfo;

import java.util.List;

/**
 * customerMapper接口
 * 
 * @author zxx
 * @date 2023-01-16
 */
public interface CustomerInfoMapper 
{
    /**
     * 查询customer
     * 
     * @param customerId customer主键
     * @return customer
     */
    public CustomerInfo selectCustomerInfoByCustomerId(Long customerId);

    /**
     * 查询customer列表
     * 
     * @param customerInfo customer
     * @return customer集合
     */
    public List<CustomerInfo> selectCustomerInfoList(CustomerInfo customerInfo);

    /**
     * 新增customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    public int insertCustomerInfo(CustomerInfo customerInfo);

    /**
     * 修改customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    public int updateCustomerInfo(CustomerInfo customerInfo);

    /**
     * 删除customer
     * 
     * @param customerId customer主键
     * @return 结果
     */
    public int deleteCustomerInfoByCustomerId(Long customerId);

    /**
     * 批量删除customer
     * 
     * @param customerIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteCustomerInfoByCustomerIds(Long[] customerIds);
}
