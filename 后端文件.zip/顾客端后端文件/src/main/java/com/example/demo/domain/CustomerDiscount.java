package com.example.demo.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;


/**
 * 用户卡券对象 customer_discount
 * 
 * @author zxx
 * @date 2023-01-20
 */
public class CustomerDiscount extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 标识 */
    private Long cdId;

    /** 顾客标识 */

    private Long customerId;

    /** 折扣标识 */

    private Long discountId;
    /** 过期时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")

    private Date validate;
    public void setCdId(Long cdId) 
    {
        this.cdId = cdId;
    }

    public Long getCdId() 
    {
        return cdId;
    }
    public void setCustomerId(Long customerId) 
    {
        this.customerId = customerId;
    }

    public Long getCustomerId() 
    {
        return customerId;
    }
    public void setDiscountId(Long discountId) 
    {
        this.discountId = discountId;
    }
    public void setValidate(Date validate)
    {
        this.validate = validate;
    }

    public Date getValidate()
    {
        return validate;
    }
    public Long getDiscountId() 
    {
        return discountId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("cdId", getCdId())
            .append("customerId", getCustomerId())
            .append("discountId", getDiscountId())
            .toString();
    }
}
