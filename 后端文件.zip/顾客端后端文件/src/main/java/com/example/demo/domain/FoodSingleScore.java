package com.example.demo.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

/**
 * foodSingleScore对象 food_single_score
 * 
 * @author zxx
 * @date 2023-02-28
 */
public class FoodSingleScore extends BaseEntity
{
    private static final long serialVersionUID = 1L;
    /** 单个评分标识 */
    private Long singleId;

    /** 顾客标识 */
    private Long customerId;

    /** 订单标识 */

    private Long orderId;
    /** 菜品标识 */

    private Long foodId;

    /** 平均总体评分（0-5星） */

    private String score;
    /** 单个菜品评分（0-5星） */

    public Long getFoodId() {
        return foodId;
    }

    public void setFoodId(Long foodId) {
        this.foodId = foodId;
    }

    public Long getSingleId() {
        return singleId;
    }

    public void setSingleId(Long singleId) {
        this.singleId = singleId;
    }

    public void setCustomerId(Long customerId)
    {
        this.customerId = customerId;
    }

    public Long getCustomerId() 
    {
        return customerId;
    }
    public void setOrderId(Long orderId)
    {
        this.orderId = orderId;
    }

    public Long getOrderId()
    {
        return orderId;
    }
    public void setScore(String score) 
    {
        this.score = score;
    }

    public String getScore() 
    {
        return score;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("singleId", getSingleId())
            .append("customerId", getCustomerId())
            .append("orderId", getOrderId())
            .append("foodId", getOrderId())
            .append("score", getScore())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
