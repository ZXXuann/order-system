package com.example.demo.dao;

import com.example.demo.domain.FoodSingleScore;

import java.util.List;


/**
 * 【请填写功能名称】Mapper接口
 * 
 * @author zxx
 * @date 2023-02-28
 */
public interface FoodSingleScoreMapper 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param singleId 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public FoodSingleScore selectFoodSingleScoreBySingleId(Long singleId);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<FoodSingleScore> selectFoodSingleScoreList(FoodSingleScore foodSingleScore);

    /**
     * 新增【请填写功能名称】
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 结果
     */
    public int insertFoodSingleScore(FoodSingleScore foodSingleScore);

    /**
     * 修改【请填写功能名称】
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 结果
     */
    public int updateFoodSingleScore(FoodSingleScore foodSingleScore);

    /**
     * 删除【请填写功能名称】
     * 
     * @param singleId 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteFoodSingleScoreBySingleId(Long singleId);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param singleIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFoodSingleScoreBySingleIds(Long[] singleIds);
}
