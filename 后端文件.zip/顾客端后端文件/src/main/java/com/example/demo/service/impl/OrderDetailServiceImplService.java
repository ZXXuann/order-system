package com.example.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.OrderDetailMapper;
import com.example.demo.dao.OrderInfoMapper;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.OrderDetail;
import com.example.demo.domain.OrderInfo;
import com.example.demo.domain.R;
import com.example.demo.service.IOrderDetailService;
import com.example.demo.service.IOrderInfoService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OrderDetailServiceImplService implements IOrderDetailService {
    @Autowired
    private OrderDetailMapper orderDetailMapper;
    @Autowired
    private OrderInfoMapper orderInfoMapper;
    @Override
    public R getOrderDetail(OrderDetail orderDetail) {
        OrderInfo orderInfo = new OrderInfo();
        orderInfo.setOrderId(orderDetail.getOrderId());
//        Map map = JSON.parseObject(JSON.toJSONString(orderInfo), Map.class);
        OrderInfo temp = orderInfoMapper.selectOrderInfoByOrderId(orderInfo.getOrderId());
        Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(temp,"yyyy-MM-dd HH:mm:ss"), Map.class);
        map.put("items",orderDetailMapper.selectOrderDetailList(orderDetail));
        return RU.OK(map);
    }
}
