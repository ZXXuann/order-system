package com.example.demo.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 菜品类型对象 food_type
 * 
 * @author zxx
 * @date 2023-01-09
 */
public class FoodType extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 菜品类型标识 */
    private Long foodtypeId;

    /** 菜品类型图片 */
    private String foddtypeImg;

    /** 菜品类型名 */
    private String foodtypeName;

    /** 菜品类型详细 */
    private String foodtypeDetail;

    public void setFoodtypeId(Long foodtypeId) 
    {
        this.foodtypeId = foodtypeId;
    }

    public Long getFoodtypeId() 
    {
        return foodtypeId;
    }
    public void setFoddtypeImg(String foddtypeImg) 
    {
        this.foddtypeImg = foddtypeImg;
    }

    public String getFoddtypeImg() 
    {
        return foddtypeImg;
    }
    public void setFoodtypeName(String foodtypeName) 
    {
        this.foodtypeName = foodtypeName;
    }

    public String getFoodtypeName() 
    {
        return foodtypeName;
    }
    public void setFoodtypeDetail(String foodtypeDetail) 
    {
        this.foodtypeDetail = foodtypeDetail;
    }

    public String getFoodtypeDetail() 
    {
        return foodtypeDetail;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("foodtypeId", getFoodtypeId())
            .append("foddtypeImg", getFoddtypeImg())
            .append("foodtypeName", getFoodtypeName())
            .append("foodtypeDetail", getFoodtypeDetail())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
