package com.example.demo.service;

import com.example.demo.domain.R;

public interface IIndexService {
    R getPic();
}
