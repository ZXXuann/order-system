package com.example.demo.service.impl;

import com.example.demo.dao.*;
import com.example.demo.domain.*;
import com.example.demo.service.ICartService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class CartService implements ICartService {
    @Autowired
    private OrderDetailMapper orderDetailMapper;
    @Autowired
    private OrderInfoMapper orderInfoMapper;
    @Autowired
    private FoodMapper foodMapper;
    @Autowired
    private CustomerDiscountMapper customerDiscountMapper;
    @Autowired
    private DiscountInfoMapper discountInfoMapper;
    @Autowired
    private FoodSepcificationMapper foodSepcificationMapper;
    @Override
    @Transactional
    public R postOrder(Cart cart) {
        //获取customer的id
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();

        //获取cart的内容 塞进orderInfo 然后塞进数据库
        OrderInfo orderInfo = new OrderInfo();

        orderInfo.setCustomerId((long) id);
        orderInfo.setChairNo((long) cart.getChairNo());
        orderInfo.setCustomerAddr(cart.getCustomerAddr());
        orderInfo.setCustomerName(cart.getCustomerName());
        orderInfo.setCustomerPhone(cart.getCustomerPhone());
        orderInfo.setOrderType(cart.getOrderType());
        orderInfo.setPayStatus(1);
        //先插进去 然后就有orderID了
        orderInfoMapper.insertOrderInfo(orderInfo);

        //遍历循环取出food的内容 塞进orderDetail 然后塞进数据库
        List<CartFood> foods = cart.getFoods();
        BigDecimal sum=new BigDecimal(0);
        DiscountInfo discountInfo =null;

        //循环金额加加加 并且 订单详细插插插
        for(CartFood food:foods){
            Food temp = foodMapper.selectFoodByFoodId((long) food.getFoodId());
            System.out.println(temp.getFoodPrice()+":"+food.getFoodNumber());

            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setFoodCount((long) food.getFoodNumber());
            orderDetail.setFoodId((long) food.getFoodId());
            orderDetail.setFoodImg(temp.getFoodImg());
            BigDecimal foodPrice = temp.getFoodPrice();
            String add="";
            BigDecimal multiply =new BigDecimal(0);
            //判断是否有规格
            if(temp.getIsSingle()!=0&&food.getSpeciIds()!=null&&food.getSpeciIds().length>0){
                    //获取规格信息(价格) 然后+++++++ 赚钱搞钱！！！
                    Integer[] specfi=food.getSpeciIds();
                    for(Integer i:specfi){
                        System.out.println(i);
                        FoodSepcification fs
                                = foodSepcificationMapper.selectFoodSepcificationBySpcfId((long) i);
                        foodPrice=foodPrice.add(fs.getSpcfPrice());
                        multiply = foodPrice.multiply(new BigDecimal(food.getFoodNumber()));
                        System.out.println(multiply);
                        add=fs.getSpcfName()+","+add;
                    }
            }else{
                //若无规格，那么就按原先价格添加
                multiply = foodPrice.multiply(new BigDecimal(food.getFoodNumber()));
            }
            orderDetail.setFoodPrice(foodPrice);
            orderDetail.setFoodAdditional(add);
            orderDetail.setOrderId(orderInfo.getOrderId());
            orderDetail.setFoodName(temp.getFoodName());
            orderDetail.setFoodCount((long) food.getFoodNumber());
            orderDetailMapper.insertOrderDetail(orderDetail);
            sum=sum.add(multiply);
            System.out.println("sum"+sum);
        }



        if(cart.getCdId()!=null){
            CustomerDiscount customerDiscount
                    = customerDiscountMapper.selectCustomerDiscountByCdId(Long.valueOf(cart.getCdId()));
            if(customerDiscount!=null&&customerDiscount.getCustomerId()!=null&&customerDiscount.getCustomerId().intValue()==id){
                DiscountInfo tmp=new DiscountInfo();
                tmp.setDiscountId(customerDiscount.getDiscountId());
                tmp.setDiscountCondition(sum);
                //减去消费券的优惠
                discountInfo = discountInfoMapper.selectDiscountInfoByCondition(tmp);
                if(discountInfo!=null&&discountInfo.getDiscountId()!=null) {
                    //让其失效
                    customerDiscount.setValidate(new Date(System.currentTimeMillis()));
                    customerDiscountMapper.updateCustomerDiscount(customerDiscount);
                    //填入订单优惠信息
                    orderInfo.setDiscountId(String.valueOf(discountInfo.getDiscountId()));
                    orderInfo.setDiscountAmount(discountInfo.getDiscountAccount());
                    orderInfo.setDiscountDetail(discountInfo.getDiscountDetail());
                    //删除总数
                    sum=sum.subtract(discountInfo.getDiscountAccount());
                }else{
                    return RU.NO();
                }
            }
        }

//        if(discountInfo!=null){
//            sum=sum.subtract(discountInfo.getDiscountAccount());
//        }

        orderInfo.setOrderAmount(sum);
        System.out.println(sum);


        orderInfoMapper.updateOrderInfo(orderInfo);
        return RU.OK("操作成功");
    }
}
