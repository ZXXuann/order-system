package com.example.demo.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 *
 * @author zxx
 * @date 2023-01-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartFood {
    private int foodId;
    private int foodNumber;
    private Integer[] speciIds;
}
