package com.example.demo.service;

import com.example.demo.domain.FoodCollect;

import java.util.List;


/**
 * 规格集合Service接口
 * 
 * @author zxx
 * @date 2023-01-30
 */
public interface IFoodCollectService 
{
    /**
     * 查询规格集合
     * 
     * @param collectId 规格集合主键
     * @return 规格集合
     */
    public FoodCollect selectFoodCollectByCollectId(Long collectId);

    /**
     * 查询规格集合列表
     * 
     * @param foodCollect 规格集合
     * @return 规格集合集合
     */
    public List<FoodCollect> selectFoodCollectList(FoodCollect foodCollect);

    /**
     * 新增规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    public int insertFoodCollect(FoodCollect foodCollect);

    /**
     * 修改规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    public int updateFoodCollect(FoodCollect foodCollect);

    /**
     * 批量删除规格集合
     * 
     * @param collectIds 需要删除的规格集合主键集合
     * @return 结果
     */
    public int deleteFoodCollectByCollectIds(Long[] collectIds);

    /**
     * 删除规格集合信息
     * 
     * @param collectId 规格集合主键
     * @return 结果
     */
    public int deleteFoodCollectByCollectId(Long collectId);
}
