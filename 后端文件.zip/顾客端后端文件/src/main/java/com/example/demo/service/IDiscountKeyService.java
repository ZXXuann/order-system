package com.example.demo.service;

import com.example.demo.domain.DiscountKey;
import com.example.demo.domain.R;

import java.util.List;

/**
 * 红包卡券兑换码Service接口
 * 
 * @author zxx
 * @date 2023-02-05
 */
public interface IDiscountKeyService 
{
    R exchangeKey(DiscountKey discountKey) throws Exception;

    /**
     * 查询红包卡券兑换码
     * 
     * @param keyId 红包卡券兑换码主键
     * @return 红包卡券兑换码
     */
    public DiscountKey selectDiscountKeyByKeyId(Long keyId);

    /**
     * 查询红包卡券兑换码列表
     * 
     * @param discountKey 红包卡券兑换码
     * @return 红包卡券兑换码集合
     */
    public List<DiscountKey> selectDiscountKeyList(DiscountKey discountKey);

    /**
     * 新增红包卡券兑换码
     * 
     * @param discountKey 红包卡券兑换码
     * @return 结果
     */
    public int insertDiscountKey(DiscountKey discountKey);

    /**
     * 修改红包卡券兑换码
     * 
     * @param discountKey 红包卡券兑换码
     * @return 结果
     */
    public int updateDiscountKey(DiscountKey discountKey);

    /**
     * 批量删除红包卡券兑换码
     * 
     * @param keyIds 需要删除的红包卡券兑换码主键集合
     * @return 结果
     */
    public int deleteDiscountKeyByKeyIds(Long[] keyIds);

    /**
     * 删除红包卡券兑换码信息
     * 
     * @param keyId 红包卡券兑换码主键
     * @return 结果
     */
    public int deleteDiscountKeyByKeyId(Long keyId);
}
