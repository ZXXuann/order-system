package com.example.demo.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.FoodCollectMapper;
import com.example.demo.dao.FoodSepcificationMapper;
import com.example.demo.dao.FoodTypeMapper;
import com.example.demo.domain.*;
import com.example.demo.service.IFoodCollectService;
import com.example.demo.service.IFoodSepcificationService;
import com.example.demo.service.IFoodService;
import com.example.demo.service.IFoodTypeService;
import com.example.demo.utils.DateUtils;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * 菜品类型Service业务层处理
 * 
 * @author zxx
 * @date 2023-01-09
 */
@Service
public class FoodTypeServiceImpl implements IFoodTypeService
{
    @Autowired
    private FoodTypeMapper foodTypeMapper;
    @Autowired
    private IFoodService foodService;
    @Autowired
    private FoodSepcificationMapper foodSepcificationMapper;
    @Autowired
    private FoodCollectMapper foodCollectMapper;
    /**
     * 查询菜品类型
     * 
     * @param foodtypeId 菜品类型主键
     * @return 菜品类型
     */
    @Override
    public FoodType selectFoodTypeByFoodtypeId(Long foodtypeId)
    {
        return foodTypeMapper.selectFoodTypeByFoodtypeId(foodtypeId);
    }

    /**
     * 查询菜品类型列表
     * 
     * @param foodType 菜品类型
     * @return 菜品类型
     */
    @Override
    public List<FoodType> selectFoodTypeList(FoodType foodType)
    {
        return foodTypeMapper.selectFoodTypeList(foodType);
    }

    /**
     * 新增菜品类型
     * 
     * @param foodType 菜品类型
     * @return 结果
     */
    @Override
    public int insertFoodType(FoodType foodType)
    {
        foodType.setCreateTime(DateUtils.getNowDate());
        return foodTypeMapper.insertFoodType(foodType);
    }

    /**
     * 修改菜品类型
     * 
     * @param foodType 菜品类型
     * @return 结果
     */
    @Override
    public int updateFoodType(FoodType foodType)
    {
        foodType.setUpdateTime(DateUtils.getNowDate());
        return foodTypeMapper.updateFoodType(foodType);
    }

    /**
     * 批量删除菜品类型
     * 
     * @param foodtypeIds 需要删除的菜品类型主键
     * @return 结果
     */
    @Override
    public int deleteFoodTypeByFoodtypeIds(Long[] foodtypeIds)
    {
        return foodTypeMapper.deleteFoodTypeByFoodtypeIds(foodtypeIds);
    }

    /**
     * 删除菜品类型信息
     * 
     * @param foodtypeId 菜品类型主键
     * @return 结果
     */
    @Override
    public int deleteFoodTypeByFoodtypeId(Long foodtypeId)
    {
        return foodTypeMapper.deleteFoodTypeByFoodtypeId(foodtypeId);
    }

    @Override
    public R getFoodTypeAndFood(){
//        OrderInfo temp = orderInfoMapper.selectOrderInfoByOrderId(orderInfo.getOrderId());
//        Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(temp,"yyyy-MM-dd HH:mm:ss"), Map.class);
//        map.put("items",orderDetailMapper.selectOrderDetailList(orderDetail));
        List temp=new ArrayList();
        List<FoodType> lists=foodTypeMapper.selectFoodTypeList(null);
        for(FoodType list:lists){
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(list,"yyyy-MM-dd HH:mm:ss"), Map.class);
            Food food=new Food();
            food.setFoodType(list.getFoodtypeId());
//            String[] words = line.split(" ");
            List<Map> foods = foodService.selectFoodList(food);
            for(Map tmp:foods){
                if((Integer)tmp.get("isSingle")!=0){
                    //取出food的规格
                    FoodSepcification foodSepcification = new FoodSepcification();
                    foodSepcification.setFoodId(Long.valueOf((Integer) tmp.get("foodId")));
                    List<FoodSepcification>
                            fsmp = foodSepcificationMapper.selectFoodSepcificationList(foodSepcification);
                    Map fsmap=new HashMap();
                    //采用类似缓存机制(缓存字典) 减少数据库访问 用map装之前查过的内容 若未查过 则直接查询
                    Map dic=new HashMap();
                    for(FoodSepcification fs:fsmp){
                        String o2 = (String) dic.get(fs.getCollectId());
                        String collectName=o2;
                        if(o2==null||o2.length()<0) {
                            collectName=foodCollectMapper.selectFoodCollectByCollectId(fs.getCollectId()).getCollectName();
                            dic.put(fs.getCollectId(),collectName);
                        }
                        List o1 = (List) fsmap.get(collectName);
                        List o = o1!=null?o1:new ArrayList<>();
                        o.add(fs);
                        fsmap.put(collectName,o);
                    }
                    //处理返回值问题 使得以key和value输出
                    Set set = fsmap.keySet();
                    Iterator iterator =set.iterator();
                    List mp=new ArrayList();
                    while(iterator.hasNext()){
                        String next = (String) iterator.next();//规格：key
                        Object o = fsmap.get(next);//选项：list
                        Map map1=new HashMap();
                        map1.put("chose",o);
                        map1.put("name",next);
                        mp.add(map1);
                    }
//                    Map fsmap=new HashMap();
//                    fsmap.put("spcf",fsmp);
                    tmp.put("spcf",mp);
                }
            }
            map.put("items", foods);
            temp.add(map);
        }
        return RU.OK(temp);
    }
}
