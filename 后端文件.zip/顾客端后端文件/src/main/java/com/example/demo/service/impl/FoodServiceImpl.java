package com.example.demo.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.FoodMapper;
import com.example.demo.domain.Food;
import com.example.demo.domain.FoodType;
import com.example.demo.service.IFoodService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 菜品管理Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-01-09
 */
@Service
public class FoodServiceImpl implements IFoodService
{
    @Autowired
    private FoodMapper foodMapper;

    /**
     * 查询菜品管理
     * 
     * @param foodId 菜品管理主键
     * @return 菜品管理
     */
    @Override
    public Food selectFoodByFoodId(Long foodId)
    {
        return foodMapper.selectFoodByFoodId(foodId);
    }

    /**
     * 查询菜品管理列表
     * 
     * @param food 菜品管理
     * @return 菜品管理
     */
    @Override
    public List<Map> selectFoodList(Food food)
    {
        List<Food> foods = foodMapper.selectFoodList(food);
        List temp=new ArrayList();
        for(Food list:foods){
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(list,"yyyy-MM-dd HH:mm:ss"), Map.class);
            String[] img = list.getFoodImg().split(",");
            map.put("foodImgs", img);
            map.remove("foodImg");
            temp.add(map);
        }
        return temp;
    }

    /**
     * 新增菜品管理
     * 
     * @param food 菜品管理
     * @return 结果
     */
    @Override
    public int insertFood(Food food)
    {
        food.setCreateTime(DateUtils.getNowDate());
        return foodMapper.insertFood(food);
    }

    /**
     * 修改菜品管理
     * 
     * @param food 菜品管理
     * @return 结果
     */
    @Override
    public int updateFood(Food food)
    {
        food.setUpdateTime(DateUtils.getNowDate());
        return foodMapper.updateFood(food);
    }

    /**
     * 批量删除菜品管理
     * 
     * @param foodIds 需要删除的菜品管理主键
     * @return 结果
     */
    @Override
    public int deleteFoodByFoodIds(Long[] foodIds)
    {
        return foodMapper.deleteFoodByFoodIds(foodIds);
    }

    /**
     * 删除菜品管理信息
     * 
     * @param foodId 菜品管理主键
     * @return 结果
     */
    @Override
    public int deleteFoodByFoodId(Long foodId)
    {
        return foodMapper.deleteFoodByFoodId(foodId);
    }
}
