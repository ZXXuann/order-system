package com.example.demo.domain;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
@TableName("customer_perms")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Perms implements Serializable {
    @TableId("id")
    private Integer id;
    private String perms;
    private Long createBy;

    private Date createTime;

    private Integer updateBy;

    private Date updateTime;

    private Integer delFlag;

    private String remark;
}
