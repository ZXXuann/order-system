package com.example.demo.service;

import com.example.demo.domain.Customer;
import com.example.demo.domain.R;

public interface ICustomerService {
    R getCustomer();
    R updateCustomer(Customer customer);

    R updateCustomerPwd(Customer customer);
}
