package com.example.demo.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * info对象 order_info
 * 
 * @author zxx
 * @date 2023-01-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderInfo extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 订单主表标识 */
    private Long orderId;

    /** 顾客名称 */

    private String customerName;

    /** 顾客地址 */

    private String customerAddr;

    /** 顾客标识 */

    private Long customerId;

    /** 订单金额 */

    private BigDecimal orderAmount;

    /** 订单类型（1外卖 2堂食） */

    private Integer orderType;

    /** 订单状态 */

    private Integer orderStatus;

    /** 支付状态 */

    private Integer payStatus;

    /** 桌号 */

    private Long chairNo;
    /** 评价 */
    private Integer iseval;
    /**优惠券详细*/
    private String discountDetail;
    /**优惠券金额*/
    private BigDecimal discountAmount;
    /**优惠券编号*/
    private String discountId;
    /** 顾客的手机 */

    private String customerPhone;
}
