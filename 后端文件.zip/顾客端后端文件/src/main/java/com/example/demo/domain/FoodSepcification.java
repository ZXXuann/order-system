package com.example.demo.domain;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * 菜品规格对象 food_sepcification
 * 
 * @author zxx
 * @date 2023-01-30
 */
public class FoodSepcification extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 规格标识 */
    private Long spcfId;

    /** 规格所属集合 */

    private Long collectId;

    /** 菜品名称 */

    private Long foodId;

    /** 规格名 */

    private String spcfName;

    /** 规格价格(增量) */

    private BigDecimal spcfPrice;

    public void setSpcfId(Long spcfId) 
    {
        this.spcfId = spcfId;
    }

    public Long getSpcfId() 
    {
        return spcfId;
    }
    public void setCollectId(Long collectId) 
    {
        this.collectId = collectId;
    }

    public Long getCollectId() 
    {
        return collectId;
    }
    public void setFoodId(Long foodId) 
    {
        this.foodId = foodId;
    }

    public Long getFoodId() 
    {
        return foodId;
    }
    public void setSpcfName(String spcfName) 
    {
        this.spcfName = spcfName;
    }

    public String getSpcfName() 
    {
        return spcfName;
    }
    public void setSpcfPrice(BigDecimal spcfPrice) 
    {
        this.spcfPrice = spcfPrice;
    }

    public BigDecimal getSpcfPrice() 
    {
        return spcfPrice;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("spcfId", getSpcfId())
            .append("collectId", getCollectId())
            .append("foodId", getFoodId())
            .append("spcfName", getSpcfName())
            .append("spcfPrice", getSpcfPrice())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
