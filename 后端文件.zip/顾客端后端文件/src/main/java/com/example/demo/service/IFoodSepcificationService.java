package com.example.demo.service;

import com.example.demo.domain.FoodSepcification;

import java.util.List;


/**
 * 菜品规格Service接口
 * 
 * @author zxx
 * @date 2023-01-30
 */
public interface IFoodSepcificationService 
{
    /**
     * 查询菜品规格
     * 
     * @param spcfId 菜品规格主键
     * @return 菜品规格
     */
    public FoodSepcification selectFoodSepcificationBySpcfId(Long spcfId);

    /**
     * 查询菜品规格列表
     * 
     * @param foodSepcification 菜品规格
     * @return 菜品规格集合
     */
    public List<FoodSepcification> selectFoodSepcificationList(FoodSepcification foodSepcification);

    /**
     * 新增菜品规格
     * 
     * @param foodSepcification 菜品规格
     * @return 结果
     */
    public int insertFoodSepcification(FoodSepcification foodSepcification);

    /**
     * 修改菜品规格
     * 
     * @param foodSepcification 菜品规格
     * @return 结果
     */
    public int updateFoodSepcification(FoodSepcification foodSepcification);

    /**
     * 批量删除菜品规格
     * 
     * @param spcfIds 需要删除的菜品规格主键集合
     * @return 结果
     */
    public int deleteFoodSepcificationBySpcfIds(Long[] spcfIds);

    /**
     * 删除菜品规格信息
     * 
     * @param spcfId 菜品规格主键
     * @return 结果
     */
    public int deleteFoodSepcificationBySpcfId(Long spcfId);
}
