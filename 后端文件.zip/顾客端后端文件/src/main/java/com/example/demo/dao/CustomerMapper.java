package com.example.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.domain.Customer;


public interface CustomerMapper extends BaseMapper<Customer> {
}
