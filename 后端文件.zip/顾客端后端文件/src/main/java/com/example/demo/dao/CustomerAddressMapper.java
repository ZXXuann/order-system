package com.example.demo.dao;

import com.example.demo.domain.Customer;
import com.example.demo.domain.CustomerAddress;

import java.util.List;

public interface CustomerAddressMapper {
    public List selectCustomerAddressList(CustomerAddress customerAddress);
    public CustomerAddress selectCustomerAddressById(Long id);
    public int insertCustomerAddress(CustomerAddress customerAddress);
    public int updateCustomerAddress(CustomerAddress customerAddress);
    public int updateCustomerAddressAll(CustomerAddress customerAddress);
    public int deleteCustomerAddressByIds(Long[] ids);
    public int deleteCustomerAddressById(Long id);
}
