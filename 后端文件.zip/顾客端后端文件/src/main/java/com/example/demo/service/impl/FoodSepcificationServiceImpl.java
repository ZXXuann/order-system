package com.example.demo.service.impl;

import java.util.List;

import com.example.demo.dao.FoodSepcificationMapper;
import com.example.demo.domain.FoodSepcification;
import com.example.demo.service.IFoodSepcificationService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 菜品规格Service业务层处理
 * 
 * @author zxx
 * @date 2023-01-30
 */
@Service
public class FoodSepcificationServiceImpl implements IFoodSepcificationService
{
    @Autowired
    private FoodSepcificationMapper foodSepcificationMapper;

    /**
     * 查询菜品规格
     * 
     * @param spcfId 菜品规格主键
     * @return 菜品规格
     */
    @Override
    public FoodSepcification selectFoodSepcificationBySpcfId(Long spcfId)
    {
        return foodSepcificationMapper.selectFoodSepcificationBySpcfId(spcfId);
    }

    /**
     * 查询菜品规格列表
     * 
     * @param foodSepcification 菜品规格
     * @return 菜品规格
     */
    @Override
    public List<FoodSepcification> selectFoodSepcificationList(FoodSepcification foodSepcification)
    {
        return foodSepcificationMapper.selectFoodSepcificationList(foodSepcification);
    }

    /**
     * 新增菜品规格
     * 
     * @param foodSepcification 菜品规格
     * @return 结果
     */
    @Override
    public int insertFoodSepcification(FoodSepcification foodSepcification)
    {
        foodSepcification.setCreateTime(DateUtils.getNowDate());
        return foodSepcificationMapper.insertFoodSepcification(foodSepcification);
    }

    /**
     * 修改菜品规格
     * 
     * @param foodSepcification 菜品规格
     * @return 结果
     */
    @Override
    public int updateFoodSepcification(FoodSepcification foodSepcification)
    {
        foodSepcification.setUpdateTime(DateUtils.getNowDate());
        return foodSepcificationMapper.updateFoodSepcification(foodSepcification);
    }

    /**
     * 批量删除菜品规格
     * 
     * @param spcfIds 需要删除的菜品规格主键
     * @return 结果
     */
    @Override
    public int deleteFoodSepcificationBySpcfIds(Long[] spcfIds)
    {
        return foodSepcificationMapper.deleteFoodSepcificationBySpcfIds(spcfIds);
    }

    /**
     * 删除菜品规格信息
     * 
     * @param spcfId 菜品规格主键
     * @return 结果
     */
    @Override
    public int deleteFoodSepcificationBySpcfId(Long spcfId)
    {
        return foodSepcificationMapper.deleteFoodSepcificationBySpcfId(spcfId);
    }
}
