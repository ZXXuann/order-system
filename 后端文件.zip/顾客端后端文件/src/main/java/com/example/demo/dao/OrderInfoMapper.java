package com.example.demo.dao;



import com.example.demo.domain.OrderInfo;

import java.util.List;

/**
 * infoMapper接口
 * 
 * @author zxx
 * @date 2023-01-09
 */
public interface OrderInfoMapper 
{
    /**
     * 查询info
     * 
     * @param orderId info主键
     * @return info
     */
    public OrderInfo selectOrderInfoByOrderId(Long orderId);
    /**
     * 查询info列表(orderstatus!=?)
     *
     * @param orderInfo info
     * @return info集合
     */
    public List<OrderInfo> selectListNotOrderStatus(OrderInfo orderInfo);
    /**
     * 查询info列表
     * 
     * @param orderInfo info
     * @return info集合
     */
    public List<OrderInfo> selectOrderInfoList(OrderInfo orderInfo);

    /**
     * 新增info
     * 
     * @param orderInfo info
     * @return 结果
     */
    public int insertOrderInfo(OrderInfo orderInfo);

    /**
     * 修改info
     * 
     * @param orderInfo info
     * @return 结果
     */
    public int updateOrderInfo(OrderInfo orderInfo);

    /**
     * 删除info
     * 
     * @param orderId info主键
     * @return 结果
     */
    public int deleteOrderInfoByOrderId(Long orderId);

    /**
     * 批量删除info
     * 
     * @param orderIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteOrderInfoByOrderIds(Long[] orderIds);
}
