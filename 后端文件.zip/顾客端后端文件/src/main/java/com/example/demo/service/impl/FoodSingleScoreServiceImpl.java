package com.example.demo.service.impl;

import java.util.List;

import com.example.demo.dao.FoodSingleScoreMapper;
import com.example.demo.domain.FoodSingleScore;
import com.example.demo.service.IFoodSingleScoreService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author zxx
 * @date 2023-02-28
 */
@Service
public class FoodSingleScoreServiceImpl implements IFoodSingleScoreService
{
    @Autowired
    private FoodSingleScoreMapper foodSingleScoreMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param singleId 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public FoodSingleScore selectFoodSingleScoreBySingleId(Long singleId)
    {
        return foodSingleScoreMapper.selectFoodSingleScoreBySingleId(singleId);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<FoodSingleScore> selectFoodSingleScoreList(FoodSingleScore foodSingleScore)
    {
        return foodSingleScoreMapper.selectFoodSingleScoreList(foodSingleScore);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertFoodSingleScore(FoodSingleScore foodSingleScore)
    {
        foodSingleScore.setCreateTime(DateUtils.getNowDate());
        return foodSingleScoreMapper.insertFoodSingleScore(foodSingleScore);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param foodSingleScore 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateFoodSingleScore(FoodSingleScore foodSingleScore)
    {
        foodSingleScore.setUpdateTime(DateUtils.getNowDate());
        return foodSingleScoreMapper.updateFoodSingleScore(foodSingleScore);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param singleIds 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteFoodSingleScoreBySingleIds(Long[] singleIds)
    {
        return foodSingleScoreMapper.deleteFoodSingleScoreBySingleIds(singleIds);
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param singleId 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteFoodSingleScoreBySingleId(Long singleId)
    {
        return foodSingleScoreMapper.deleteFoodSingleScoreBySingleId(singleId);
    }
}
