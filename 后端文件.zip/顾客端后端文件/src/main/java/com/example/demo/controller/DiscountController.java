package com.example.demo.controller;

import com.example.demo.domain.DiscountInfo;
import com.example.demo.domain.DiscountKey;
import com.example.demo.domain.R;
import com.example.demo.service.ICustomerDiscountService;
import com.example.demo.service.IDiscountKeyService;
import com.example.demo.utils.PageUtil;
import com.example.demo.utils.RU;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping({"discount"})
public class DiscountController {
    @Autowired
    private ICustomerDiscountService customerDiscountService;
    @Autowired
    private IDiscountKeyService discountKeyService;
    @GetMapping("/discountinfo")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getInfo() throws Exception {
        PageHelper.startPage(PageUtil.getPageDomain());
        List list = customerDiscountService.selectCustomerDiscountList();
        return RU.OK(list);
    }
    @GetMapping("/novalidatediscountinfo")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getNoValidateInfo(){
        PageHelper.startPage(PageUtil.getPageDomain());
        List list = customerDiscountService.selectNoValidateDiscountList();
        return RU.OK(list);
    }
    @GetMapping("/validCondition")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getValidByCondition(DiscountInfo discountInfo){
        PageHelper.startPage(PageUtil.getPageDomain());
        List list = customerDiscountService.selectCustomerDiscountList(discountInfo);
        return RU.OK(list);
    }
    @PostMapping("/exchangeKey")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R exchangeKey(DiscountKey discountKey) throws Exception {
        return discountKeyService.exchangeKey(discountKey);
    }
}
