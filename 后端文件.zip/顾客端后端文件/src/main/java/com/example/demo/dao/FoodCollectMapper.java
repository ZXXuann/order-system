package com.example.demo.dao;

import com.example.demo.domain.FoodCollect;

import java.util.List;


/**
 * 规格集合Mapper接口
 * 
 * @author zxx
 * @date 2023-01-30
 */
public interface FoodCollectMapper 
{
    /**
     * 查询规格集合
     * 
     * @param collectId 规格集合主键
     * @return 规格集合
     */
    public FoodCollect selectFoodCollectByCollectId(Long collectId);

    /**
     * 查询规格集合列表
     * 
     * @param foodCollect 规格集合
     * @return 规格集合集合
     */
    public List<FoodCollect> selectFoodCollectList(FoodCollect foodCollect);

    /**
     * 新增规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    public int insertFoodCollect(FoodCollect foodCollect);

    /**
     * 修改规格集合
     * 
     * @param foodCollect 规格集合
     * @return 结果
     */
    public int updateFoodCollect(FoodCollect foodCollect);

    /**
     * 删除规格集合
     * 
     * @param collectId 规格集合主键
     * @return 结果
     */
    public int deleteFoodCollectByCollectId(Long collectId);

    /**
     * 批量删除规格集合
     * 
     * @param collectIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFoodCollectByCollectIds(Long[] collectIds);
}
