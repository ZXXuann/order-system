package com.example.demo.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


/**
 * 规格集合对象 food_collect
 * 
 * @author zxx
 * @date 2023-01-30
 */
public class FoodCollect extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 集合标识 */
    private Long collectId;

    /** 集合名称 */

    private String collectName;

    public void setCollectId(Long collectId) 
    {
        this.collectId = collectId;
    }

    public Long getCollectId() 
    {
        return collectId;
    }
    public void setCollectName(String collectName) 
    {
        this.collectName = collectName;
    }

    public String getCollectName() 
    {
        return collectName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("collectId", getCollectId())
            .append("collectName", getCollectName())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
