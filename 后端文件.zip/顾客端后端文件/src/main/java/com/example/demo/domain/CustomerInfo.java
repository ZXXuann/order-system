package com.example.demo.domain;



/**
 * customer对象 customer_info
 * 
 * @author zxx
 * @date 2023-01-16
 */
public class CustomerInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 顾客标识 */
    private Long customerId;

    /** 第三方用户开放标识 */
    private String openId;

    /** 顾客姓名 */

    private String customerName;

    /** 顾客密码 */

    private String customerPasswd;

    /** 顾客的手机 */

    private String customerPhone;

    /** 顾客地址 */

    private String customerAddr;

    /** 顾客昵称 */

    private String nickname;

    /** 顾客身份号码 */

    private String idNo;

    /** 顾客角色(会员 普通会员 封禁等) */

    private Long customerType;

    /** 0未删除 1已删除 */
    private String delFlag;

    /** 性别 */
    private Integer customerSex;

    /** 顾客积分 */

    private Long customerScore;


    public void setCustomerId(Long customerId) 
    {
        this.customerId = customerId;
    }

    public Long getCustomerId() 
    {
        return customerId;
    }
    public void setOpenId(String openId) 
    {
        this.openId = openId;
    }

    public String getOpenId() 
    {
        return openId;
    }
    public void setCustomerName(String customerName) 
    {
        this.customerName = customerName;
    }

    public String getCustomerName() 
    {
        return customerName;
    }
    public void setCustomerPasswd(String customerPasswd) 
    {
        this.customerPasswd = customerPasswd;
    }

    public String getCustomerPasswd() 
    {
        return customerPasswd;
    }
    public void setCustomerPhone(String customerPhone) 
    {
        this.customerPhone = customerPhone;
    }

    public String getCustomerPhone() 
    {
        return customerPhone;
    }
    public void setCustomerAddr(String customerAddr) 
    {
        this.customerAddr = customerAddr;
    }

    public String getCustomerAddr() 
    {
        return customerAddr;
    }
    public void setNickname(String nickname) 
    {
        this.nickname = nickname;
    }

    public String getNickname() 
    {
        return nickname;
    }
    public void setIdNo(String idNo) 
    {
        this.idNo = idNo;
    }

    public String getIdNo() 
    {
        return idNo;
    }
    public void setCustomerType(Long customerType) 
    {
        this.customerType = customerType;
    }

    public Long getCustomerType() 
    {
        return customerType;
    }
    public void setDelFlag(String delFlag) 
    {
        this.delFlag = delFlag;
    }

    public String getDelFlag() 
    {
        return delFlag;
    }
    public void setCustomerSex(Integer customerSex)
    {
        this.customerSex = customerSex;
    }

    public Integer getCustomerSex()
    {
        return customerSex;
    }
    public void setCustomerScore(Long customerScore) 
    {
        this.customerScore = customerScore;
    }

    public Long getCustomerScore() 
    {
        return customerScore;
    }

    @Override
    public String toString() {
        return "CustomerInfo{" +
                "customerId=" + customerId +
                ", openId='" + openId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerPasswd='" + customerPasswd + '\'' +
                ", customerPhone='" + customerPhone + '\'' +
                ", customerAddr='" + customerAddr + '\'' +
                ", nickname='" + nickname + '\'' +
                ", idNo='" + idNo + '\'' +
                ", customerType=" + customerType +
                ", delFlag='" + delFlag + '\'' +
                ", customerSex='" + customerSex + '\'' +
                ", customerScore=" + customerScore +
                '}';
    }
}
