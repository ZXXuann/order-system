package com.example.demo.handle;

import com.alibaba.fastjson.JSON;
import com.example.demo.utils.WebUtils;
import com.example.demo.domain.R;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@Component
public class AuthenticationEntryPointImpl implements AuthenticationEntryPoint {
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
        //给前端ResponseResult 的json
//           System.out.println(authException);
           R r = new R(HttpStatus.UNAUTHORIZED.value(), "登陆认证失败");
           String json = JSON.toJSONString(r);
           WebUtils.renderString(response, json);

    }
}
