package com.example.demo.service;

import com.example.demo.domain.Customer;
import com.example.demo.domain.CustomerInfo;
import com.example.demo.domain.R;

import java.util.List;

/**
 * customerService接口
 * 
 * @author zxx
 * @date 2023-01-16
 */
public interface ICustomerInfoService 
{
    /**
     * 查询customer
     * 
     * @param customerId customer主键
     * @return customer
     */
    public CustomerInfo selectCustomerInfoByCustomerId(Long customerId);

    /**
     * 查询customer列表
     * 
     * @param customerInfo customer
     * @return customer集合
     */
    public List<CustomerInfo> selectCustomerInfoList(CustomerInfo customerInfo);

    /**
     * 新增customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    public int insertCustomerInfo(CustomerInfo customerInfo);

    R registerCustomer(CustomerInfo customerInfo);

    /**
     * 修改customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    public int updateCustomerInfo(CustomerInfo customerInfo);

    R updateCustomerPwd(CustomerInfo customerInfo);

    /**
     * 批量删除customer
     * 
     * @param customerIds 需要删除的customer主键集合
     * @return 结果
     */
    public int deleteCustomerInfoByCustomerIds(Long[] customerIds);

    /**
     * 删除customer信息
     * 
     * @param customerId customer主键
     * @return 结果
     */
    public int deleteCustomerInfoByCustomerId(Long customerId);

    R getCustomer();
}
