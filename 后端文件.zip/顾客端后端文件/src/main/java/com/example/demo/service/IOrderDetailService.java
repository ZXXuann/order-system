package com.example.demo.service;

import com.example.demo.domain.OrderDetail;
import com.example.demo.domain.OrderInfo;
import com.example.demo.domain.R;

public interface IOrderDetailService {
    R getOrderDetail(OrderDetail orderDetail);
}
