package com.example.demo.service.impl;


import com.example.demo.dao.CustomerInfoMapper;
import com.example.demo.domain.CustomerInfo;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import com.example.demo.service.ICustomerInfoService;
import com.example.demo.utils.DateUtils;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.List;

/**
 * customerService业务层处理
 * 
 * @author zxx
 * @date 2023-01-16
 */
@Service
public class CustomerInfoServiceImpl implements ICustomerInfoService
{
    @Autowired
    private CustomerInfoMapper customerInfoMapper;

    /**
     * 查询customer
     * 
     * @param customerId customer主键
     * @return customer
     */
    @Override
    public CustomerInfo selectCustomerInfoByCustomerId(Long customerId)
    {
        return customerInfoMapper.selectCustomerInfoByCustomerId(customerId);
    }

    /**
     * 查询customer列表
     * 
     * @param customerInfo customer
     * @return customer
     */
    @Override
    public List<CustomerInfo> selectCustomerInfoList(CustomerInfo customerInfo)
    {
        return customerInfoMapper.selectCustomerInfoList(customerInfo);
    }

    /**
     * 新增customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    @Override
    public int insertCustomerInfo(CustomerInfo customerInfo)
    {
        customerInfo.setCreateTime(DateUtils.getNowDate());
        return customerInfoMapper.insertCustomerInfo(customerInfo);
    }
    @Autowired
    PasswordEncoder passwordEncoder;
    @Override
    public R registerCustomer(CustomerInfo customerInfo){
        //用户名校验：6-16位
        if(customerInfo.getCustomerName()==null||customerInfo.getCustomerName().trim().equals("")
        ||customerInfo.getCustomerName().length()<6||customerInfo.getCustomerName().length()>16){
            return RU.NO("用户名有误");
        }
        //姓名校验：1-4位
        if(customerInfo.getNickname()==null||customerInfo.getNickname().trim().equals("")
                ||customerInfo.getNickname().length()<=0||customerInfo.getNickname().length()>4){
            return RU.NO("姓名有误");
        }
        //密码校验：6-16位 不包括0
        if(customerInfo.getCustomerPasswd()==null||customerInfo.getCustomerPasswd().trim().equals("")
                ||customerInfo.getCustomerPasswd().length()<6||customerInfo.getCustomerPasswd().length()>16){
            return RU.NO("密码有误");
        }
        //性别校验
        if(customerInfo.getCustomerSex()==null){
            return RU.NO("性别有误");
        }
        customerInfo.setCustomerScore(0L);
        customerInfo.setCustomerType(1L);
        customerInfo.setDelFlag("0");
        //密码加密加盐
        customerInfo.setCustomerPasswd(passwordEncoder.encode(customerInfo.getCustomerPasswd()));
        if(customerInfoMapper.insertCustomerInfo(customerInfo)<=0){
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return RU.NO();
        };
        return RU.OK("操作成功");
    }
    /**
     * 修改customer
     * 
     * @param customerInfo customer
     * @return 结果
     */
    @Override
    public int updateCustomerInfo(CustomerInfo customerInfo)
    {
        customerInfo.setUpdateTime(DateUtils.getNowDate());
        return customerInfoMapper.updateCustomerInfo(customerInfo);
    }
    /**
     * 修改customer密码
     *
     * @param customerInfo customer
     * @return 结果
     */
    @Override
    public R updateCustomerPwd(CustomerInfo customerInfo) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerInfo tmp = new CustomerInfo();
        tmp.setCustomerId(Long.valueOf(id));
        tmp.setUpdateTime(DateUtils.getNowDate());
        tmp.setCustomerPasswd(passwordEncoder.encode(customerInfo.getCustomerPasswd()));
        int ret = customerInfoMapper.updateCustomerInfo(tmp);
        return RU.OK(ret);
    }

    /**
     * 批量删除customer
     * 
     * @param customerIds 需要删除的customer主键
     * @return 结果
     */
    @Override
    public int deleteCustomerInfoByCustomerIds(Long[] customerIds)
    {
        return customerInfoMapper.deleteCustomerInfoByCustomerIds(customerIds);
    }

    /**
     * 删除customer信息
     * 
     * @param customerId customer主键
     * @return 结果
     */
    @Override
    public int deleteCustomerInfoByCustomerId(Long customerId)
    {
        return customerInfoMapper.deleteCustomerInfoByCustomerId(customerId);
    }
    @Override
    public R getCustomer(){
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerInfo customerInfo=selectCustomerInfoByCustomerId((long) id);
        return RU.OK(customerInfo);
    }
}
