package com.example.demo.service;

import com.example.demo.domain.Customer;
import com.example.demo.domain.R;

public interface ILoginService {
    R login(Customer customer);
    R logout();
}
