package com.example.demo.service;

import java.util.List;
import com.example.demo.domain.FoodRecommendation;
import com.example.demo.domain.R;

/**
 * 推荐Service接口
 * 
 * @author zxx
 * @date 2023-03-01
 */
public interface IFoodRecommendationService 
{
    /**
     * 查询推荐
     * 
     * @param recId 推荐主键
     * @return 推荐
     */
    public FoodRecommendation selectFoodRecommendationByRecId(Long recId);

    /**
     * 查询推荐列表
     *
     * @return 推荐集合
     */
    public R selectFoodRecommendationList();


    /**
     * 新增推荐
     * 
     * @param foodRecommendation 推荐
     * @return 结果
     */
    public int insertFoodRecommendation(FoodRecommendation foodRecommendation);

    /**
     * 修改推荐
     * 
     * @param foodRecommendation 推荐
     * @return 结果
     */
    public int updateFoodRecommendation(FoodRecommendation foodRecommendation);

    /**
     * 批量删除推荐
     * 
     * @param recIds 需要删除的推荐主键集合
     * @return 结果
     */
    public int deleteFoodRecommendationByRecIds(Long[] recIds);

    /**
     * 删除推荐信息
     * 
     * @param recId 推荐主键
     * @return 结果
     */
    public int deleteFoodRecommendationByRecId(Long recId);
    /**
     * 删除全部推荐
     *
     * @return 结果
     */
    public int deleteFoodRecommendation();

    int createRecommendation();
}
