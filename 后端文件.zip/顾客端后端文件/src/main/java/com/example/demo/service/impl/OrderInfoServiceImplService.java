package com.example.demo.service.impl;

import com.example.demo.dao.OrderInfoMapper;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.service.IOrderInfoService;
import com.example.demo.utils.RU;
import com.example.demo.domain.OrderInfo;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class OrderInfoServiceImplService implements IOrderInfoService {
    @Autowired
    private OrderInfoMapper orderInfoMapper;
    @Override
    public R getOrderInfoList(OrderInfo orderInfo) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        orderInfo.setCustomerId((long) id);
        System.out.println("test:"+orderInfo.getOrderStatus());
        return RU.OK(orderInfoMapper.selectOrderInfoList(orderInfo));
    }
    @Override
    public R getListNotOrderStatus(OrderInfo orderInfo) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        orderInfo.setCustomerId((long) id);
        return RU.OK(orderInfoMapper.selectListNotOrderStatus(orderInfo));
    }

    @Override
    public R getOrderInfo(OrderInfo orderInfo) {
        return RU.OK(orderInfoMapper.insertOrderInfo(orderInfo));
    }
}
