package com.example.demo.controller;

import com.example.demo.domain.Cart;
import com.example.demo.domain.R;
import com.example.demo.service.ICartService;
import com.example.demo.service.impl.CartService;
import com.example.demo.utils.RU;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping({"cart"})
public class CartController {
    @Autowired
    private ICartService cartService;
    @PostMapping("postcart")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R postCart(@RequestBody Cart cart){
        return cartService.postOrder(cart);
    }
}
