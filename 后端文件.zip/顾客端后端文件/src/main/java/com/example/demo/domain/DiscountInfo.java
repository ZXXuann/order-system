package com.example.demo.domain;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 红包卡券对象 discount_info
 * 
 * @author zxx
 * @date 2023-01-20
 */
public class DiscountInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 红包卡券id */
    private Long discountId;

    /** 红包卡券数额 */

    private BigDecimal discountAccount;

    /** 红包卡券详细 */

    private String discountDetail;

    /** 红包卡券是否生效 */

    private String isvalidate;

    /** 红包卡券满减条件 */

    private BigDecimal discountCondition;


    /** 0为红包 1为卡券 */

    private String discountType;

    /** 红包卡券标题 */

    private String discountTitle;

    public void setDiscountId(Long discountId) 
    {
        this.discountId = discountId;
    }

    public Long getDiscountId() 
    {
        return discountId;
    }
    public void setDiscountAccount(BigDecimal discountAccount) 
    {
        this.discountAccount = discountAccount;
    }

    public BigDecimal getDiscountAccount() 
    {
        return discountAccount;
    }
    public void setDiscountDetail(String discountDetail) 
    {
        this.discountDetail = discountDetail;
    }

    public String getDiscountDetail() 
    {
        return discountDetail;
    }
    public void setIsvalidate(String isvalidate) 
    {
        this.isvalidate = isvalidate;
    }

    public String getIsvalidate() 
    {
        return isvalidate;
    }
    public void setDiscountCondition(BigDecimal discountCondition) 
    {
        this.discountCondition = discountCondition;
    }

    public BigDecimal getDiscountCondition() 
    {
        return discountCondition;
    }

    public void setDiscountType(String discountType) 
    {
        this.discountType = discountType;
    }

    public String getDiscountType() 
    {
        return discountType;
    }
    public void setDiscountTitle(String discountTitle) 
    {
        this.discountTitle = discountTitle;
    }

    public String getDiscountTitle() 
    {
        return discountTitle;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("discountId", getDiscountId())
            .append("discountAccount", getDiscountAccount())
            .append("discountDetail", getDiscountDetail())
            .append("isvalidate", getIsvalidate())
            .append("discountCondition", getDiscountCondition())
            .append("updateTime", getUpdateTime())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("discountType", getDiscountType())
            .append("updateBy", getUpdateBy())
            .append("discountTitle", getDiscountTitle())
            .toString();
    }
}
