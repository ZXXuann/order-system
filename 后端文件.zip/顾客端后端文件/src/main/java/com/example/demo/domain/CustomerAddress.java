package com.example.demo.domain;

import java.io.Serializable;
/**
 *
 * @author zxx
 * @date 2023-01-09
 */
public class CustomerAddress implements Serializable {
    private Integer id;
    private String name;
    private Integer gender;
    private String description;
    private String address;
    private String phone;
    private String isDefault;
    private Long customerId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public CustomerAddress() {
    }

    public CustomerAddress(Integer id, String name, Integer gender, String description, String address, String phone, String isDefault, Long customerId) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.description = description;
        this.address = address;
        this.phone = phone;
        this.isDefault = isDefault;
        this.customerId = customerId;
    }
}
