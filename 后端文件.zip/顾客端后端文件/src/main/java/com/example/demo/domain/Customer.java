package com.example.demo.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
/**
 *
 * @author zxx
 * @date 2023-01-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("customer_info")
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    @TableId
    private int customerId;
    private int openId;
    private String customerName;
    private String customerPhone;
    private String customerAddr;
    private String nickname;

    private String customerPasswd;
    private String customerSex;
    private int idNo;
    private String customerType;
    private String createTime;
    private String createBy;
    private String updateBy;
    private Date updateTime;
    private Integer delFlag;
    private Integer customerScore;
    private String customerImg;
}
