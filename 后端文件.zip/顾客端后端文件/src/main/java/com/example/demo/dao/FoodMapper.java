package com.example.demo.dao;

import com.example.demo.domain.Food;

import java.util.List;

/**
 * 菜品管理Mapper接口
 * 
 * @author ruoyi
 * @date 2023-01-09
 */
public interface FoodMapper 
{
    /**
     * 查询菜品管理
     * 
     * @param foodId 菜品管理主键
     * @return 菜品管理
     */
    public Food selectFoodByFoodId(Long foodId);

    /**
     * 查询菜品管理列表
     * 
     * @param food 菜品管理
     * @return 菜品管理集合
     */
    public List<Food> selectFoodList(Food food);

    /**
     * 新增菜品管理
     * 
     * @param food 菜品管理
     * @return 结果
     */
    public int insertFood(Food food);

    /**
     * 修改菜品管理
     * 
     * @param food 菜品管理
     * @return 结果
     */
    public int updateFood(Food food);

    /**
     * 删除菜品管理
     * 
     * @param foodId 菜品管理主键
     * @return 结果
     */
    public int deleteFoodByFoodId(Long foodId);

    /**
     * 批量删除菜品管理
     * 
     * @param foodIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFoodByFoodIds(Long[] foodIds);
}
