package com.example.demo.service;


import com.example.demo.domain.DiscountInfo;

import java.util.List;

/**
 * 红包卡券Service接口
 * 
 * @author zxx
 * @date 2023-01-20
 */
public interface IDiscountInfoService 
{
    /**
     * 查询红包卡券
     * 
     * @param discountId 红包卡券主键
     * @return 红包卡券
     */
    public DiscountInfo selectDiscountInfoByDiscountId(Long discountId);

    /**
     * 查询红包卡券列表
     * 
     * @param discountInfo 红包卡券
     * @return 红包卡券集合
     */
    public List<DiscountInfo> selectDiscountInfoList(DiscountInfo discountInfo);

    /**
     * 新增红包卡券
     * 
     * @param discountInfo 红包卡券
     * @return 结果
     */
    public int insertDiscountInfo(DiscountInfo discountInfo);

    /**
     * 修改红包卡券
     * 
     * @param discountInfo 红包卡券
     * @return 结果
     */
    public int updateDiscountInfo(DiscountInfo discountInfo);

    /**
     * 批量删除红包卡券
     * 
     * @param discountIds 需要删除的红包卡券主键集合
     * @return 结果
     */
    public int deleteDiscountInfoByDiscountIds(Long[] discountIds);

    /**
     * 删除红包卡券信息
     * 
     * @param discountId 红包卡券主键
     * @return 结果
     */
    public int deleteDiscountInfoByDiscountId(Long discountId);
}
