package com.example.demo.dao;


import com.example.demo.domain.OrderDetail;

import java.util.List;

/**
 * detailMapper接口
 * 
 * @author zxx
 * @date 2023-01-09
 */
public interface OrderDetailMapper 
{
    /**
     * 查询detail
     * 
     * @param detailId detail主键
     * @return detail
     */
    public OrderDetail selectOrderDetailByDetailId(Long detailId);

    /**
     * 查询detail列表
     * 
     * @param orderDetail detail
     * @return detail集合
     */
    public List<OrderDetail> selectOrderDetailList(OrderDetail orderDetail);

    /**
     * 新增detail
     * 
     * @param orderDetail detail
     * @return 结果
     */
    public int insertOrderDetail(OrderDetail orderDetail);

    /**
     * 修改detail
     * 
     * @param orderDetail detail
     * @return 结果
     */
    public int updateOrderDetail(OrderDetail orderDetail);

    /**
     * 删除detail
     * 
     * @param detailId detail主键
     * @return 结果
     */
    public int deleteOrderDetailByDetailId(Long detailId);

    /**
     * 批量删除detail
     * 
     * @param detailIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteOrderDetailByDetailIds(Long[] detailIds);
}
