package com.example.demo.service;

import com.example.demo.domain.OrderInfo;
import com.example.demo.domain.R;

public interface IOrderInfoService {
    R getOrderInfoList(OrderInfo orderInfo);

    R getListNotOrderStatus(OrderInfo orderInfo);

    R getOrderInfo(OrderInfo orderInfo);
}
