package com.example.demo.service;


import com.example.demo.domain.FoodScore;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * scoreService接口
 * 
 * @author zxx
 * @date 2023-01-09
 */
public interface IFoodScoreService 
{
    /**
     * 查询score
     * 
     * @param scoreId score主键
     * @return score
     */
    public FoodScore selectFoodScoreByScoreId(Long scoreId);

    /**
     * 查询score列表
     * 
     * @param foodScore score
     * @return score集合
     */
    public List<FoodScore> selectFoodScoreList(FoodScore foodScore);

    @Transactional
    List selectAutoCustomerId(FoodScore foodScore);

    /**
     * 新增score
     * 
     * @param foodScore score
     * @return 结果
     */
    public int insertFoodScore(FoodScore foodScore);

    /**
     * 修改score
     * 
     * @param foodScore score
     * @return 结果
     */
    public int updateFoodScore(FoodScore foodScore);

    /**
     * 批量删除score
     * 
     * @param scoreIds 需要删除的score主键集合
     * @return 结果
     */
    public int deleteFoodScoreByScoreIds(Long[] scoreIds);

    /**
     * 删除score信息
     * 
     * @param scoreId score主键
     * @return 结果
     */
    public int deleteFoodScoreByScoreId(Long scoreId);
}
