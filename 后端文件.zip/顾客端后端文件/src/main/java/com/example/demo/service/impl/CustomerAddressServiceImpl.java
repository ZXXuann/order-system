package com.example.demo.service.impl;

import com.example.demo.dao.CustomerAddressMapper;
import com.example.demo.domain.CustomerAddress;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import com.example.demo.service.ICustomerAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class CustomerAddressServiceImpl implements ICustomerAddressService {
    @Autowired
    private CustomerAddressMapper customerAddressMapper;
    @Override
    public List selectCustomerAddressList(CustomerAddress customerAddress) {
        return customerAddressMapper.selectCustomerAddressList(customerAddress);
    }
    public R selectCustomerAddressList() {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerAddress customerAddress = new CustomerAddress();
        customerAddress.setCustomerId((long) id);
        List list=customerAddressMapper.selectCustomerAddressList(customerAddress);
        return new R(200,list);
    }
    @Override
    public CustomerAddress selectCustomerAddressById(Long id) {
        return customerAddressMapper.selectCustomerAddressById(id);
    }
    @Transactional
    @Override
    public int insertCustomerAddress(CustomerAddress customerAddress) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        customerAddress.setCustomerId((long) id);
        if("1".equals(customerAddress.getIsDefault())){
            CustomerAddress tmp = new CustomerAddress();
            tmp.setIsDefault("0");
            customerAddressMapper.updateCustomerAddressAll(tmp);
        }
        //取消其他默认地址
        return customerAddressMapper.insertCustomerAddress(customerAddress);
    }
    @Transactional
    @Override
    public int updateCustomerAddress(CustomerAddress customerAddress) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        customerAddress.setCustomerId((long) id);
        if("1".equals(customerAddress.getIsDefault())){
            CustomerAddress tmp = new CustomerAddress();
            tmp.setIsDefault("0");
            customerAddressMapper.updateCustomerAddressAll(tmp);
        }
        return customerAddressMapper.updateCustomerAddress(customerAddress);
    }

    @Override
    public int deleteCustomerAddressByIds(Long[] ids) {
        return customerAddressMapper.deleteCustomerAddressByIds(ids);
    }

    @Override
    public int deleteCustomerAddressById(Long id) {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int cusId=loginCustomer.getCustomer().getCustomerId();
        CustomerAddress customerAddress=new CustomerAddress();
        customerAddress.setCustomerId((long) cusId);
        return customerAddressMapper.deleteCustomerAddressById(id);
    }
}
