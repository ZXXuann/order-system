package com.example.demo.service.impl;

import com.example.demo.config.SettingConfig;
import com.example.demo.service.ILoginService;
import com.example.demo.utils.JwtUtil;
import com.example.demo.utils.RedisCache;
import com.example.demo.domain.Customer;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Service
public class LoginServiceImpl implements ILoginService {
    @Autowired
    private SettingConfig settingConfig;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    RedisCache redisCache;
    public R login(Customer customer) {
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
                new UsernamePasswordAuthenticationToken(customer.getCustomerName(), customer.getCustomerPasswd());
        Authentication authentication = authenticationManager.authenticate(usernamePasswordAuthenticationToken);
        LoginCustomer loginCustomer = (LoginCustomer) (authentication.getPrincipal());
        String id = String.valueOf(loginCustomer.getCustomer().getCustomerId());
        String jwt = JwtUtil.createJWT(id, (long) (settingConfig.getTokenValidTime()*60 * 60 *1000));
        Map<String, String> map = new HashMap<>();
        map.put("token", jwt);
        redisCache.setCacheObject("CustomerLogin:" + id, loginCustomer, 24, TimeUnit.HOURS);
        return new R(200, "登录成功", map);
    }

    @Override
    public R logout() {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        redisCache.deleteObject("CustomerLogin:"+id);
        return new R(200,"退出成功!");
    }
}
