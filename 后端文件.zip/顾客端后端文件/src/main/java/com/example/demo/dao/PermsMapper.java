package com.example.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.domain.Perms;

import java.util.List;

public interface PermsMapper extends BaseMapper<Perms> {
    List<String> selectPermsByCustomerId(Integer customerId);
}
