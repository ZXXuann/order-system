package com.example.demo.service;

import com.example.demo.domain.FoodType;
import com.example.demo.domain.R;

import java.util.List;

/**
 * 菜品类型Service接口
 * 
 * @author zxx
 * @date 2023-01-09
 */
public interface IFoodTypeService 
{
    /**
     * 查询菜品类型
     * 
     * @param foodtypeId 菜品类型主键
     * @return 菜品类型
     */
    public FoodType selectFoodTypeByFoodtypeId(Long foodtypeId);

    /**
     * 查询菜品类型列表
     * 
     * @param foodType 菜品类型
     * @return 菜品类型集合
     */
    public List<FoodType> selectFoodTypeList(FoodType foodType);

    /**
     * 新增菜品类型
     * 
     * @param foodType 菜品类型
     * @return 结果
     */
    public int insertFoodType(FoodType foodType);

    /**
     * 修改菜品类型
     * 
     * @param foodType 菜品类型
     * @return 结果
     */
    public int updateFoodType(FoodType foodType);

    /**
     * 批量删除菜品类型
     * 
     * @param foodtypeIds 需要删除的菜品类型主键集合
     * @return 结果
     */
    public int deleteFoodTypeByFoodtypeIds(Long[] foodtypeIds);

    /**
     * 删除菜品类型信息
     * 
     * @param foodtypeId 菜品类型主键
     * @return 结果
     */
    public int deleteFoodTypeByFoodtypeId(Long foodtypeId);

    R getFoodTypeAndFood();
}
