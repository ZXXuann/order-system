package com.example.demo.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.CustomerDiscountMapper;
import com.example.demo.dao.DiscountInfoMapper;
import com.example.demo.domain.CustomerDiscount;
import com.example.demo.domain.DiscountInfo;
import com.example.demo.domain.LoginCustomer;
import com.example.demo.service.ICustomerDiscountService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;


/**
 * 用户卡券Service业务层处理
 * 
 * @author zxx
 * @date 2023-01-20
 */
@Service
public class CustomerDiscountServiceImpl implements ICustomerDiscountService
{
    @Autowired
    private CustomerDiscountMapper customerDiscountMapper;
    @Autowired
    private DiscountInfoMapper discountInfoMapper;
    /**
     * 查询用户卡券
     * 
     * @param cdId 用户卡券主键
     * @return 用户卡券
     */
    @Override
    public CustomerDiscount selectCustomerDiscountByCdId(Long cdId)
    {
        return customerDiscountMapper.selectCustomerDiscountByCdId(cdId);
    }
    /**
     * 查询用户卡券列表
     *
     * @return 未过期用户卡券
     */
    @Override
    public List selectNoValidateDiscountList()
    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerDiscount customerDiscount = new CustomerDiscount();
        customerDiscount.setCustomerId((long) id);
        List<CustomerDiscount> customerDiscounts = customerDiscountMapper.selectCustomerDiscountList(customerDiscount);
        List temp=new ArrayList();
        for(CustomerDiscount cd:customerDiscounts){
            DiscountInfo discountInfo = discountInfoMapper.selectDiscountInfoByDiscountId(cd.getDiscountId());
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(discountInfo,"yyyy-MM-dd HH:mm:ss"), Map.class);
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = sdf.format(cd.getValidate());
            boolean validate = DateUtils.getNowDate().after(cd.getValidate());
            if(validate){
                map.put("validate",format);
                map.put("cdId",cd.getCdId());
                temp.add(map);
            }
        }
        return temp;
    }

    @Override
    public List selectCustomerDiscountList() {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerDiscount customerDiscount = new CustomerDiscount();
        customerDiscount.setCustomerId((long) id);
        List<CustomerDiscount> customerDiscounts = customerDiscountMapper.selectCustomerDiscountList(customerDiscount);
        List temp=new ArrayList();
        for(CustomerDiscount cd:customerDiscounts){
            DiscountInfo discountInfo = discountInfoMapper.selectDiscountInfoByDiscountId(cd.getDiscountId());
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(discountInfo,"yyyy-MM-dd HH:mm:ss"), Map.class);
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = sdf.format(cd.getValidate());
            boolean validate = DateUtils.getNowDate().after(cd.getValidate());
            if(!validate){
                map.put("validate",format);
                map.put("cdId",cd.getCdId());
                temp.add(map);
            }
        }
        return temp;
    }

    @Override
    public List selectDiscountByCondition(DiscountInfo tmp) {
        return null;
    }

    /**
     * 查询用户卡券列表
     *
     * @param  tmp 用户卡券
     * @return 未过期用户卡券
     */
    @Override
    public List selectCustomerDiscountList(DiscountInfo tmp)
    {
        //获取顾客id
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        CustomerDiscount customerDiscount = new CustomerDiscount();
        customerDiscount.setCustomerId((long) id);
        //查找顾客红包卡券
        List<CustomerDiscount> customerDiscounts = customerDiscountMapper.selectCustomerDiscountList(customerDiscount);
        List temp=new ArrayList();
        //对红包卡券逐一遍历
        for(CustomerDiscount cd:customerDiscounts){
            //设置优惠券的id
            tmp.setDiscountId(cd.getDiscountId());
            //查找与之的券的信息（id和condition）
            DiscountInfo discountInfo = discountInfoMapper.selectDiscountInfoByCondition(tmp);
            if(discountInfo==null||discountInfo.getDiscountId()==null){
                continue;
            }
            //过期时间
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(discountInfo,"yyyy-MM-dd HH:mm:ss"), Map.class);
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = sdf.format(cd.getValidate());
            boolean validate = DateUtils.getNowDate().after(cd.getValidate());
            //是否过期？ 过期抛弃
            if(!validate){
                map.put("validate",format);
                map.put("cdId",cd.getCdId());
                temp.add(map);
            }
        }
        return temp;
    }

    /**
     * 新增用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    @Override
    public int insertCustomerDiscount(CustomerDiscount customerDiscount)
    {
        return customerDiscountMapper.insertCustomerDiscount(customerDiscount);
    }

    /**
     * 修改用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    @Override
    public int updateCustomerDiscount(CustomerDiscount customerDiscount)
    {
        return customerDiscountMapper.updateCustomerDiscount(customerDiscount);
    }

    /**
     * 批量删除用户卡券
     * 
     * @param cdIds 需要删除的用户卡券主键
     * @return 结果
     */
    @Override
    public int deleteCustomerDiscountByCdIds(Long[] cdIds)
    {
        return customerDiscountMapper.deleteCustomerDiscountByCdIds(cdIds);
    }

    /**
     * 删除用户卡券信息
     * 
     * @param cdId 用户卡券主键
     * @return 结果
     */
    @Override
    public int deleteCustomerDiscountByCdId(Long cdId)
    {
        return customerDiscountMapper.deleteCustomerDiscountByCdId(cdId);
    }
}
