package com.example.demo.controller;

import com.example.demo.domain.OrderDetail;
import com.example.demo.service.IOrderDetailService;
import com.example.demo.service.IOrderInfoService;
import com.example.demo.utils.PageUtil;
import com.github.pagehelper.PageHelper;
import com.example.demo.domain.OrderInfo;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping({"anms","order"})
@RestController
public class OrderController {
    @Autowired
    private IOrderDetailService orderDetailService;
    @Autowired
    private IOrderInfoService orderInfoService;
    @GetMapping("info/list")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getOrderInfo(OrderInfo orderInfo){
        PageHelper.startPage(PageUtil.getPageDomain());
        return orderInfoService.getOrderInfoList(orderInfo);
    }
    @GetMapping("info/list/status")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getOrderInfoStatus(OrderInfo orderInfo){
        PageHelper.startPage(PageUtil.getPageDomain());
        return orderInfoService.getListNotOrderStatus(orderInfo);
    }
    @GetMapping("detail/list")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getOrderDetail(OrderDetail orderDetail){
        PageHelper.startPage(PageUtil.getPageDomain());
        return  orderDetailService.getOrderDetail(orderDetail);
    }
}
