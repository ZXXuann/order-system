package com.example.demo.service.impl;

import java.util.List;

import com.example.demo.dao.CustomerDiscountMapper;
import com.example.demo.dao.DiscountInfoMapper;
import com.example.demo.dao.DiscountKeyMapper;
import com.example.demo.domain.*;
import com.example.demo.service.IDiscountKeyService;
import com.example.demo.utils.DateUtils;
import com.example.demo.utils.JwtUtil;
import com.example.demo.utils.RU;
import io.jsonwebtoken.ExpiredJwtException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 红包卡券兑换码Service业务层处理
 * 
 * @author zxx
 * @date 2023-02-05
 */
@Service
public class DiscountKeyServiceImpl implements IDiscountKeyService
{
    @Autowired
    private DiscountKeyMapper discountKeyMapper;
    @Autowired
    private DiscountInfoMapper discountInfoMapper;
    @Autowired
    private CustomerDiscountMapper customerDiscountMapper;
    /**
     * 兑换码兑换
     *
     * @param discountKey 红包卡券兑换码主键
     * @return 红包卡券兑换码
     */
    @Transactional
    @Override
    public R exchangeKey(DiscountKey discountKey) throws Exception {
        discountKey.setDiscountId(null);
        //查找存在 生效？
        discountKey=discountKeyMapper.selectDiscountKeyByCondition(discountKey);
        if(discountKey!=null&&discountKey.getDiscountId()!=null){
            //兑换时令其失效
            discountKey.setIsvalidate("1");
            if(discountKeyMapper.updateDiscountKey(discountKey)>=1){
                //获取优惠券Id
                String subject = JwtUtil.parseJWT(discountKey.getDiscountKey()).getSubject();
                //优惠券存在？
                DiscountInfo discountInfo = discountInfoMapper.selectDiscountInfoByDiscountId(Long.valueOf(subject));
                //存在后继续
                if(discountInfo!=null&&discountInfo.getDiscountId()!=null){
                    //获取customer的id
                    Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
                    LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
                    int id=loginCustomer.getCustomer().getCustomerId();
                    //塞进去
                    CustomerDiscount customerDiscount = new CustomerDiscount();
                    customerDiscount.setCustomerId((long) id);
                    customerDiscount.setDiscountId(discountInfo.getDiscountId());
                    System.out.println(JwtUtil.parseJWT(discountKey.getDiscountKey()));
                    try {
                        customerDiscount.setValidate(JwtUtil.parseJWT(discountKey.getDiscountKey()).getExpiration());
                    }catch (ExpiredJwtException e){
                        return RU.NO("卡券已过期");
                    }
                    //给用户塞进优惠券
                    if(customerDiscountMapper.insertCustomerDiscount(customerDiscount)>=1){
                        return RU.OK("卡券兑换成功");
                    }
                }

            }
        }
        return RU.NO("卡券不存在！");
    }
    /**
     * 查询红包卡券兑换码
     * 
     * @param keyId 红包卡券兑换码主键
     * @return 红包卡券兑换码
     */
    @Override
    public DiscountKey selectDiscountKeyByKeyId(Long keyId)
    {
        return discountKeyMapper.selectDiscountKeyByKeyId(keyId);
    }

    /**
     * 查询红包卡券兑换码列表
     * 
     * @param discountKey 红包卡券兑换码
     * @return 红包卡券兑换码
     */
    @Override
    public List<DiscountKey> selectDiscountKeyList(DiscountKey discountKey)
    {
        return discountKeyMapper.selectDiscountKeyList(discountKey);
    }

    /**
     * 新增红包卡券兑换码
     * 
     * @param discountKey 红包卡券兑换码
     * @return 结果
     */
    @Override
    public int insertDiscountKey(DiscountKey discountKey)
    {
        discountKey.setCreateTime(DateUtils.getNowDate());
        return discountKeyMapper.insertDiscountKey(discountKey);
    }

    /**
     * 修改红包卡券兑换码
     * 
     * @param discountKey 红包卡券兑换码
     * @return 结果
     */
    @Override
    public int updateDiscountKey(DiscountKey discountKey)
    {
        discountKey.setUpdateTime(DateUtils.getNowDate());
        return discountKeyMapper.updateDiscountKey(discountKey);
    }

    /**
     * 批量删除红包卡券兑换码
     * 
     * @param keyIds 需要删除的红包卡券兑换码主键
     * @return 结果
     */
    @Override
    public int deleteDiscountKeyByKeyIds(Long[] keyIds)
    {
        return discountKeyMapper.deleteDiscountKeyByKeyIds(keyIds);
    }

    /**
     * 删除红包卡券兑换码信息
     * 
     * @param keyId 红包卡券兑换码主键
     * @return 结果
     */
    @Override
    public int deleteDiscountKeyByKeyId(Long keyId)
    {
        return discountKeyMapper.deleteDiscountKeyByKeyId(keyId);
    }
}
