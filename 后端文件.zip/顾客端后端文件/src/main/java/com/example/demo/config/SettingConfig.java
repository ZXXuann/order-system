package com.example.demo.config;

import com.example.demo.utils.YamlPropertySourceFactory;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "relate")
@PropertySource(value="classpath:config.yml",factory = YamlPropertySourceFactory.class,encoding = "UTF-8")
public class SettingConfig {
    private String uploadPath;
    private String serverPath;
    private int tokenValidTime;
}