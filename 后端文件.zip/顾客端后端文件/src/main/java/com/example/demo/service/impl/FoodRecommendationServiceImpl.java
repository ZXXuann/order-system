package com.example.demo.service.impl;

import java.util.List;

import com.example.demo.domain.LoginCustomer;
import com.example.demo.domain.R;
import com.example.demo.utils.DateUtils;
import com.example.demo.utils.RU;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.jdbc.MySQLJDBCDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.JDBCDataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.example.demo.dao.FoodRecommendationMapper;
import com.example.demo.domain.FoodRecommendation;
import com.example.demo.service.IFoodRecommendationService;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

/**
 * 推荐Service业务层处理
 * 
 * @author zxx
 * @date 2023-03-01
 */
@Service
public class FoodRecommendationServiceImpl implements IFoodRecommendationService 
{
    @Autowired
    private FoodRecommendationMapper foodRecommendationMapper;
    @Autowired
    private DataSource dataSource;
    /**
     * 查询推荐
     * 
     * @param recId 推荐主键
     * @return 推荐
     */
    @Override
    public FoodRecommendation selectFoodRecommendationByRecId(Long recId)
    {
        return foodRecommendationMapper.selectFoodRecommendationByRecId(recId);
    }

    /**
     * 查询推荐列表
     *
     * @return 推荐
     */
    @Override
    public R selectFoodRecommendationList()
    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        FoodRecommendation recommendation = new FoodRecommendation();
        recommendation.setCustomerId((long) id);
        List<FoodRecommendation> foodRecommendations
                = foodRecommendationMapper.selectFoodRecommendationList(recommendation);
        return RU.OK(foodRecommendations);
    }

    /**
     * 新增推荐
     * 
     * @param foodRecommendation 推荐
     * @return 结果
     */
    @Override
    @Transactional
    public int insertFoodRecommendation(FoodRecommendation foodRecommendation)
    {
//        List<FoodRecommendation> old
//                = foodRecommendationMapper.selectFoodRecommendationList(foodRecommendation);
//        //判断是否有老值，有老值则先删除
//        if(old.size()>0){
//            Long ids[]=new Long[old.size()];
//            int i=0;
//            for(FoodRecommendation tmp:old){
//                ids[i]=tmp.getCustomerId();
//                i++;
//            }
//            foodRecommendationMapper.deleteFoodRecommendationByRecIds(ids);
//        }
        foodRecommendation.setCreateTime(DateUtils.getNowDate());
        return foodRecommendationMapper.insertFoodRecommendation(foodRecommendation);
    }

    /**
     * 修改推荐
     * 
     * @param foodRecommendation 推荐
     * @return 结果
     */
    @Override
    public int updateFoodRecommendation(FoodRecommendation foodRecommendation)
    {
        foodRecommendation.setUpdateTime(DateUtils.getNowDate());
        return foodRecommendationMapper.updateFoodRecommendation(foodRecommendation);
    }

    /**
     * 批量删除推荐
     * 
     * @param recIds 需要删除的推荐主键
     * @return 结果
     */
    @Override
    public int deleteFoodRecommendationByRecIds(Long[] recIds)
    {
        return foodRecommendationMapper.deleteFoodRecommendationByRecIds(recIds);
    }

    /**
     * 删除推荐信息
     * 
     * @param recId 推荐主键
     * @return 结果
     */
    @Override
    public int deleteFoodRecommendationByRecId(Long recId)
    {
        return foodRecommendationMapper.deleteFoodRecommendationByRecId(recId);
    }
    /**
     * 删除推荐信息
     *
     * @return 结果
     */
    @Override
    public int deleteFoodRecommendation()
    {
        return foodRecommendationMapper.deleteFoodRecommendation();
    }

    @Override
    @Transactional
    public int createRecommendation(){
        //获取数据模型
        JDBCDataModel dataModel = new MySQLJDBCDataModel(dataSource, "food_single_score", "customer_id", "food_id", "score", null);
        DataModel model = dataModel;
        try {
            //计算相似度
            UserSimilarity similarity = new PearsonCorrelationSimilarity(model);
            //计算阈值 k近邻
            UserNeighborhood neighborhood = new NearestNUserNeighborhood(3, similarity, model);
            Recommender recommender = new GenericUserBasedRecommender(model, neighborhood, similarity);
            //获取每个用户的推荐数据
            LongPrimitiveIterator userIDs = dataModel.getUserIDs();
            while(userIDs.hasNext()){
                Long id = userIDs.next();
                //获取推荐
                List<RecommendedItem> recommendations = recommender.recommend(id, 3);
                for(RecommendedItem tmp:recommendations) {
                    //获取推荐具体值并删除原先数据后插入数据
                    long itemID = tmp.getItemID();
                    float value = tmp.getValue();
                    deleteFoodRecommendation();
                    FoodRecommendation foodRecommendation = new FoodRecommendation();
                    foodRecommendation.setFoodId(itemID);
                    foodRecommendation.setScore(String.valueOf(value));
                    foodRecommendation.setCustomerId(id);
                    insertFoodRecommendation(foodRecommendation);
                }
            }
            return 1;
        } catch (TasteException e) {
            return 0;
        }
    }
}
