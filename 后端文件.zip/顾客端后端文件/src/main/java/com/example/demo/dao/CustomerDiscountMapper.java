package com.example.demo.dao;

import java.util.List;
import com.example.demo.domain.CustomerDiscount;

/**
 * 用户卡券Mapper接口
 * 
 * @author ruoyi
 * @date 2023-01-20
 */
public interface CustomerDiscountMapper 
{
    /**
     * 查询用户卡券
     * 
     * @param cdId 用户卡券主键
     * @return 用户卡券
     */
    public CustomerDiscount selectCustomerDiscountByCdId(Long cdId);

    /**
     * 查询用户卡券列表
     *
     * @param customerDiscount 用户卡券
     * @return 用户卡券集合
     */
    public List<CustomerDiscount> selectCustomerDiscountList(CustomerDiscount customerDiscount);

    /**
     * 新增用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    public int insertCustomerDiscount(CustomerDiscount customerDiscount);

    /**
     * 修改用户卡券
     * 
     * @param customerDiscount 用户卡券
     * @return 结果
     */
    public int updateCustomerDiscount(CustomerDiscount customerDiscount);

    /**
     * 删除用户卡券
     * 
     * @param cdId 用户卡券主键
     * @return 结果
     */
    public int deleteCustomerDiscountByCdId(Long cdId);

    /**
     * 批量删除用户卡券
     * 
     * @param cdIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteCustomerDiscountByCdIds(Long[] cdIds);
}
