package com.example.demo.controller;

import com.example.demo.domain.FoodScore;
import com.example.demo.domain.R;
import com.example.demo.service.IFoodScoreService;
import com.example.demo.utils.PageUtil;
import com.example.demo.utils.RU;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"anms","rate"})
public class RateController {
    @Autowired
    private IFoodScoreService foodScoreService;
    @PostMapping("updateRate")
//    @PreAuthorize("hasAuthority('customer:info:all')")
    public R updateRate(@RequestBody FoodScore foodScore){
        System.out.println(foodScore.getSingleScore());
        if(foodScoreService.insertFoodScore(foodScore)>0){
            return RU.OK("");
        }else{
            return RU.NO();
        }
    }
    @GetMapping("rateinfo")
    public R getInfo(){
        PageHelper.startPage(PageUtil.getPageDomain());
        List<FoodScore> foodScores = foodScoreService.selectFoodScoreList(null);
        return RU.OK(foodScores);
    }
    @GetMapping("cusrate")
    @PreAuthorize("hasAuthority('customer:info:all')")
    public R getCusRate(FoodScore foodScore){
//        PageHelper.startPage(PageUtil.getPageDomain());
        List<FoodScore> foodScores = foodScoreService.selectAutoCustomerId(foodScore);
        return RU.OK(foodScores);
    }
}
