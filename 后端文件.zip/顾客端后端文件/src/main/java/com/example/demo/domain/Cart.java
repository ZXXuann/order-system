package com.example.demo.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
/**
 *
 * @author zxx
 * @date 2023-01-09
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cart {
    private Integer cdId;
    private List<CartFood> foods;
    private String customerName;
    private String customerAddr;
    private Integer customerId;
    private Integer chairNo;
    private Integer orderType;
    private Integer payStatus;
    private String customerPhone;
}
