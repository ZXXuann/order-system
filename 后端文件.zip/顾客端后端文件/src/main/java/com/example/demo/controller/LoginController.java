package com.example.demo.controller;

import com.example.demo.domain.CustomerInfo;
import com.example.demo.service.ICustomerInfoService;
import com.example.demo.service.ICustomerService;
import com.example.demo.service.ILoginService;
import com.example.demo.domain.Customer;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"user","anms"})
public class LoginController {
    @Autowired
    ILoginService ILoginService;
    @Autowired
    private ICustomerInfoService customerService;
    @PostMapping("login")
    public R login( Customer customer){
        return ILoginService.login(customer);
    }
    @PostMapping("reg")
    public R regCustomer(CustomerInfo customerInfo){
        return customerService.registerCustomer(customerInfo);
    }
}
