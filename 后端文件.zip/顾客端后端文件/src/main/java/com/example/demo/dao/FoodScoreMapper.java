package com.example.demo.dao;


import com.example.demo.domain.FoodScore;

import java.util.List;

/**
 * scoreMapper接口
 * 
 * @author zxx
 * @date 2023-01-09
 */
public interface FoodScoreMapper 
{
    /**
     * 查询score
     * 
     * @param scoreId score主键
     * @return score
     */
    public FoodScore selectFoodScoreByScoreId(Long scoreId);

    /**
     * 查询score列表
     * 
     * @param foodScore score
     * @return score集合
     */
    public List<FoodScore> selectFoodScoreList(FoodScore foodScore);

    /**
     * 新增score
     * 
     * @param foodScore score
     * @return 结果
     */
    public int insertFoodScore(FoodScore foodScore);

    /**
     * 修改score
     * 
     * @param foodScore score
     * @return 结果
     */
    public int updateFoodScore(FoodScore foodScore);

    /**
     * 删除score
     * 
     * @param scoreId score主键
     * @return 结果
     */
    public int deleteFoodScoreByScoreId(Long scoreId);

    /**
     * 批量删除score
     * 
     * @param scoreIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFoodScoreByScoreIds(Long[] scoreIds);

    public List<FoodScore> selectRate();
}
