package com.example.demo.service.impl;

import com.example.demo.dao.IndexMapper;
import com.example.demo.service.IIndexService;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class IndexServiceImpl implements IIndexService {
    @Autowired
    private IndexMapper indexMapper;
    @Override
    public R getPic() {
       return new R<>(HttpStatus.OK.value(), indexMapper.selectList(null));
    }
}
