package com.example.demo.service.impl;


import com.example.demo.dao.DiscountInfoMapper;
import com.example.demo.domain.DiscountInfo;
import com.example.demo.service.IDiscountInfoService;
import com.example.demo.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 红包卡券Service业务层处理
 * 
 * @author zxx
 * @date 2023-01-20
 */
@Service
public class DiscountInfoServiceImpl implements IDiscountInfoService
{
    @Autowired
    private DiscountInfoMapper discountInfoMapper;

    /**
     * 查询红包卡券
     * 
     * @param discountId 红包卡券主键
     * @return 红包卡券
     */
    @Override
    public DiscountInfo selectDiscountInfoByDiscountId(Long discountId)
    {
        return discountInfoMapper.selectDiscountInfoByDiscountId(discountId);
    }

    /**
     * 查询红包卡券列表
     * 
     * @param discountInfo 红包卡券
     * @return 红包卡券
     */
    @Override
    public List<DiscountInfo> selectDiscountInfoList(DiscountInfo discountInfo)
    {
        return discountInfoMapper.selectDiscountInfoList(discountInfo);
    }

    /**
     * 新增红包卡券
     * 
     * @param discountInfo 红包卡券
     * @return 结果
     */
    @Override
    public int insertDiscountInfo(DiscountInfo discountInfo)
    {
        discountInfo.setCreateTime(DateUtils.getNowDate());
        return discountInfoMapper.insertDiscountInfo(discountInfo);
    }

    /**
     * 修改红包卡券
     * 
     * @param discountInfo 红包卡券
     * @return 结果
     */
    @Override
    public int updateDiscountInfo(DiscountInfo discountInfo)
    {
        discountInfo.setUpdateTime(DateUtils.getNowDate());
        return discountInfoMapper.updateDiscountInfo(discountInfo);
    }

    /**
     * 批量删除红包卡券
     * 
     * @param discountIds 需要删除的红包卡券主键
     * @return 结果
     */
    @Override
    public int deleteDiscountInfoByDiscountIds(Long[] discountIds)
    {
        return discountInfoMapper.deleteDiscountInfoByDiscountIds(discountIds);
    }

    /**
     * 删除红包卡券信息
     * 
     * @param discountId 红包卡券主键
     * @return 结果
     */
    @Override
    public int deleteDiscountInfoByDiscountId(Long discountId)
    {
        return discountInfoMapper.deleteDiscountInfoByDiscountId(discountId);
    }
}
