package com.example.demo.service.impl;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.dao.CustomerMapper;
import com.example.demo.dao.FoodScoreMapper;
import com.example.demo.dao.FoodSingleScoreMapper;
import com.example.demo.dao.OrderInfoMapper;
import com.example.demo.domain.*;
import com.example.demo.service.IFoodScoreService;
import com.example.demo.utils.DateUtils;
import org.apache.ibatis.transaction.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * scoreService业务层处理
 * 
 * @author zxx
 * @date 2023-01-09
 */
@Service
public class FoodScoreServiceImpl implements IFoodScoreService
{
    @Autowired
    private FoodScoreMapper foodScoreMapper;
    @Autowired
    private CustomerMapper customerMapper;
    @Autowired
    private OrderInfoMapper orderInfoMapper;
    @Autowired
    private FoodSingleScoreMapper foodSingleScoreMapper;
    /**
     * 查询score
     * 
     * @param scoreId score主键
     * @return score
     */
    @Override
    public FoodScore selectFoodScoreByScoreId(Long scoreId)
    {
        return foodScoreMapper.selectFoodScoreByScoreId(scoreId);
    }

    /**
     * 查询score列表
     * 
     * @param foodScore score
     * @return score
     */
    @Transactional
    @Override
    public List selectFoodScoreList(FoodScore foodScore)

    {
        List<FoodScore> foodScores = foodScoreMapper.selectFoodScoreList(foodScore);
        List temp=new ArrayList<>();
        for(FoodScore list:foodScores){
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(list,"yyyy-MM-dd HH:mm:ss"), Map.class);
            Customer customer = customerMapper.selectById(list.getCustomerId());
            map.put("customerImg",customer!=null?customer.getCustomerImg():"");
            map.put("customerName",customer!=null?customer.getNickname():"匿名");
            String[] imgs = list.getScoreImg()!=null?list.getScoreImg().split(","):null;
            map.put("scoreImgs",imgs);
            temp.remove("scoreId");
            temp.add(map);
        }
        return temp;
    }
    @Transactional
    @Override
    public List selectAutoCustomerId(FoodScore foodScore)

    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        foodScore.setCustomerId((long) id);
        List<FoodScore> foodScores = foodScoreMapper.selectFoodScoreList(foodScore);
        List temp=new ArrayList<>();
        for(FoodScore list:foodScores){
            Map map = JSON.parseObject(JSONObject.toJSONStringWithDateFormat(list,"yyyy-MM-dd HH:mm:ss"), Map.class);
            Customer customer = customerMapper.selectById(list.getCustomerId());
            map.put("customerImg",customer!=null?customer.getCustomerImg():"");
            map.put("customerName",customer!=null?customer.getNickname():"匿名");
            String[] imgs = list.getScoreImg()!=null?list.getScoreImg().split(","):null;
            map.put("scoreImgs",imgs);
            temp.remove("scoreId");
            temp.add(map);
        }
        return temp;
    }
    /**
     * 新增score
     * 
     * @param foodScore score
     * @return 结果
     */
    @Override
    @Transactional
    public int insertFoodScore(FoodScore foodScore)
    {
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        LoginCustomer loginCustomer=(LoginCustomer) authentication.getPrincipal();
        int id=loginCustomer.getCustomer().getCustomerId();
        int i=1;
        foodScore.setCustomerId((long) id);
        foodScore.setCreateTime(DateUtils.getNowDate());
        List<FoodSingleScore> singleScore = foodScore.getSingleScore();
        //插入单个菜品，并且计算总体的平均分
        int sum=0;
        for(FoodSingleScore fss:singleScore){
            Integer score = Integer.valueOf(fss.getScore());
            sum+=score;
            //创建一个临时查询的foodSingleScore，查看有没有重复的，重复则删除
            FoodSingleScore foodSingleScore = new FoodSingleScore();
            foodSingleScore.setCustomerId((long) id);
            foodSingleScore.setFoodId(fss.getFoodId());
            List<FoodSingleScore> foodSingleScores
                    = foodSingleScoreMapper.selectFoodSingleScoreList(foodSingleScore);
            if(foodSingleScores.size()!=0){
                foodSingleScore = foodSingleScores.get(0);
                i=foodSingleScoreMapper.deleteFoodSingleScoreBySingleId(foodSingleScore.getSingleId());
                if(i<=0){
                    //如果删除条数为0则回滚
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                    return 0;
                }
            }
            //插入单个菜品的评价
            fss.setCustomerId((long) id);
            fss.setCreateTime(DateUtils.getNowDate());
            i=foodSingleScoreMapper.insertFoodSingleScore(fss);
            //如果插入条数为0则回滚
            if(i<=0){
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                return 0;
            }

        }
        foodScore.setScore(String.valueOf(sum/singleScore.size()));
        //修改订单已为评价状态
        OrderInfo orderInfo = new OrderInfo();
        orderInfo.setOrderId(foodScore.getOrderId());
        orderInfo.setIseval(1);
        i=orderInfoMapper.updateOrderInfo(orderInfo);
        if(i<=0){
            //如果插入条数为0则回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return 0;
        }
        //插入总的评价
        if(foodScoreMapper.insertFoodScore(foodScore)<=0){
            //如果插入条数为0则回滚
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return 0;
        }
        return 1;
    }

    /**
     * 修改score
     * 
     * @param foodScore score
     * @return 结果
     */
    @Override
    public int updateFoodScore(FoodScore foodScore)
    {
        foodScore.setUpdateTime(DateUtils.getNowDate());
        return foodScoreMapper.updateFoodScore(foodScore);
    }

    /**
     * 批量删除score
     * 
     * @param scoreIds 需要删除的score主键
     * @return 结果
     */
    @Override
    public int deleteFoodScoreByScoreIds(Long[] scoreIds)
    {
        return foodScoreMapper.deleteFoodScoreByScoreIds(scoreIds);
    }

    /**
     * 删除score信息
     * 
     * @param scoreId score主键
     * @return 结果
     */
    @Override
    public int deleteFoodScoreByScoreId(Long scoreId)
    {
        return foodScoreMapper.deleteFoodScoreByScoreId(scoreId);
    }
}
