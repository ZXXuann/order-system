package com.example.demo.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.math.BigDecimal;

/**
 * 菜品管理对象 food
 * 
 * @author zxx
 * @date 2023-01-09
 */
public class Food extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 菜品标识 */
    private Long foodId;

    /** 菜品名 */
    private String foodName;

    /** 菜品价格 */

    private BigDecimal foodPrice;

    /** 菜品图片 */

    private String foodImg;

    /** 菜品详细 */

    private String foodDetail;

    /** 菜品状态 */
    private String foodStatus;

    /** 菜品所属类型 */
    private Long foodType;
    /** 菜品是否有规格 */
    private Integer isSingle;

    public Integer getIsSingle() {
        return isSingle;
    }

    public void setIsSingle(Integer isSingle) {
        this.isSingle = isSingle;
    }

    public void setFoodId(Long foodId)
    {
        this.foodId = foodId;
    }

    public Long getFoodId() 
    {
        return foodId;
    }
    public void setFoodName(String foodName) 
    {
        this.foodName = foodName;
    }

    public String getFoodName() 
    {
        return foodName;
    }
    public void setFoodPrice(BigDecimal foodPrice) 
    {
        this.foodPrice = foodPrice;
    }

    public BigDecimal getFoodPrice() 
    {
        return foodPrice;
    }
    public void setFoodImg(String foodImg) 
    {
        this.foodImg = foodImg;
    }

    public String getFoodImg() 
    {
        return foodImg;
    }
    public void setFoodDetail(String foodDetail) 
    {
        this.foodDetail = foodDetail;
    }

    public String getFoodDetail() 
    {
        return foodDetail;
    }
    public void setFoodStatus(String foodStatus) 
    {
        this.foodStatus = foodStatus;
    }

    public String getFoodStatus() 
    {
        return foodStatus;
    }
    public void setFoodType(Long foodType) 
    {
        this.foodType = foodType;
    }

    public Long getFoodType() 
    {
        return foodType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("foodId", getFoodId())
            .append("foodName", getFoodName())
            .append("foodPrice", getFoodPrice())
            .append("foodImg", getFoodImg())
            .append("foodDetail", getFoodDetail())
            .append("foodStatus", getFoodStatus())
            .append("foodType", getFoodType())
            .append("createTime", getCreateTime())
            .append("createBy", getCreateBy())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
