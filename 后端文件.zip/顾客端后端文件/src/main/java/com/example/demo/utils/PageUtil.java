package com.example.demo.utils;

import com.example.demo.domain.PageDomain;

public class PageUtil {
    public static PageDomain getPageDomain(){
        String pageNum = SevletUtil.getParameter("pageNum");
        String pageSize = SevletUtil.getParameter("pageSize");
        PageDomain pageDomain = new PageDomain();
        pageDomain.setPageNum(pageNum==null||"".equals(pageNum.trim())?1: Integer.valueOf(pageNum));
        pageDomain.setPageSize(pageSize==null||"".equals(pageSize.trim())?10: Integer.valueOf(pageSize));
        return pageDomain;
    }
}
