package com.example.demo.utils;

import com.example.demo.domain.R;
import org.springframework.http.HttpStatus;

public class RU {
    //成功的返回
    public static R OK(Object obj){
        return new R<>(HttpStatus.OK.value(), obj);
    }
    //失败的返回
    public static R NO(){
        return new R<>(HttpStatus.BAD_REQUEST.value(),"操作失败");
    }
    public static R NO(Object obj){
        return new R<>(HttpStatus.BAD_REQUEST.value(),obj);
    }
}
