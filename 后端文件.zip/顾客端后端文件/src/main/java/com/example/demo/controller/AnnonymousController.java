package com.example.demo.controller;

import com.example.demo.service.IIndexService;
import com.example.demo.domain.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("anms")
public class AnnonymousController {
    @Autowired
    private IIndexService IIndexService;
    //首页的图片获取
    @GetMapping("index")
    public R index(){
       return IIndexService.getPic();
    }
}
