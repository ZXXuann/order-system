package com.example.demo;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.jdbc.MySQLJDBCDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.model.JDBCDataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;
import java.util.Map.Entry;
//基于用户的协同过滤算法
public class UCF {

    public static void main(String[] args) {
        //由于quartz在使用时非单例，无法直接使用autowired注入，那么直接用mysql数据源
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setServerName("localhost");
        dataSource.setUser("root");
        dataSource.setPassword("111111");
        dataSource.setDatabaseName("mydb");
        //获取数据模型
        JDBCDataModel dataModel = new MySQLJDBCDataModel(dataSource, "food_single_score", "customer_id", "food_id", "score", null);
        DataModel model = dataModel;
        try {
            //计算皮尔逊相似度
            UserSimilarity similarity = new PearsonCorrelationSimilarity(model);
            //计算阈值 k近邻
            UserNeighborhood neighborhood = new NearestNUserNeighborhood(3, similarity, model);
            Recommender recommender = new GenericUserBasedRecommender(model, neighborhood, similarity);
            //获取每个用户的推荐数据
            LongPrimitiveIterator userIDs = dataModel.getUserIDs();
            Connection connection = dataSource.getConnection();
            //先删除先前生成的协同过滤数据
            PreparedStatement del = connection.prepareStatement("delete from food_recommendation");
            del.execute();
            while(userIDs.hasNext()){
                Long id = userIDs.next();
                //获取3个推荐
                List<RecommendedItem> recommendations = recommender.recommend(id, 3);
                System.out.println(recommendations.size());
                for(RecommendedItem tmp:recommendations) {
                    //获取推荐具体值并删除原先数据后插入数据
                    long itemID = tmp.getItemID();
                    float value = tmp.getValue();
                    //生成新的协同过滤数据
                    PreparedStatement ins = connection.prepareStatement(
                            "insert into food_recommendation(customer_id,food_id,score,create_time) values (?,?,?,?)");
                    ins.setString(1,String.valueOf(id));
                    ins.setString(2,String.valueOf(itemID));
                    ins.setString(3,String.valueOf(value));
                    ins.setDate(4,new java.sql.Date(new Date().getTime()));
                    ins.execute();
                    ins.close();
                }
            }
            //关闭连接
            del.close();
            connection.close();
            System.out.println("成功");
        } catch (TasteException e) {
            System.out.println(e);
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
